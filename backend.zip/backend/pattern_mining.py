# src/graphrag/pattern_mining.py

import json
import os
import time
from datetime import datetime
from typing import List, Dict, Tuple, Optional
from dotenv import load_dotenv, find_dotenv
from openai import OpenAI
from gqlalchemy import Memgraph

load_dotenv(find_dotenv())

# ─────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────

FLAG_NODE_LABEL = "SystemFlag"
FLAG_NAME = "pattern_mining_dirty"

# Type pairs that appear in nearly every circuit — too ubiquitous
# to carry topological signal. Excluded from co-occurrence graph.
EXCLUDED_TYPES = {"Unknown"}

# If a type-pair co-appears in more than this fraction of all
# circuits, it's too generic to define a meaningful pattern.
MAX_COOCCURRENCE_RATIO = 0.80

# Communities made entirely of passive types (no IC anchor)
# are almost always noise. Discard them.
IC_ANCHOR_TYPES = {"IC", "Transistor"}

# Minimum number of circuits two different component types must
# share before we draw a CO_OCCURS_WITH edge between them.
DEFAULT_MIN_COOCCURRENCE = 2

# Canonical type normalization
COMPONENT_TYPE_MAP = {
    "Resistor":              "Resistor",
    "Capacitor":             "Capacitor",
    "Inductor":              "Inductor",
    "IC":                    "IC",
    "Diode":                 "Diode",
    "Transistor":            "Transistor",
    "Connector":             "Connector",
    "Oscillator":            "Oscillator",
    "Circuit_Protection":    "Circuit_Protection",
    "Display":               "Display",
    "Switch":                "Switch",
    "PartQuest":             "PartQuest",
    "Capacitor (Polarized)": "Capacitor",
    "Test Point":            "Connector",
    "Fuse":                  "Circuit_Protection",
    "Voltage Regulator":     "IC",
    "op_amp": "IC",
    "Sensor": "Sensor",
    "Filter":                "Filter",
    "LED":                   "Diode",
    "Transformer": "Transformer",
    "ferritebead": "Ferrite Bead",
    "ferrite_bead": "Ferrite Bead", 
    "op_amp": "IC",
    "ground": "Connector",
    "schottky_diode": "Diode",
    "tvs_diode": "Diode",
    "fb": "Ferrite Bead",  # footprint prefix
    "Unknown":               "Unclassified",
}

def normalize_component_type(raw_type: str) -> str:
    """Normalize component type to canonical form."""
    if not raw_type:
        return "Unknown"
    return COMPONENT_TYPE_MAP.get(raw_type.lower().strip(), raw_type)
# ─────────────────────────────────────────────────────────────
# Sub-step 1a — Build co-occurrence edges
# ─────────────────────────────────────────────────────────────

def build_cooccurrence_edges(
    db: Memgraph,
    min_cooccurrence: int = DEFAULT_MIN_COOCCURRENCE
) -> int:
    """
    Scans all CircuitDescriptions in Memgraph and creates
    CO_OCCURS_WITH edges between ComponentNode types that
    appear together in at least min_cooccurrence circuits.

    Guards applied:
    - Same-type pairs excluded (Capacitor↔Capacitor meaningless)
    - EXCLUDED_TYPES (Unknown) ignored entirely
    - Pairs appearing in > MAX_COOCCURRENCE_RATIO of circuits
      are too generic and excluded

    Returns number of CO_OCCURS_WITH edges created.
    """

    print("\n📊 Step 1a — Building co-occurrence edges...")

    # 1. Count total circuits
    total_result = list(db.execute_and_fetch(
        "MATCH (d:CircuitDescription) RETURN count(d) AS total"
    ))
    total_circuits = total_result[0]['total'] if total_result else 0

    if total_circuits == 0:
        print("  ❌ No circuits found in Memgraph.")
        return 0

    print(f"  Found {total_circuits} circuits in database.")

    # 2. Fetch all (circuit_id, component_type) pairs
    pairs_query = """
    MATCH (d:CircuitDescription)-[:HAS_COMPONENT]->(c:ComponentNode)
    RETURN ID(d) AS circuit_id, c.type AS comp_type
    """
    raw_pairs = list(db.execute_and_fetch(pairs_query))

    # 3. Group component types by circuit
    circuit_types: Dict[int, set] = {}
    for row in raw_pairs:
        cid = row['circuit_id']
        ctype = row['comp_type']
        if ctype in EXCLUDED_TYPES:
            continue
        if cid not in circuit_types:
            circuit_types[cid] = set()
        circuit_types[cid].add(ctype)

    # 4. Count co-occurrences for every distinct type pair
    cooccurrence: Dict[Tuple[str, str], int] = {}
    for cid, types in circuit_types.items():
        type_list = sorted(types)  # sort so (A,B) and (B,A) are the same key
        for i in range(len(type_list)):
            for j in range(i + 1, len(type_list)):
                t1, t2 = type_list[i], type_list[j]
                if t1 == t2:
                    continue  # guard: no same-type pairs
                key = (t1, t2)
                cooccurrence[key] = cooccurrence.get(key, 0) + 1

    # 5. Apply filters
    max_allowed = int(total_circuits * MAX_COOCCURRENCE_RATIO)
    filtered_pairs = {
        (t1, t2): count
        for (t1, t2), count in cooccurrence.items()
        if count >= min_cooccurrence and count <= max_allowed
    }

    print(f"  Total type pairs found:     {len(cooccurrence)}")
    print(f"  Pairs after filtering:      {len(filtered_pairs)}")

    if not filtered_pairs:
        print("  ⚠️  No pairs survived filtering. "
              "Try lowering min_cooccurrence.")
        return 0

    # 6. Clear old CO_OCCURS_WITH edges before re-writing
    db.execute("MATCH ()-[r:CO_OCCURS_WITH]->() DELETE r")
    print("  🗑️  Cleared old CO_OCCURS_WITH edges.")

    # 7. Write new edges
    # CO_OCCURS_WITH edges live between ComponentNode instances,
    # but we work at the type level (one edge per type-pair,
    # using the first matching node of each type as anchor).
    edge_count = 0
    for (t1, t2), weight in filtered_pairs.items():
        create_query = """
        MATCH (a:ComponentNode {type: $t1})
        MATCH (b:ComponentNode {type: $t2})
        WHERE ID(a) <> ID(b)
        WITH a, b LIMIT 1
        MERGE (a)-[r:CO_OCCURS_WITH]->(b)
        SET r.weight = $weight
        """
        db.execute(create_query, {
            't1': t1,
            't2': t2,
            'weight': weight
        })
        edge_count += 1
        print(f"    ↔ {t1} ↔ {t2}  (weight={weight})")

    print(f"  ✅ Created {edge_count} CO_OCCURS_WITH edges.")
    return edge_count


# ─────────────────────────────────────────────────────────────
# Sub-step 1b — Run Louvain via Memgraph MAGE
# ─────────────────────────────────────────────────────────────
def run_louvain(db: Memgraph) -> Dict[int, List[str]]:
    """
    Calls community_detection.get() via Memgraph MAGE.
    Returns a dict: { community_id -> [component_type, ...] }
    """

    print("\n🔬 Step 1b — Running Louvain community detection...")

    louvain_query = """
    CALL community_detection.get()
    YIELD node, community_id
    RETURN node, community_id
    """

    try:
        results = list(db.execute_and_fetch(louvain_query))
    except Exception as e:
        print(f"  ❌ Louvain failed: {e}")
        print("  Make sure MAGE is installed and "
              "community_detection.get is available.")
        return {}

    if not results:
        print("  ❌ Louvain returned no results.")
        return {}

    print(f"  Raw results count: {len(results)}")

    communities: Dict[int, set] = {}
    skipped = 0

    for row in results:
        cid = row['community_id']
        node = row['node']

        # {"id":..., "labels":[...], "properties":{...}, "type":"node"}
        # Handle both gqlalchemy Node object and plain dict
        if hasattr(node, '_labels'):
            # gqlalchemy Node object
            labels = node._labels or set()
            if 'ComponentNode' not in labels:
                skipped += 1
                continue
            ctype = node._properties.get('type', '')
        elif isinstance(node, dict):
            # plain dict (Memgraph Lab style)
            labels = node.get('labels', [])
            if 'ComponentNode' not in labels:
                skipped += 1
                continue
            ctype = node.get('properties', {}).get('type', '')
        else:
            skipped += 1
            continue



        # Normalize to canonical form
        ctype = normalize_component_type(ctype)

        if not ctype or ctype == 'Unknown':
            skipped += 1
            continue

        if cid not in communities:
            communities[cid] = set()
        communities[cid].add(ctype)

    print(f"  Skipped {skipped} non-ComponentNode results.")

    # Convert sets to sorted lists
    community_map = {
        cid: sorted(types)
        for cid, types in communities.items()
    }

    print(f"  Found {len(community_map)} raw communities:")
    for cid, types in community_map.items():
        print(f"    Community {cid}: {types}")

    return community_map

# ─────────────────────────────────────────────────────────────
# Sub-step 1c — LLM naming via gpt-4o-mini
# ─────────────────────────────────────────────────────────────

class CommunityNamer:
    """
    Sends each Louvain community to gpt-4o-mini and asks for
    a precise EDA snake_case name.
    Communities with no IC anchor are labelled unknown_cluster
    and skipped.
    """

    def __init__(self, openai_client: OpenAI):
        self.client = openai_client

    def name_community(
        self,
        community_id: int,
        component_types: List[str]
    ) -> Optional[str]:
        """
        Returns a snake_case pattern name or None if the
        community should be skipped.
        """

        # Guard: skip communities with no IC anchor
        has_ic = any(t in IC_ANCHOR_TYPES for t in component_types)
        if not has_ic:
            print(f"    ⏭️  Community {community_id} skipped "
                  f"(no IC anchor): {component_types}")
            return None

        # Guard: skip single-type communities
        if len(component_types) < 2:
            print(f"Community {community_id} skipped "
                  f"(only one type): {component_types}")
            return None
        # Guard: maximum 8 types — broader than this is not discriminating
        if len(component_types) > 8:
            print(f"Community {community_id} skipped "
                f"(too broad, max=8): {component_types}")
            return None

      

        prompt = f"""You are an expert electronics engineer specializing in PCB sub-circuit pattern recognition.

Given a list of component types that co-occur in a graph cluster extracted from real PCB schematics,
output a single snake_case name describing the most likely sub-circuit pattern.

Component types: {component_types}

Rules:
- Output ONLY the snake_case name, nothing else
- Use standard EDA/schematic terminology
"""
        
        
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = self.client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0,
                    max_tokens=20
                )
                name = response.choices[0].message.content.strip().lower()
                name = name.replace(" ", "_").replace("-", "_")

                if name == "unknown_cluster":
                    print(f"    ⏭️  Community {community_id} -> "
                          f"unknown_cluster, skipped.")
                    return None

                print(f"    ✅ Community {community_id} "
                      f"{component_types} -> '{name}'")
                return name

            except Exception as e:
                print(f"    ⚠️  Attempt {attempt + 1} failed: {e}")
                if attempt < max_retries - 1:
                    time.sleep(2)
                    continue
                print(f"    ❌ Naming failed for community "
                      f"{community_id} after {max_retries} attempts.")
                return None


# ─────────────────────────────────────────────────────────────
# Sub-step 1d — Store PatternNodes and CONTAINS_PATTERN edges
# ─────────────────────────────────────────────────────────────

def store_patterns(
    db: Memgraph,
    community_map: Dict[int, List[str]],
    named_communities: Dict[int, str]
) -> int:
    """
    For each named community:
    1. Deduplicates identical type-sets (Louvain sometimes produces
       communities with the same component types — keep first, skip rest)
    2. Pre-filters by component count, match_ratio, and min_circuits
       BEFORE creating any node — prevents ghost PatternNodes
    3. Deduplicates names across viable communities only
       (active_filter -> active_filter_1, active_filter_2)
    4. Creates each PatternNode with CREATE (not MERGE) so every
       surviving community gets its own distinct node
    5. Creates CONTAINS_PATTERN edges

    Returns number of PatternNodes created.
    """

    print("\n\U0001f4be Step 1d \u2014 Storing PatternNodes and edges...")

    # Clear old PatternNodes and CONTAINS_PATTERN edges
    db.execute("MATCH (p:PatternNode) DETACH DELETE p")
    print("  \U0001f5d1\ufe0f  Cleared old PatternNodes.")

    # Cache total circuit count once
    total_result = list(db.execute_and_fetch(
        "MATCH (d:CircuitDescription) RETURN count(d) AS total"
    ))
    total_circuits = total_result[0]['total'] if total_result else 0

    # ── Step A: pre-filter every community before touching the graph ──
    viable = {}  # community_id -> (pattern_name, component_types, matching_circuits)
    seen_type_sets = set()  # frozensets of component_types already processed
    # Compute once before the loop — total_circuits never changes
    min_circuits_required = max(2, total_circuits // 3)
    max_ratio = min(0.90, 0.40 + (1.0 / max(total_circuits, 1)))


    for community_id, pattern_name in named_communities.items():
        component_types = community_map[community_id]
        type_set = frozenset(component_types)

        # Guard: identical type-set already seen (Louvain duplicate community)
        if type_set in seen_type_sets:
            print(f"  \u23ed\ufe0f  Pre-filter: '{pattern_name}' {component_types} "
                  f"skipped \u2014 identical type-set already processed")
            continue
        seen_type_sets.add(type_set)

        # Guard: minimum 3 component types
        if len(component_types) < 3:
            print(f"  \u23ed\ufe0f  Pre-filter: '{pattern_name}' skipped "
                  f"\u2014 only {len(component_types)} types (min: 3)")
            continue

        # Guard: maximum 8 component types
        if len(component_types) > 8:
            print(f"  \u23ed\ufe0f  Pre-filter: '{pattern_name}' skipped "
                  f"\u2014 {len(component_types)} types (max: 8)")
            continue

        type_conditions = "\n".join([
            f"AND (d)-[:HAS_COMPONENT]->(:ComponentNode {{type: '{t}'}})"
            for t in component_types
        ])
        find_circuits_query = f"""
        MATCH (d:CircuitDescription)
        WHERE true
        {type_conditions}
        RETURN ID(d) AS desc_id, d.title AS title
        """
        matching_circuits = list(db.execute_and_fetch(find_circuits_query))
        match_ratio = (
            len(matching_circuits) / total_circuits
            if total_circuits > 0 else 0
        )
        # Query matching circuits
        matching_circuits = list(db.execute_and_fetch(find_circuits_query))
        match_ratio = len(matching_circuits) / total_circuits if total_circuits > 0 else 0

        # Guard: minimum circuits
        if len(matching_circuits) < min_circuits_required:
            print(f"  skipped — only {len(matching_circuits)} circuits "
                f"(min: {min_circuits_required})")
            continue

        # Guard: too generic
        if match_ratio > max_ratio:
            print(f"  skipped — {match_ratio:.0%} of circuits "
                f"(threshold: {max_ratio:.0%})")
            continue

    viable[community_id] = (pattern_name, component_types, matching_circuits)
    print(f"\n  {len(viable)} communities passed pre-filter "
          f"(skipped {len(named_communities) - len(viable)}).")

    # ── Step B: deduplicate names across viable communities only ──
    from collections import defaultdict
    name_counts: Dict[str, int] = defaultdict(int)
    for _, (name, _, _) in viable.items():
        name_counts[name] += 1

    name_usage: Dict[str, int] = defaultdict(int)

    # ── Step C: create nodes and edges ──
    pattern_count = 0
    now = datetime.utcnow().isoformat()

    for community_id, (pattern_name, component_types, matching_circuits) in viable.items():

        # Unique name — suffix only when duplicates exist
        if name_counts[pattern_name] > 1:
            name_usage[pattern_name] += 1
            unique_name = f"{pattern_name}_{name_usage[pattern_name]}"
        else:
            unique_name = pattern_name

        types_json = json.dumps(component_types)

        # CREATE not MERGE — every surviving community is a distinct node
        create_pattern_query = """
        CREATE (p:PatternNode {
            name: $name,
            component_types: $types,
            community_id: $cid,
            created_at: $created_at
        })
        RETURN ID(p) AS pattern_id
        """
        result = list(db.execute_and_fetch(create_pattern_query, {
            'name': unique_name,
            'types': types_json,
            'cid': community_id,
            'created_at': now
        }))

        if not result:
            print(f"  \u274c Failed to create PatternNode '{unique_name}'")
            continue

        pattern_id = result[0]['pattern_id']
        match_ratio = len(matching_circuits) / total_circuits
        print(f"\n  \U0001f4cc PatternNode '{unique_name}' (ID: {pattern_id})")
        print(f"     Types: {component_types}")
        print(f"     Circuits matched: {len(matching_circuits)} "
              f"({match_ratio:.0%} of database)")

        for circuit in matching_circuits:
            desc_id = circuit['desc_id']
            title = circuit['title']
            edge_query = """
            MATCH (d:CircuitDescription), (p:PatternNode)
            WHERE ID(d) = $desc_id AND ID(p) = $pattern_id
            MERGE (d)-[:CONTAINS_PATTERN]->(p)
            """
            db.execute(edge_query, {
                'desc_id': desc_id,
                'pattern_id': pattern_id
            })
            print(f"       \u2192 '{title}' -[:CONTAINS_PATTERN]-> '{unique_name}'")

        pattern_count += 1

    print(f"\n  \u2705 Stored {pattern_count} PatternNodes.")
    return pattern_count


class PatternMiningPipeline:
    """
    Orchestrates all four sub-steps of pattern mining.
    Run once after bulk loading circuits into Memgraph,
    and re-run whenever the dirty flag is set.
    """

    def __init__(
        self,
        db: Memgraph,
        openai_client: OpenAI,
        min_cooccurrence: int = DEFAULT_MIN_COOCCURRENCE
    ):
        self.db = db
        self.openai_client = openai_client
        self.min_cooccurrence = min_cooccurrence
        self.namer = CommunityNamer(openai_client)

    def run(self) -> Dict:
        """
        Runs all four sub-steps end to end.
        Returns a summary dict.
        """
        print("\n" + "="*60)
        print("PATTERN MINING PIPELINE")
        print("="*60)

        # Step 1a
        edge_count = build_cooccurrence_edges(
            self.db,
            self.min_cooccurrence
        )
        if edge_count == 0:
            print("\n⚠️  No co-occurrence edges created. "
                  "Aborting pipeline.")
            return {"status": "aborted", "reason": "no_edges"}

        # Step 1b
        community_map = run_louvain(self.db)
        if not community_map:
            print("\n⚠️  Louvain returned no communities. "
                  "Aborting pipeline.")
            return {"status": "aborted", "reason": "no_communities"}

        # Step 1c
        print("\n🏷️  Step 1c — Naming communities with gpt-4o-mini...")
        named_communities: Dict[int, str] = {}
        for community_id, component_types in community_map.items():
            name = self.namer.name_community(
                community_id,
                component_types
            )
            if name is not None:
                named_communities[community_id] = name

        print(f"\n  Named {len(named_communities)} / "
              f"{len(community_map)} communities.")

        if not named_communities:
            print("\n⚠️  No communities were named. "
                  "Aborting pipeline.")
            return {
                "status": "aborted",
                "reason": "no_named_communities"
            }

        # Step 1d
        pattern_count = store_patterns(
            self.db,
            community_map,
            named_communities
        )

        # Final summary
        summary = {
            "status": "complete",
            "cooccurrence_edges": edge_count,
            "raw_communities": len(community_map),
            "named_communities": len(named_communities),
            "pattern_nodes_stored": pattern_count
        }

        print("\n" + "="*60)
        print("PATTERN MINING COMPLETE")
        print("="*60)
        for k, v in summary.items():
            print(f"  {k}: {v}")

        return summary
    


def set_dirty(db: Memgraph):
    """Call this whenever a new circuit is stored."""
    db.execute("""
        MERGE (f:SystemFlag {name: $name})
        SET f.dirty = true, f.updated_at = $now
    """, {"name": FLAG_NAME, "now": __import__("datetime").datetime.utcnow().isoformat()})
    print("🚩 Pattern mining flagged as dirty.")

def clear_dirty(db: Memgraph):
    """Call this after pipeline completes successfully."""
    db.execute("""
        MERGE (f:SystemFlag {name: $name})
        SET f.dirty = false, f.updated_at = $now
    """, {"name": FLAG_NAME, "now": __import__("datetime").datetime.utcnow().isoformat()})
    print("✅ Pattern mining dirty flag cleared.")

def is_dirty(db: Memgraph) -> bool:
    """Returns True if pipeline needs to run."""
    result = list(db.execute_and_fetch("""
        MATCH (f:SystemFlag {name: $name})
        RETURN f.dirty AS dirty
    """, {"name": FLAG_NAME}))

    if not result:
        return True   # flag node doesn't exist yet → treat as dirty (first run)

    return result[0].get("dirty", True)


# ─────────────────────────────────────────────────────────────
# Convenience function
# ─────────────────────────────────────────────────────────────

def run_pattern_mining_pipeline(
    db: Memgraph,
    openai_client: OpenAI,
    min_cooccurrence: int = DEFAULT_MIN_COOCCURRENCE
) -> Dict:
    """
    Top-level entry point called from scripts or notebook.

    Usage:
        from graphrag.pattern_mining import run_pattern_mining_pipeline
        summary = run_pattern_mining_pipeline(
            db=memgraph.memgraph,
            openai_client=OpenAI()
        )
    """
    pipeline = PatternMiningPipeline(db, openai_client, min_cooccurrence)
    return pipeline.run()