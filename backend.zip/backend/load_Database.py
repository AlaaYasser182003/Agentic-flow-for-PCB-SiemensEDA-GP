import sqlite3
import json
import os
import base64
from typing import Dict, List, Any, Optional

def convert_bytes_to_base64(data: Any) -> Any:
    """
    Recursively convert bytes objects to base64 strings
    """
    if isinstance(data, bytes):
        # Convert bytes to base64 string
        return base64.b64encode(data).decode('utf-8')
    elif isinstance(data, dict):
        return {k: convert_bytes_to_base64(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_bytes_to_base64(item) for item in data]
    elif isinstance(data, tuple):
        return tuple(convert_bytes_to_base64(item) for item in data)
    else:
        return data

def sqlite_to_json(db_path: str, output_dir: str = None, 
                   encode_bytes: str = 'base64') -> Dict[str, List[Dict]]:
    """
    Export all tables from SQLite database to JSON
    
    Args:
        db_path: Path to SQLite database file
        output_dir: Directory to save JSON files (optional)
        encode_bytes: How to encode bytes ('base64', 'hex', or 'ignore')
    
    Returns:
        Dictionary with table names as keys and list of rows as values
    """
    
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"Database file not found: {db_path}")
    
    # Connect to SQLite database
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # Get all table names
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    tables = [table[0] for table in tables]
    
    # Dictionary to store all data
    all_data = {}
    
    # Create output directory if specified
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    
    # Export each table
    for table_name in tables:
        print(f"Exporting table: {table_name}")
        
        try:
            # Get table data
            cursor.execute(f"SELECT * FROM {table_name}")
            rows = cursor.fetchall()
            
            # Convert rows to list of dictionaries
            table_data = []
            for row in rows:
                row_dict = dict(row)
                
                # Handle bytes in the row
                for key, value in row_dict.items():
                    if isinstance(value, bytes):
                        if encode_bytes == 'base64':
                            row_dict[key] = base64.b64encode(value).decode('utf-8')
                        elif encode_bytes == 'hex':
                            row_dict[key] = value.hex()
                        else:  # ignore or remove
                            row_dict[key] = None
                
                table_data.append(row_dict)
            
            all_data[table_name] = table_data
            
            # Save individual table to JSON file if output_dir specified
            if output_dir:
                output_file = os.path.join(output_dir, f"{table_name}.json")
                with open(output_file, 'w', encoding='utf-8') as f:
                    json.dump(table_data, f, indent=2, ensure_ascii=False)
                print(f"  Saved to: {output_file}")
                
        except Exception as e:
            print(f"  ❌ Error exporting table {table_name}: {e}")
            continue
    
    conn.close()
    
    # Save all data to a single JSON file
    if output_dir:
        all_data_file = os.path.join(output_dir, 'all_tables.json')
        with open(all_data_file, 'w', encoding='utf-8') as f:
            json.dump(all_data, f, indent=2, ensure_ascii=False, 
                     default=bytes_to_base64_handler)
        print(f"\nAll data saved to: {all_data_file}")
    
    return all_data

def bytes_to_base64_handler(obj):
    """Custom JSON encoder for bytes objects"""
    if isinstance(obj, bytes):
        return {
            '_type': 'bytes',
            '_encoding': 'base64',
            '_value': base64.b64encode(obj).decode('utf-8')
        }
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

# Advanced version with better error handling
class SQLiteToJSON:
    """Export SQLite database to JSON with bytes support"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn = None
        self.cursor = None
        
    def connect(self):
        """Establish database connection"""
        if not os.path.exists(self.db_path):
            raise FileNotFoundError(f"Database file not found: {self.db_path}")
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()
        
    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
            
    def get_tables(self) -> List[str]:
        """Get list of all user tables"""
        self.cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name NOT LIKE 'sqlite_%'
        """)
        return [row[0] for row in self.cursor.fetchall()]
    
    def get_table_schema(self, table_name: str) -> Dict:
        """Get table schema information"""
        self.cursor.execute(f"PRAGMA table_info({table_name})")
        columns = self.cursor.fetchall()
        
        return {
            'table_name': table_name,
            'columns': [
                {
                    'name': col[1],
                    'type': col[2],
                    'not_null': bool(col[3]),
                    'default': col[4],
                    'primary_key': bool(col[5])
                }
                for col in columns
            ]
        }
    
    def row_to_dict(self, row, encode_bytes: str = 'base64') -> Dict:
        """Convert SQLite row to dictionary with bytes handling"""
        row_dict = dict(row)
        
        for key, value in row_dict.items():
            if isinstance(value, bytes):
                if encode_bytes == 'base64':
                    row_dict[key] = base64.b64encode(value).decode('utf-8')
                elif encode_bytes == 'hex':
                    row_dict[key] = value.hex()
                else:  # 'ignore'
                    row_dict[key] = f'<bytes: {len(value)} bytes>'
                    
        return row_dict
    
    def export_table(self, table_name: str, encode_bytes: str = 'base64') -> Dict:
        """Export a single table to dictionary"""
        # Get data
        self.cursor.execute(f"SELECT * FROM {table_name}")
        rows = self.cursor.fetchall()
        
        data = []
        for row in rows:
            data.append(self.row_to_dict(row, encode_bytes))
        
        return {'data': data, 'count': len(data)}
    
    def export_all(self, 
                   output_dir: str = '.',
                   single_file: bool = True,
                   encode_bytes: str = 'base64',
                   exclude_tables: List[str] = None) -> None:
        """
        Export all tables to JSON
        
        Args:
            output_dir: Directory to save JSON files
            single_file: Whether to save all data in one file
            encode_bytes: How to encode bytes ('base64', 'hex', 'ignore')
            exclude_tables: List of table names to exclude
        """
        self.connect()
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        # Get all tables
        tables = self.get_tables()
        if exclude_tables:
            tables = [t for t in tables if t not in exclude_tables]
        
        print(f"Found {len(tables)} tables: {', '.join(tables)}")
        
        all_data = {}
        export_summary = {'tables_exported': 0, 'total_rows': 0}
        
        # Export each table
        for table_name in tables:
            print(f"Exporting: {table_name}")
            
            try:
                table_data = self.export_table(table_name, encode_bytes)
                all_data[table_name] = table_data['data']
                export_summary['tables_exported'] += 1
                export_summary['total_rows'] += table_data['count']
                print(f"  → {table_data['count']} rows exported")
                
                # Save individual table files if not using single file
                if not single_file:
                    filename = os.path.join(output_dir, f"{table_name}.json")
                    with open(filename, 'w', encoding='utf-8') as f:
                        json.dump(table_data['data'], f, indent=2, ensure_ascii=False)
                    print(f"  → Saved to: {filename}")
                    
            except Exception as e:
                print(f"  ❌ Error: {e}")
                continue
        
        # Save all data to one file
        if single_file:
            import datetime
            timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = os.path.join(output_dir, f'export_all_{timestamp}.json')
            
            export_data = {
                'export_info': {
                    'export_date': datetime.datetime.now().isoformat(),
                    'database': os.path.basename(self.db_path),
                    'bytes_encoding': encode_bytes,
                    'summary': export_summary
                },
                'data': all_data
            }
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            print(f"\n✅ All data exported to: {filename}")
            print(f"   Tables: {export_summary['tables_exported']}, Rows: {export_summary['total_rows']}")
        
        self.close()

# Example usage for your specific case
if __name__ == "__main__":
    # Use the fixed function
    db_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "backend\\lib.db"
    )   
    print("path....",db_path) 
    output_dir = "json_exports"
    
    try:
        # Method 1: Using the simple function
        print("Method 1: Using simple function")
        result = sqlite_to_json(db_path, output_dir, encode_bytes='base64')
        print(f"\n✅ Successfully exported {len(result)} tables")
        
        # Print summary
        for table, data in result.items():
            print(f"  - {table}: {len(data)} rows")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    
    print("\n" + "="*50 + "\n")
    
    try:
        # Method 2: Using the class (more features)
        print("Method 2: Using class with more options")
        exporter = SQLiteToJSON(db_path)
        
        # Export with different bytes encoding options
        exporter.export_all(
            output_dir='json_exports',
            single_file=True,
            encode_bytes='base64',  # 'base64', 'hex', or 'ignore'
            exclude_tables=['temp', 'backup']  # optional
        )
        
    except Exception as e:
        print(f"❌ Error: {e}")