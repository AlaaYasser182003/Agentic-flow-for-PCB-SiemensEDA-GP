
"""
pads_agent.py — PADS Pro EDIF Import/Export Agent
==================================================
Part of an agentic PCB design pipeline:

  [Schematic JSON Agent]
        |
        v  (schematic dict)
  [EDIF Mapper Agent]
        |
        v  (EDIF string or .edf/.edn file path)
  [THIS AGENT — PADSAgent]
        |  import: feeds EDIF into PADS Pro via edifgraf.exe
        |  export: pulls EDIF out of PADS Pro via edifExporter.exe
        v  (AgentResult — output_path on export, None on import)
  [Next agent / fabrication / DRC ...]

PADS Pro version : VX.2.12
Install root     : set via PADS_ROOT env variable or Config below.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import tempfile
import importlib
import config
importlib.reload(config)
from config import PADS_ROOT as _CONFIG_PADS_ROOT
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

class Config:
    PADS_ROOT: str = os.getenv("PADS_ROOT", _CONFIG_PADS_ROOT)

    @classmethod
    def sdd_home(cls) -> Path:
        return Path(cls.PADS_ROOT) / "SDD_HOME"

    @classmethod
    def mglaunch(cls) -> Path:
        return cls.sdd_home() / "common" / "win32" / "bin" / "mglaunch.exe"

    @classmethod
    def edif_importer(cls) -> Path:
        # edifgraf.exe — imports EDIF netlist into PADS Pro
        return cls.sdd_home() / "wv" / "win64" / "bin" / "edifgraf.exe"

    @classmethod
    def edif_exporter(cls) -> Path:
        # edifExporter.exe — exports EDIF netlist from PADS Pro
        return cls.sdd_home() / "wv" / "win64" / "bin" / "edifExporter.exe"

    USE_MGLAUNCH: bool = os.getenv("PADS_USE_MGLAUNCH", "true").lower() == "true"
    TIMEOUT: int = int(os.getenv("PADS_TIMEOUT", "120"))
    DEFAULT_OUTPUT_DIR: str = os.getenv("PADS_OUTPUT_DIR", r"E:\PADS_Pipeline_Output")


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

class Status(str, Enum):
    OK      = "ok"
    WARNING = "warning"
    ERROR   = "error"


@dataclass
class AgentResult:
    """
    Returned by every PADSAgent operation.
    Pass directly into the next agent in the pipeline.
    """
    status:      Status
    operation:   str
    output_path: Optional[Path] = None   # set on export, None on import
    log_path:    Optional[Path] = None
    message:     str            = ""
    metadata:    dict           = field(default_factory=dict)

    def ok(self) -> bool:
        return self.status == Status.OK

    def to_dict(self) -> dict:
        return {
            "status":      self.status.value,
            "operation":   self.operation,
            "output_path": str(self.output_path) if self.output_path else None,
            "log_path":    str(self.log_path)    if self.log_path    else None,
            "message":     self.message,
            "metadata":    self.metadata,
        }

    def __repr__(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


# ---------------------------------------------------------------------------
# Logger
# ---------------------------------------------------------------------------

def _make_logger(log_path: Path) -> logging.Logger:
    logger = logging.getLogger(f"pads_agent_{id(log_path)}")
    logger.setLevel(logging.DEBUG)
    if not logger.handlers:
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
        logger.addHandler(fh)
        logger.addHandler(sh)
    return logger


# ---------------------------------------------------------------------------
# Core agent
# ---------------------------------------------------------------------------

class PADSAgent:
    """
    EDIF-only Import/Export agent for PADS Pro VX.2.12.

    Instantiate via class methods:
        agent = PADSAgent.from_file("netlist.edf")
        agent = PADSAgent.from_edif_string(edif_content)

    Then call:
        result = agent.import_edif()
        result = agent.export_edif(output_dir="E:/output")
    """

    def __init__(
        self,
        edif_path:    Optional[Path] = None,
        edif_content: Optional[str]  = None,
        prj_file:     Optional[Path] = None, 
    ):
        if edif_path is None and edif_content is None:
            raise ValueError("Provide either edif_path or edif_content.")
        self._edif_path    = edif_path
        self._edif_content = edif_content   
        self._prj_file     = prj_file

    # ------------------------------------------------------------------
    # Factory constructors
    # ------------------------------------------------------------------

    @classmethod
    def from_file(cls, path: str | Path, prj_file: str | Path | None = None) -> "PADSAgent":
        """FILE mode: EDIF mapper wrote a .edf/.edn file to disk."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"EDIF file not found: {p}")
        return cls(
            edif_path=p,
            prj_file=Path(prj_file) if prj_file else None   # ← pass it through to __init__
        )
    @classmethod
    def from_edif_string(cls, edif_content: str) -> "PADSAgent":
        """DICT mode: EDIF mapper returns the EDIF as a Python string."""
        if not edif_content.strip():
            raise ValueError("EDIF content string is empty.")
        return cls(edif_content=edif_content)

    # ------------------------------------------------------------------
    # Import
    # ------------------------------------------------------------------

    def import_edif(self) -> AgentResult:
        """
        Import EDIF netlist into PADS Pro via edifgraf.exe.

        One-way feed into the tool — no output file is produced by this
        agent. AgentResult carries only status + log_path.
        """
        ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = Path(tempfile.gettempdir()) / f"pads_import_edif_{ts}.log"
        logger   = _make_logger(log_path)

        logger.info("=== PADSAgent — import_edif ===")
        logger.info("PADS root     : %s", Config.PADS_ROOT)
        logger.info("edifgraf.exe  : %s", Config.edif_importer())

        with tempfile.TemporaryDirectory() as tmpdir:
            try:
                edif_file = self._resolve_edif(Path(tmpdir), logger)
                importer  = Config.edif_importer()
                self._check_exe(importer, logger)

                cmd = self._wrap([
                    str(importer),
                    "-i", str(edif_file),
                    *(["-p", str(self._prj_file)] if self._prj_file else []), 
                ])

                logger.info("Running: %s", " ".join(cmd))
                self._run(cmd, logger)

                logger.info("SUCCESS — EDIF imported into PADS Pro")
                return AgentResult(
                    status=Status.OK,
                    operation="import_edif",
                    output_path=None,
                    log_path=log_path,
                    message="EDIF imported successfully into PADS Pro.",
                    metadata={"input": str(edif_file)},
                )

            except Exception as exc:
                logger.exception("import_edif failed")
                return AgentResult(
                    status=Status.ERROR,
                    operation="import_edif",
                    log_path=log_path,
                    message=str(exc),
                )

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_edif(self, output_dir: str | Path | None = None) -> AgentResult:
        """
        Export EDIF netlist from the current PADS Pro design via edifExporter.exe.
        Returns AgentResult with output_path pointing to the .edf file.
        """
        out_dir  = Path(output_dir) if output_dir else Path(Config.DEFAULT_OUTPUT_DIR)
        out_dir.mkdir(parents=True, exist_ok=True)

        ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = out_dir / f"export_edif_{ts}.log"
        logger   = _make_logger(log_path)

        logger.info("=== PADSAgent — export_edif ===")
        logger.info("PADS root        : %s", Config.PADS_ROOT)
        logger.info("edifExporter.exe : %s", Config.edif_exporter())
        logger.info("Output dir       : %s", out_dir)

        try:
            exporter = Config.edif_exporter()
            self._check_exe(exporter, logger)

            out_file = out_dir / f"exported_{ts}.edf"

            cmd = self._wrap([
                str(exporter),
                "-o", str(out_file),
            ])

            logger.info("Running: %s", " ".join(cmd))
            self._run(cmd, logger)

            if not out_file.exists():
                return AgentResult(
                    status=Status.ERROR,
                    operation="export_edif",
                    log_path=log_path,
                    message=f"Exporter ran but output not found: {out_file}",
                )

            logger.info("SUCCESS — EDIF exported to: %s", out_file)
            return AgentResult(
                status=Status.OK,
                operation="export_edif",
                output_path=out_file,
                log_path=log_path,
                message="EDIF exported successfully.",
                metadata={"output": str(out_file)},
            )

        except Exception as exc:
            logger.exception("export_edif failed")
            return AgentResult(
                status=Status.ERROR,
                operation="export_edif",
                log_path=log_path,
                message=str(exc),
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_edif(self, tmpdir: Path, logger: logging.Logger) -> Path:
        if self._edif_path:
            return self._edif_path
        edif_file = tmpdir / "input_netlist.edf"
        edif_file.write_text(self._edif_content, encoding="utf-8")  # type: ignore[arg-type]
        logger.info("EDIF string written to temp: %s", edif_file)
        return edif_file

    def _wrap(self, cmd: list[str]) -> list[str]:
        if not Config.USE_MGLAUNCH:
            return cmd
        mglaunch = Config.mglaunch()
        if not mglaunch.exists():
            return cmd
        return [str(mglaunch)] + cmd

    def _run(self, cmd: list[str], logger: logging.Logger) -> None:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=Config.TIMEOUT,
            text=True,
        )
        for line in (result.stdout or "").splitlines():
            logger.debug("  [exe] %s", line)
        if result.returncode != 0:
            raise RuntimeError(
                f"Process exited with code {result.returncode}:\n{result.stdout}"
            )

    @staticmethod
    def _check_exe(path: Path, logger: logging.Logger) -> None:
        if not path.exists():
            logger.error("Executable not found: %s", path)
            raise FileNotFoundError(f"Executable not found: {path}")


# ---------------------------------------------------------------------------
# Pipeline helper
# ---------------------------------------------------------------------------

def run_edif_agent(
    operation:   str,
    edif_input:  str | Path | None = None,
    edif_string: str | None        = None,
    output_dir:  str | Path | None = None,
) -> AgentResult:
    """
    Thin wrapper for the pipeline orchestrator.

    Examples:
        # FILE mode import
        result = run_edif_agent("import_edif", edif_input="netlist.edn")
        if result.ok():
            pass  # EDIF is now inside PADS Pro

        # DICT mode import
        result = run_edif_agent("import_edif", edif_string=edif_mapper_output)

        # Export
        result = run_edif_agent("export_edif", output_dir="E:/output")
        if result.ok():
            next_agent(result.output_path)
    """
    if operation == "import_edif":
        if edif_input:
            agent = PADSAgent.from_file(edif_input)
        elif edif_string:
            agent = PADSAgent.from_edif_string(edif_string)
        else:
            raise ValueError("import_edif requires edif_input or edif_string.")
        return agent.import_edif()

    elif operation == "export_edif":
        agent = PADSAgent.from_edif_string("(edif dummy)")
        return agent.export_edif(output_dir)

    else:
        raise ValueError(f"Unknown operation '{operation}'. Use 'import_edif' or 'export_edif'.")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
#
# USAGE:
#   python pads_agent.py import_edif --edif netlist.edn
#   python pads_agent.py export_edif --output E:\output
#   python pads_agent.py import_edif --edif netlist.edn --dry-run
#   python pads_agent.py import_edif --edif netlist.edn --pads-root "E:\MentorGraphics\PADSProVX.2.12"
#
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        prog="pads_agent.py",
        description="PADS Pro VX.2.12 — EDIF Import/Export Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
operations:
  import_edif   Feed a .edf/.edn netlist into PADS Pro    (needs --edif)
  export_edif   Export EDIF netlist from PADS Pro         (needs --output)
        """,
    )

    parser.add_argument(
        "operation",
        choices=["import_edif", "export_edif"],
        help="Operation to perform",
    )
    parser.add_argument(
        "--edif",
        metavar="FILE",
        help="Path to input .edf/.edn file  (required for import_edif)",
    )
    parser.add_argument(
        "--output",
        metavar="DIR",
        default=Config.DEFAULT_OUTPUT_DIR,
        help=f"Output directory for export_edif (default: {Config.DEFAULT_OUTPUT_DIR})",
    )
    parser.add_argument(
        "--pads-root",
        metavar="DIR",
        help=f"Override PADS Pro install root (default: {Config.PADS_ROOT})",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate inputs and print resolved paths without calling any executable",
    )

    args = parser.parse_args()

    if args.pads_root:
        Config.PADS_ROOT = args.pads_root

    # Validate
    errors = []
    if args.operation == "import_edif" and not args.edif:
        errors.append("--edif is required for import_edif")
    if args.edif and not Path(args.edif).exists():
        errors.append(f"--edif file not found: {args.edif}")
    if errors:
        for e in errors:
            print(f"[ERROR] {e}")
        sys.exit(1)

    # Dry run
    if args.dry_run:
        print("\n[DRY RUN] Resolved configuration:")
        print(f"  Operation        : {args.operation}")
        print(f"  PADS root        : {Config.PADS_ROOT}")
        print(f"  SDD_HOME         : {Config.sdd_home()}")
        print(f"  mglaunch         : {Config.mglaunch()}  {'[found]' if Config.mglaunch().exists() else '[NOT FOUND]'}")
        print(f"  edifgraf.exe     : {Config.edif_importer()}  {'[found]' if Config.edif_importer().exists() else '[NOT FOUND]'}")
        print(f"  edifExporter.exe : {Config.edif_exporter()}  {'[found]' if Config.edif_exporter().exists() else '[NOT FOUND]'}")
        if args.edif:
            print(f"  EDIF input       : {args.edif}  [found]")
        if args.operation == "export_edif":
            print(f"  Output dir       : {args.output}")
        print("\n[DRY RUN] No executables were called.")
        sys.exit(0)

    # Run
    result = run_edif_agent(
        operation=args.operation,
        edif_input=args.edif,
        output_dir=args.output if args.operation == "export_edif" else None,
    )

    print(result)
    sys.exit(0 if result.ok() else 1)