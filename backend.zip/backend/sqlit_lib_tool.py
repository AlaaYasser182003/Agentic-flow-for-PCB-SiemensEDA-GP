"""
library_tool_sqlite.py
======================
PADS Pro Library Search Tool backed by lib_merged.db (SQLite FTS5).

Schema expected in lib_merged.db:
    parts_exact : partNumber, internalPN, manufacturer, description,
                  value, package, category, datasheet, supplier,
                  supplierPN, tolerance, voltage, source
    parts       : FTS5 virtual table over same columns

Integration:
    from library_tool_sqlite import search_library, LIBRARY_SYSTEM_ADDITION
    llm_with_tools = llm.bind_tools([search_component_datasheet, search_library])
"""

from __future__ import annotations

import re
from datetime import datetime
import sqlite3
from typing import Optional, List, Dict, Any
from langchain_core.tools import tool

# ── Loaded once at startup ─────────────────────────────────────────────────────
import os
# LIBRARY_DB: str = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "lib.db")
LIBRARY_DB = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "lib.db"
)
COLS = [
    "partNumber", "internalPN", "manufacturer", "description",
    "value", "value_numeric", "package", "category", "datasheet",
    "supplier", "supplierPN", "tolerance", "voltage", "source",
]
PASSIVE_CATEGORIES = {"resistor", "capacitor", "inductor", "fuse", "ferrite", "inductor"}

# ── Component type synonyms ────────────────────────────────────────────────────
# Maps user/LLM terms → DB description tokens
DESCRIPTION_SYNONYMS: dict[str, list[str]] = {
    # Capacitors
    "decoupling":    ["CAP CER", "MLCC", "bypass"],
    "bypass":        ["CAP CER", "MLCC", "decoupling"],
    "bulk":          ["CAP ALUM", "electrolytic"],
    "electrolytic":  ["CAP ALUM", "ALUM"],
    "ceramic":       ["CAP CER", "MLCC", "CER"],
    "mlcc":          ["CAP CER", "ceramic"],
    "tantalum":      ["CAP TANT", "TANT"],
    # Resistors
    "pullup":        ["RES SMD", "thick film"],
    "pulldown":      ["RES SMD", "thick film"],
    "current sense": ["RES SMD", "shunt"],
    "shunt":         ["RES SMD", "current sense"],
    # Inductors
    "choke":         ["INDUCTOR", "FERRITE", "choke"],
    "ferrite bead":  ["FERRITE", "EMI"],
    # ICs
    "ldo":           ["IC REG LDO", "linear regulator"],
    "vreg":          ["IC REG", "regulator"],
    "opamp":         ["IC OPAMP", "operational amplifier"],
    "op-amp":        ["IC OPAMP", "operational amplifier"],
    "mosfet":        ["MOSFET", "FET"],
    "nmos":          ["MOSFET N-CH", "N-channel"],
    "pmos":          ["MOSFET P-CH", "P-channel"],
    "bjt":           ["transistor", "NPN", "PNP"],
    "usb":           ["USB", "UART", "serial"],
    "uart":          ["UART", "serial", "USB"],
    "mcu":           ["IC MCU", "microcontroller", "AVR", "ARM"],
    "microcontroller": ["IC MCU", "MCU"],
}

# ── Value parsing ──────────────────────────────────────────────────────────────

_METRIC = {
    "p": 1e-12, "n": 1e-9, "u": 1e-6, "µ": 1e-6,
    "m": 1e-3,  "k": 1e3,  "K": 1e3,  "M": 1e6,  "G": 1e9,
}

def _parse_value(raw) -> float | None:
    """Convert '10k', '100nF', '4.7uH' → float. Returns None if unparseable."""
    if raw is None:
        return None
    if isinstance(raw, (int, float)):
        return float(raw)
    s = str(raw).strip().replace(",", ".")
    s = re.sub(r"(?i)(ohm|ω|Ω|f|h)$", "", s).strip()
    # handle EIA notation: 4u7 → 4.7u, 4R7 → 4.7
    s = re.sub(r"^(\d+)([uUnNpPkKmMgG])(\d+)$",
               lambda m: f"{m.group(1)}.{m.group(3)}{m.group(2)}", s)
    m = re.match(r"^([+-]?\d+\.?\d*)\s*([pnuµmkKMG]?)$", s)
    if not m:
        return None
    num, prefix = float(m.group(1)), m.group(2)
    return num * _METRIC.get(prefix, 1.0)

def _values_close(a: float, b: float, tol: float = 0.20) -> bool:
    if a == 0 and b == 0:
        return True
    if a == 0 or b == 0:
        return False
    return abs(a - b) / max(abs(a), abs(b)) <= tol

def _voltage_ok(requested: str, rated: str) -> bool:
    def _v(s):
        m = re.search(r"(\d+\.?\d*)", str(s))
        return float(m.group(1)) if m else 0.0
    return _v(rated) >= _v(requested)

def _normalize_value_for_search(value: str, category: str = None) -> list[str]:
    """
    Generate all equivalent string representations of a value for DB matching.
    e.g. "100nF" → ["100nF","0.1uF","0.1UF","100NF","100000pF",...]
    """
    target = _parse_value(value)
    if target is None:
        return [value, value.upper()]

    variants: set[str] = {value, value.upper(), value.lower()}
    cat = (category or "").lower()

    def _add(v: float, unit: str):
        # generate clean representations, avoid scientific notation
        if v == int(v):
            s = str(int(v))
        else:
            s = f"{v:.6g}"
        variants.add(f"{s}{unit}")
        variants.add(f"{s}{unit.upper()}")
        variants.add(f"{s} {unit}")
        variants.add(f"{s} {unit.upper()}")

    # ── Capacitor ──────────────────────────────────────────────────────────────
    if "cap" in cat or target < 1e-3:
        if 1e-3 <= target:
            _add(target * 1e3, "mF")
        if 1e-6 <= target < 1:
            _add(target * 1e6, "uF")
            _add(target * 1e6, "µF")
        if 1e-9 <= target < 1e-3:
            _add(target * 1e9, "nF")
        if 1e-12 <= target < 1e-6:
            _add(target * 1e12, "pF")
        # cross-unit: 100nF → also add 0.1uF and vice versa
        if 1e-9 <= target < 1e-6:
            _add(target * 1e6, "uF")   # 100nF → 0.1uF
        if 1e-6 <= target < 1e-3:
            _add(target * 1e9, "nF")   # 0.1uF → 100nF

    # ── Resistor ───────────────────────────────────────────────────────────────
    if "res" in cat or target >= 1:
        if target >= 1e6:
            _add(target / 1e6, "M")
            _add(target / 1e6, "MEG")
            variants.add(f"{target / 1e6:.4g}Mohm")
        if target >= 1e3:
            _add(target / 1e3, "k")
            variants.add(f"{target / 1e3:.4g}kohm")
        # bare value
        if target == int(target):
            variants.update([str(int(target)), f"{int(target)}R",
                             f"{int(target)}ohm"])
        else:
            variants.update([f"{target:.4g}", f"{target:.4g}R"])

    # ── Inductor ───────────────────────────────────────────────────────────────
    if "ind" in cat or "ferrite" in cat:
        if target >= 1e-3:
            _add(target * 1e3, "mH")
        if target >= 1e-6:
            _add(target * 1e6, "uH")
            _add(target * 1e6, "µH")
        if target >= 1e-9:
            _add(target * 1e9, "nH")

    variants.discard("")
    return list(variants)


def _expand_query_synonyms(query: str) -> list[str]:
    """
    Expand query words using synonym table.
    Returns list of all search tokens (original + synonyms).
    """
    tokens = set()
    q_lower = query.lower()
    for term, synonyms in DESCRIPTION_SYNONYMS.items():
        if term in q_lower:
            tokens.update(synonyms)
    # also add original words (length > 1, not stopwords)
    STOPWORDS = {"a", "an", "the", "for", "and", "or", "with", "of", "to", "in"}
    tokens.update(
        w for w in query.split()
        if len(w) > 1 and w.lower() not in STOPWORDS
    )
    return list(tokens)


def _build_fts_query(tokens: list[str]) -> str:
    """
    Build a robust FTS5 query from tokens.
    Uses AND for required terms, falls back to OR if AND returns nothing.
    Caller should try AND first then OR.
    """
    # quote each token to prevent FTS5 syntax errors
    safe = [f'"{t}"' for t in tokens if t.strip()]
    return " AND ".join(safe)

def _build_fts_query_or(tokens: list[str]) -> str:
    safe = [f'"{t}"' for t in tokens if t.strip()]
    return " OR ".join(safe)


# ── Core search ────────────────────────────────────────────────────────────────

def search_library_db(
    query:    str,
    db_path:  str,
    top_k:    int = 5,
    category: str | None = None,
    value:    str | None = None,
    voltage:  str | None = None,
) -> list[dict]:
    """
    Multi-tier search with passive-first and IC-first paths.

    Passives (Resistor/Capacitor/Inductor/Fuse):
      T0: value + category exact SQL  
      T1: value variants FTS AND     
      T2: value variants FTS OR       
      T3: description FTS AND         
      T4: description FTS OR
      T5: LIKE per-word               

    ICs / Connectors / all others:
      T1: exact partNumber            
      T2: partNumber prefix LIKE      
      T3: FTS AND (all tokens)        
      T4: FTS OR (synonym-expanded)   
      T5: LIKE per-word on description 
    """
    conn    = sqlite3.connect(db_path)
    results = []

    is_passive = category and category.lower() in PASSIVE_CATEGORIES

    # ══════════════════════════════════════════════════════════════════
    # PASSIVE PATH
    # ══════════════════════════════════════════════════════════════════
    if is_passive:

        # ── T0: value + category direct SQL ───────────────────────────
        if value:
            target = _parse_value(value)
            if target is not None:
                tol  = 0.20
                low  = target * (1 - tol)
                high = target * (1 + tol)
                try:
                    rows = conn.execute(
                        "SELECT * FROM parts_exact "
                        "WHERE value_numeric BETWEEN ? AND ? "
                        "AND   category = ? COLLATE NOCASE "
                        f"LIMIT {top_k * 4}",
                        (low, high, category)
                    ).fetchall()
                    if rows:
                        results = rows
                except Exception:
                    pass  
     # ── T1: value variants in description via FTS AND ─────────────
        if not results and value:
            value_variants = _normalize_value_for_search(value, category)
            cat_tokens     = [category] if category else []
            all_tokens     = value_variants + cat_tokens
            fts_and        = _build_fts_query(all_tokens[:6])
            try:
                fts_rows = conn.execute(
                    f"SELECT partNumber FROM parts WHERE parts MATCH ? "
                    f"ORDER BY rank LIMIT {top_k * 3}",
                    (fts_and,)
                ).fetchall()
                if fts_rows:
                    pns          = [r[0] for r in fts_rows]
                    placeholders = ",".join("?" * len(pns))
                    rows         = conn.execute(
                        f"SELECT * FROM parts_exact "
                        f"WHERE partNumber IN ({placeholders})",
                        pns
                    ).fetchall()
                    if rows:
                        results = rows
            except Exception:
                pass

        # ── T2: value variants FTS OR ──────────────────────────────────
        if not results and value:
            value_variants = _normalize_value_for_search(value, category)
            fts_or         = _build_fts_query_or(value_variants[:8])
            try:
                fts_rows = conn.execute(
                    f"SELECT partNumber FROM parts WHERE parts MATCH ? "
                    f"ORDER BY rank LIMIT {top_k * 3}",
                    (fts_or,)   # or fts_and depending on tier
                ).fetchall()
                if fts_rows:
                    pns          = [r[0] for r in fts_rows]
                    placeholders = ",".join("?" * len(pns))
                    rows         = conn.execute(
                        f"SELECT * FROM parts_exact "
                        f"WHERE partNumber IN ({placeholders})",
                        pns
                    ).fetchall()
                    if rows:
                        results = rows
            except Exception:
                pass

        # ── T3: description tokens FTS AND (synonym-expanded) ──────────
        if not results:
            tokens  = _expand_query_synonyms(query)
            fts_and = _build_fts_query(tokens[:6])
            try:
                fts_rows = conn.execute(
                    f"SELECT partNumber FROM parts WHERE parts MATCH ? "
                    f"ORDER BY rank LIMIT {top_k * 3}",
                    (fts_and,)   # or fts_and depending on tier
                ).fetchall()
                if fts_rows:
                    pns          = [r[0] for r in fts_rows]
                    placeholders = ",".join("?" * len(pns))
                    rows         = conn.execute(
                        f"SELECT * FROM parts_exact "
                        f"WHERE partNumber IN ({placeholders})",
                        pns
                    ).fetchall()
                    if rows:
                        results = rows
            except Exception:
                pass

        # ── T4: description tokens FTS OR ─────────────────────────────
        if not results:
            tokens = _expand_query_synonyms(query)
            fts_or = _build_fts_query_or(tokens)
            try:
                fts_rows = conn.execute(
                    f"SELECT partNumber FROM parts WHERE parts MATCH ? "
                    f"ORDER BY rank LIMIT {top_k * 3}",
                    (fts_or,)   # or fts_and depending on tier
                ).fetchall()
                if fts_rows:
                    pns          = [r[0] for r in fts_rows]
                    placeholders = ",".join("?" * len(pns))
                    rows         = conn.execute(
                        f"SELECT * FROM parts_exact "
                        f"WHERE partNumber IN ({placeholders})",
                        pns
                    ).fetchall()
                    if rows:
                        results = rows
            except Exception:
                pass

        # ── T5: LIKE per-word fallback ────────────────────────────────
        if not results:
            words = [w for w in query.split() if len(w) > 2]
            if words:
                clauses = " AND ".join(
                    ["(description LIKE ? OR value LIKE ?)"] * len(words)
                )
                params = []
                for w in words:
                    params += [f"%{w}%", f"%{w}%"]
                try:
                    rows = conn.execute(
                        f"SELECT * FROM parts_exact WHERE {clauses} "
                        f"LIMIT {top_k * 3}",
                        params
                    ).fetchall()
                    if rows:
                        results = rows
                except Exception:
                    pass

    # ══════════════════════════════════════════════════════════════════
    # IC / ACTIVE PATH
    # ══════════════════════════════════════════════════════════════════
    else:

        # ── T1: exact partNumber ───────────────────────────────────────
        rows = conn.execute(
            "SELECT * FROM parts_exact WHERE partNumber = ? COLLATE NOCASE",
            (query,)
        ).fetchall()
        if rows:
            results = rows

        # ── T2: exact internalPN ───────────────────────────────────────
        # internalPN often holds base MPN without suffix
        # e.g. partNumber="ATMEGA328P-AU", internalPN="ATMEGA328P"
        if not results:
            rows = conn.execute(
                "SELECT * FROM parts_exact WHERE internalPN = ? COLLATE NOCASE "
                f"LIMIT {top_k * 3}",
                (query,)
            ).fetchall()
            if rows:
                results = rows

        # ── T3: partNumber prefix LIKE ─────────────────────────────────
        # "FT232RL" finds "FT232RL-REEL", "FT232RL-R", etc.
        if not results:
            rows = conn.execute(
                "SELECT * FROM parts_exact WHERE partNumber LIKE ? COLLATE NOCASE "
                f"LIMIT {top_k * 3}",
                (f"{query}%",)
            ).fetchall()
            if rows:
                results = rows

        # ── T4: partNumber substring LIKE ─────────────────────────────
        # "328P" finds "ATMEGA328P-AU", "ATMEGA328P-MU", etc.
        if not results:
            rows = conn.execute(
                "SELECT * FROM parts_exact WHERE partNumber LIKE ? COLLATE NOCASE "
                f"LIMIT {top_k * 3}",
                (f"%{query}%",)
            ).fetchall()
            if rows:
                results = rows

        # ── T5: internalPN prefix + substring LIKE ────────────────────
        if not results:
            rows = conn.execute(
                "SELECT * FROM parts_exact "
                "WHERE internalPN LIKE ? OR internalPN LIKE ? COLLATE NOCASE "
                f"LIMIT {top_k * 3}",
                (f"{query}%", f"%{query}%")
            ).fetchall()
            if rows:
                results = rows

        # ── T6: partNumber + internalPN per-word LIKE ─────────────────
        # handles "ATMEGA 328P" or "mega328" style queries
        if not results:
            words = [w for w in query.split() if len(w) > 2]
            if words:
                clauses = " AND ".join(
                    ["(partNumber LIKE ? OR internalPN LIKE ?)"] * len(words)
                )
                params = []
                for w in words:
                    params += [f"%{w}%", f"%{w}%"]
                try:
                    rows = conn.execute(
                        f"SELECT * FROM parts_exact WHERE {clauses} "
                        f"LIMIT {top_k * 3}",
                        params
                    ).fetchall()
                    if rows:
                        results = rows
                except Exception:
                    pass

        # ── T7: FTS AND — all tokens must match ────────────────────────
        if not results:
            tokens  = _expand_query_synonyms(query)
            fts_and = _build_fts_query(tokens[:6])
            try:
                fts_rows = conn.execute(
                    f"SELECT partNumber FROM parts WHERE parts MATCH ? "
                    f"ORDER BY rank LIMIT {top_k * 3}",
                    (fts_and,)
                ).fetchall()
                if fts_rows:
                    pns          = [r[0] for r in fts_rows]
                    placeholders = ",".join("?" * len(pns))
                    rows         = conn.execute(
                        f"SELECT * FROM parts_exact "
                        f"WHERE partNumber IN ({placeholders})",
                        pns
                    ).fetchall()
                    if rows:
                        results = rows
            except Exception:
                pass

        # ── T8: FTS OR — synonym-expanded ─────────────────────────────
        if not results:
            tokens = _expand_query_synonyms(query)
            fts_or = _build_fts_query_or(tokens)
            try:
                fts_rows = conn.execute(
                    f"SELECT partNumber FROM parts WHERE parts MATCH ? "
                    f"ORDER BY rank LIMIT {top_k * 3}",
                    (fts_or,)   # or fts_and depending on tier
                ).fetchall()
                if fts_rows:
                    pns          = [r[0] for r in fts_rows]
                    placeholders = ",".join("?" * len(pns))
                    rows         = conn.execute(
                        f"SELECT * FROM parts_exact "
                        f"WHERE partNumber IN ({placeholders})",
                        pns
                    ).fetchall()
                    if rows:
                        results = rows
            except Exception:
                pass

        # ── T9: LIKE per-word on partNumber + internalPN + description ─
        if not results:
            words = [w for w in query.split() if len(w) > 2]
            if words:
                clauses = " AND ".join(
                    ["(partNumber LIKE ? OR internalPN LIKE ? OR description LIKE ?)"]
                    * len(words)
                )
                params = []
                for w in words:
                    params += [f"%{w}%", f"%{w}%", f"%{w}%"]
                try:
                    rows = conn.execute(
                        f"SELECT * FROM parts_exact WHERE {clauses} "
                        f"LIMIT {top_k * 3}",
                        params
                    ).fetchall()
                    if rows:
                        results = rows
                except Exception:
                    pass

    conn.close()

    # ── Convert to dicts ───────────────────────────────────────────────────────
    parts = [dict(zip(COLS, r)) for r in results]

    # ── Post-filter by category ────────────────────────────────────────────────
    if category:
        cat_lower = category.lower()
        filtered  = [p for p in parts if p.get("category", "").lower() == cat_lower]
        if filtered:
            parts = filtered

    # ── Post-filter by value tolerance (±20%) ─────────────────────────────────
    if value:
        target = _parse_value(value)
        if target is not None:
            valued = [
                p for p in parts
                if _parse_value(p.get("value")) is not None
                and _values_close(target, _parse_value(p.get("value")))
            ]
            if valued:
                parts = valued

    # ── Post-filter by rated voltage ───────────────────────────────────────────
    if voltage:
        volted = [
            p for p in parts
            if p.get("voltage") and _voltage_ok(voltage, p["voltage"])
        ]
        if volted:
            parts = volted

    return parts[:top_k]


# ── Formatter ─────────────────────────────────────────────────────────────────

def _fmt_part(p: dict, index: int) -> str:
    lines = [
        f"--- Candidate {index} ---",
        f"  partNumber  : {p.get('partNumber',  'N/A')}",
        f"  category    : {p.get('category',    'N/A')}",
        f"  description : {p.get('description', 'N/A')}",
        f"  value       : {p.get('value',       'N/A')}",
        f"  package     : {p.get('package',     'N/A')}",
        f"  manufacturer: {p.get('manufacturer','N/A')}",
        f"  supplierPN  : {p.get('supplierPN',  'N/A')}",
        f"  tolerance   : {p.get('tolerance',   'N/A')}",
        f"  voltage     : {p.get('voltage',     'N/A')}",
        f"  datasheet   : {p.get('datasheet',   'N/A')}",
        f"  source      : {p.get('source',      'N/A')}",
    ]
    return "\n".join(lines)


# ── LangChain tool ─────────────────────────────────────────────────────────────

@tool
def search_library(
    query:    str,
    category: Optional[str] = None,
    value:    Optional[str] = None,
    voltage:  Optional[str] = None,
) -> str:
    """
    Search the PADS Pro component library (lib_merged.db) for real parts.

    Call this BEFORE assigning any partNumber, value, or footprint
    to a component in the CircuitSpec. You MUST use a part returned
    by this tool — never invent part numbers or footprints.

    Args:
        query    : What you need, in plain English.
                   Examples: "100nF decoupling capacitor",
                             "10k pull-up resistor",
                             "NPN transistor 40V",
                             "LDO 3.3V regulator"
        category : Optional filter. One of:
                   Resistor, Capacitor, Inductor, IC, Diode,
                   Transistor, Connector, Oscillator, Filter,
                   Circuit_Protection, LED, Fuse
        value    : Optional numeric value with unit for passives.
                   Examples: "10k", "100nF", "4.7uH", "1uF", "270"
        voltage  : Optional minimum rated voltage.
                   Examples: "16V", "50V", "100V"

    Returns:
        Up to 3 real parts from the library with full properties.
        Pick ONE and use its partNumber, package, and value fields.
    """
    results = search_library_db(
        query    = query,
        db_path  = LIBRARY_DB,
        top_k    = 3,
        category = category,
        value    = value,
        voltage  = voltage,
    )

    if not results:
        # Retry without filters
        results = search_library_db(query=query, db_path=LIBRARY_DB, top_k=3)

    if not results:
        return (
            f"No parts found in library for: '{query}' "
            f"(category={category}, value={value}, voltage={voltage}).\n"
            "Add a checklist item of type 'missing' so the user can select a part."
        )

    lines = [f"=== Library results for '{query}' ===\n"]
    for i, p in enumerate(results, 1):
        lines.append(_fmt_part(p, i))
        lines.append("")

    lines.append(
        "INSTRUCTION: Select ONE of the candidates above.\n"
        "  → Set component part_number  = chosen partNumber\n"
        "  → Set component value        = value field (for passives)\n"
        "  → Set component footprint    = package field\n"
        "  → Add to metadata: 'MPN: <supplierPN>'\n"
        "  → Add to metadata: 'source: <source>'\n"
        "Do NOT use any part not listed above."
    )

    return "\n".join(lines)


# ── Batch library tool ────────────────────────────────────────────────────────

@tool
def search_library_batch(queries: List[Dict[str, Any]]) -> str:
    """
    Search the PADS Pro component library for MULTIPLE components in ONE call.

    USE THIS instead of calling search_library repeatedly.
    Collect ALL components you need to look up and send them together.

    Args:
        queries: list of search requests, each a dict with keys:
            query    : plain-English description (required)
            category : Resistor | Capacitor | Inductor | IC | Diode |
                       Transistor | Connector | Oscillator | LED | Fuse (optional)
            value    : numeric value with unit e.g. "10k", "100nF"  (optional)
            voltage  : minimum rated voltage e.g. "16V"             (optional)

    Example:
        search_library_batch([
            {"query": "ATmega328P microcontroller", "category": "IC"},
            {"query": "100nF decoupling capacitor", "category": "Capacitor", "value": "100nF"},
            {"query": "10k pull-up resistor",       "category": "Resistor",  "value": "10k"},
            {"query": "red LED",                    "category": "LED"},
        ])

    Returns:
        Results for every query in one response.
        For each component pick ONE candidate and use its partNumber/package/value.
    """
    seen: Dict[str, str] = {}
    sections = []

    for req in queries:
        query    = req.get("query", "")
        category = req.get("category")
        value    = req.get("value")
        voltage  = req.get("voltage")

        if not query:
            continue

        # Deduplicate identical queries within the same batch
        cache_key = f"{query}|{category}|{value}|{voltage}"
        if cache_key in seen:
            sections.append(
                f"=== Library results for '{query}' (same as above) ===\n"
                + seen[cache_key]
            )
            continue

        results = search_library_db(
            query=query, db_path=LIBRARY_DB, top_k=3,
            category=category, value=value, voltage=voltage,
        )
        if not results:
            results = search_library_db(query=query, db_path=LIBRARY_DB, top_k=3)

        if not results:
            block = (
                f"No parts found for: '{query}' "
                f"(category={category}, value={value}).\n"
                "→ Add a checklist item of type 'missing'."
            )
        else:
            block = "\n".join(_fmt_part(p, i) for i, p in enumerate(results, 1))

        seen[cache_key] = block
        sections.append(f"=== Library results for '{query}' ===\n{block}")

    footer = (
        "\n\nINSTRUCTION: For each component above pick ONE candidate.\n"
        "  → part_number = partNumber field\n"
        "  → value       = value field (passives)\n"
        "  → footprint   = package field\n"
        "Do NOT use any part not listed above."
    )
    return "\n\n".join(sections) + footer


# ── Datasheet cache helpers ────────────────────────────────────────────────────

def _normalize_component(name: str) -> str:
    return name.strip().upper().replace("-", "").replace("_", "").replace(" ", "")

def _ensure_cache_table():
    conn = sqlite3.connect(LIBRARY_DB)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS datasheet_cache (
            component_name TEXT PRIMARY KEY,
            datasheet_url  TEXT,
            raw_text       TEXT,
            source         TEXT,
            created_at     TEXT
        )
    """)
    conn.commit()
    conn.close()

def _cache_get(component_name: str) -> dict | None:
    key  = _normalize_component(component_name)
    conn = sqlite3.connect(LIBRARY_DB)
    row  = conn.execute(
        "SELECT datasheet_url, raw_text, source FROM datasheet_cache WHERE component_name = ?",
        (key,)
    ).fetchone()
    conn.close()
    if row:
        return {"datasheet_url": row[0], "raw_text": row[1], "source": row[2]}
    return None

def _cache_set(component_name: str, raw_text: str, source: str,
               datasheet_url: str = None):
    key  = _normalize_component(component_name)
    conn = sqlite3.connect(LIBRARY_DB)
    conn.execute("""
        INSERT OR REPLACE INTO datasheet_cache
            (component_name, datasheet_url, raw_text, source, created_at)
        VALUES (?, ?, ?, ?, ?)
    """, (key, datasheet_url, raw_text, source, datetime.now().isoformat()))
    conn.commit()
    conn.close()
    print(f"💾 [CACHE SAVED] {component_name} ({source})")
    
def _get_valid_part_numbers() -> set:
    try:
        conn = sqlite3.connect(LIBRARY_DB)
        rows = conn.execute(
            "SELECT partNumber FROM parts_exact"  # ← parts_exact only, no FTS5
        ).fetchall()
        conn.close()
        return {r[0] for r in rows if r[0]}
    except Exception as e:
        print(f"⚠️  Could not load part numbers: {e}")
        return set()
_VALID_PART_NUMBERS: set = set()   # empty until explicitly loaded

def reload_valid_part_numbers() -> int:
    """
    Wipe and reload _VALID_PART_NUMBERS fresh from lib.db.
    Discards any previously cached set — always reads the full DB.
    Call this after merging new parts, or on startup.
    Returns the new count.
    """
    global _VALID_PART_NUMBERS
    _VALID_PART_NUMBERS = set()                    # clear first
    _VALID_PART_NUMBERS = _get_valid_part_numbers() # reload fresh from DB
    print(f"🔄 Reloaded {len(_VALID_PART_NUMBERS)} part numbers from lib.db (full refresh)")
    return len(_VALID_PART_NUMBERS)





# Types that are allowed to have null part_number
SKIP_TYPES = {
    "Ground", "Power", "Supply", "PWR_FLAG", "NetTie"
}
# Load once at module import — not on every validation

#print(f"✅ Loaded {len(_VALID_PART_NUMBERS)} valid part numbers from library")

_ensure_cache_table()
_VALID_PART_NUMBERS: set = _get_valid_part_numbers()


# ── System prompt addition ─────────────────────────────────────────────────────

LIBRARY_SYSTEM_ADDITION = """
=== COMPONENT LIBRARY CONSTRAINT (MANDATORY) ===

You have access to `search_library_batch` which queries the real PADS Pro
component library (lib.db) for multiple components in ONE call.

RULES — NO EXCEPTIONS:

1. Before generating the spec, identify ALL components you need.
   Call search_library_batch ONCE with the full list — do NOT call
   search_library one component at a time.

2. For EVERY passive include value= with exact numeric value and unit:
   {"query": "100nF decoupling cap", "category": "Capacitor", "value": "100nF"}

3. For identical passives (e.g. four 100nF caps) — include ONE entry only.
   Reuse the same partNumber for all identical instances.

4. After receiving results:
   → Pick ONE candidate per component.
   → Use its partNumber as the component part_number field.
   → Use its package   as the component footprint field.
   → Use its value     as the component value field (passives).

5. If a query returns nothing:
   → Retry using search_library_batch with a shorter/simpler query.
   → If still nothing: add a checklist item of type "missing".
   → Do NOT invent a part number or footprint.
"""
