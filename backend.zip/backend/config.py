import os

_HERE = os.path.dirname(os.path.abspath(__file__))

EDN_OUTPUT_DIR = os.path.join(_HERE, "new_outputs")
OUTPUT_DIR     = os.path.join(_HERE, "output_verification")

os.makedirs(EDN_OUTPUT_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR,     exist_ok=True)

PADS_ROOT  = r"C:\\MentorGraphics\\PADSProVX.2.12"
SDD_HOME   = r"C:\\MentorGraphics\\PADSProVX.2.12\\SDD_HOME"
MGLAUNCH   = os.path.join(SDD_HOME, "common", "win32", "bin", "mglaunch.exe")
VERIFY_UI  = os.path.join(SDD_HOME, "common", "win64", "bin", "verificationUI.exe")
VDRC_EXE   = os.path.join(SDD_HOME, "wv",     "win64", "bin", "vdrc.exe")

DEFAULT_PRJ_FILE   =  r"C:\\WDIR\\PADSProVX.2.12\\DxProjects\\Project3\\Project3.prj"
DEFAULT_VERIFY_INI =  r"C:\\WDIR\\PADSProVX.2.12\\DxProjects\\Project3\\Verify.ini"
STANDARD_DIR       = os.path.join(SDD_HOME, "standard")
VERIFY_DEFAULTS    = os.path.join(SDD_HOME, "standard", "VerifyDefaults.ini")

FALLBACK_VERIFY_INI = os.path.join(EDN_OUTPUT_DIR, "Verify.ini")

DRC_CONFIG = {
    "prj_file":   DEFAULT_PRJ_FILE,
    "verify_ini": DEFAULT_VERIFY_INI,
    "output_dir": OUTPUT_DIR,
}

