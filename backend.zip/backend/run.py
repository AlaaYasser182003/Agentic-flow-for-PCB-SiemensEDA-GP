#!/usr/bin/env python
import uvicorn
import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    print(f"""
    ╔══════════════════════════════════════════════════════════╗
    ║   🚀 CircuitAI Agent API Server                          ║
    ║   Host: 127.0.0.1:8000                                   ║
    ║   API Docs: http://127.0.0.1:8000/docs                   ║
    ╚══════════════════════════════════════════════════════════╝
    """)
    # Try different import paths
    try:
        uvicorn.run(
            "app.main:app", 
            host="127.0.0.1", 
            port=8000, 
            reload=True
        )
    except Exception as e:
        print(f"Error with 'app.main': {e}")
        print("Trying alternative import...")
        uvicorn.run(
            "main:app", 
            host="127.0.0.1", 
            port=8000, 
            reload=True
        )