# %%
import json
from typing_extensions import TypedDict, Literal, Any,DefaultDict
from typing import List, Dict, Optional, Annotated, Literal
from pydantic import BaseModel, Field, field_validator
from langgraph.graph import StateGraph, END
from langgraph.types import Command, interrupt
from langchain_core.tools import tool
from IPython.display import Image
from langchain_community.tools.tavily_search import TavilySearchResults
from typing import List, Dict, Optional, Any
import numpy as np 
from gqlalchemy import Memgraph, Node, Relationship
from openai import OpenAI
from langchain_anthropic import ChatAnthropic
from langgraph.checkpoint.memory import InMemorySaver
from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage
from itertools import count
import requests
from collections import defaultdict
import importlib
import config
importlib.reload(config)
import re
import pattern_mining
importlib.reload(pattern_mining)
from pattern_mining import run_pattern_mining_pipeline , is_dirty, set_dirty, clear_dirty
import sqlit_lib_tool
importlib.reload(sqlit_lib_tool)
from sqlit_lib_tool import _cache_get, _cache_set, search_library_db, LIBRARY_DB, search_library_batch, LIBRARY_SYSTEM_ADDITION, _VALID_PART_NUMBERS ,  reload_valid_part_numbers
from config import EDN_OUTPUT_DIR, DRC_CONFIG 
import edif
importlib.reload(edif)
from edif import generate_edif_file, SKIP_TYPES, SKIP_TYPES_pn, TYPE_TO_CATEGORY ,  _patch_spec_nets
from pads_node import PADSAgent
from pads_DRC import run_pads_drc
import uuid

from dotenv import find_dotenv, load_dotenv

load_dotenv(find_dotenv())


import os
os.environ["OPENAI_API_KEY"] = "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"
os.environ["TAVILY_API_KEY"] = "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"
os.environ['ANTHROPIC_API_KEY'] = "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"




# %%
# ── Cell: reload part numbers ── 
_pn_count = reload_valid_part_numbers()
print(f"✅ {_pn_count} part numbers loaded fresh from lib.db")




import sqlite3

db_path = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "lib.db"
)
# print("daatabase paaaath ",db_path)
# conn = sqlite3.connect(db_path)
# cursor = conn.cursor()
# cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
# tables = cursor.fetchall()
# print("Available tables:",tables)
# conn.close()

# %%


mg = Memgraph(host="localhost", port=7687)

res = mg.execute_and_fetch("RETURN 1 AS ok")

print(list(res))


# %%

# Memgraph Nodes (Graph Schema)

# LAYER 1: Semantic Description
from sqlalchemy import desc


class CircuitDescription(Node):
    """Searchable description with embedding"""
    description: str
    embedding: List[float]
    title: str
    created_at: str
    confidence_score: Optional[float] = None
    structural_embedding: Optional[List[float]] = None  # GNN embedding (Step 2)
   
# LAYER 2: Circuit Components
class ComponentNode(Node):
    """Component in the circuit"""
    ref: str
    type: str
    part_number: Optional[str] = None
    value: Optional[str] = None
    footprint: Optional[str] = None
    metadata: Optional[str] = None  # JSON string
    

class PinRefNode(Node):
    """Pin reference for connections"""
    component_ref: str
    pin_number: str
    pin_name: Optional[str] = None
    pin_direction: Optional[str] = None

class NetNode(Node):
    """Net connecting components"""
    name: str
    net_type: str  # signal, power, ground

# Relationships
class DESCRIBES(Relationship, type="DESCRIBES"):
    """Description → Circuit entry point"""
    pass

class HAS_COMPONENT(Relationship, type="HAS_COMPONENT"):
    """Description → Component"""
    pass

class HAS_NET(Relationship, type="HAS_NET"):
    """Description → Net"""
    pass

class CONNECTED_TO_NET(Relationship, type="CONNECTED_TO_NET"):
    """PinRef → Net"""
    pass

class COMPONENT_HAS_PIN(Relationship, type="COMPONENT_HAS_PIN"):
    """Component → PinRef"""
    pass

# ─────────────────────────────────────────────
# Graph RAG additions — Milestone 1
# ─────────────────────────────────────────────

class PatternNode(Node):
    """
    Represents a recurring sub-circuit pattern discovered by Louvain clustering.
    Examples: buck_regulator, ldo_cluster, current_sense
    """
    name: str                                        # e.g. "buck_regulator"
    component_types: Optional[str] = None            # JSON list of type strings
    community_id: Optional[int] = None               # Raw Louvain community ID
    created_at: Optional[str] = None
    structural_embedding: Optional[List[float]] = None  # GNN embedding (Step 2)

class CO_OCCURS_WITH(Relationship, type="CO_OCCURS_WITH"):
    """
    ComponentNode ↔ ComponentNode
    Weight = number of circuits where both types co-appear.
    Intermediate edge used by Louvain — persists for re-runs.
    """
    weight: int = 1

class CONTAINS_PATTERN(Relationship, type="CONTAINS_PATTERN"):
    """
    CircuitDescription → PatternNode
    One circuit can have multiple CONTAINS_PATTERN edges.
    """
    pass


# ▼▼▼ ADDED FOR SUBCIRCUITS ▼▼▼
class SubCircuitDescription(Node):
    """
    Explicitly stored sub-circuit extracted from a parent CircuitDescription.
    Created by LLM segmentation or human curation.
    """
    name: str
    description: str
    embedding: List[float]
    source_circuit_id: int                  # desc_id of parent CircuitDescription
    created_at: Optional[str] = None
    confidence_score: Optional[float] = None

class HAS_SUBCIRCUIT(Relationship, type="HAS_SUBCIRCUIT"):
    """
    CircuitDescription → SubCircuitDescription
    One circuit can have multiple HAS_SUBCIRCUIT edges.
    """
    pass

class COMPOSED_OF_COMPONENT(Relationship, type="COMPOSED_OF_COMPONENT"):
    """
    SubCircuitDescription → ComponentNode
    Re-references existing ComponentNodes from the parent — no duplication.
    """
    pass
# ▲▲▲ ADDED FOR SUBCIRCUITS ▲▲▲
# Memgraph Circuit Manager

class CircuitMemgraph:
    """
    Manages circuit storage and retrieval in Memgraph.
    Stores circuits as graph topology with semantic search.
    """
    
    def __init__(self, memgraph_host="localhost", memgraph_port=7687):
        self.memgraph = Memgraph(host=memgraph_host, port=memgraph_port)
        self.openai_client = OpenAI()
    
    def get_embedding(self, text: str) -> List[float]:
        """Generate embedding using OpenAI"""
        response = self.openai_client.embeddings.create(
            model="text-embedding-3-small",
            input=text
        )
        return response.data[0].embedding
    
    def store_circuit_spec(self, spec) -> int:
        """
        Store a CircuitSpec in Memgraph as graph topology.
        Handles both CircuitSpec objects and dict/JSON representations.

        Args:
            spec: CircuitSpec object or dict representing the circuit

        Returns:
            desc_id: ID of the created description node
        """
        import json

        # --- Convert dict/JSON to CircuitSpec if needed ---
        if isinstance(spec, dict):
            try:
                spec = CircuitSpec(**spec)
                print(f"  ✓ Successfully converted dict to CircuitSpec")
            except Exception as e:
                print(f"  ❌ Failed to convert dict to CircuitSpec: {e}")
                import traceback
                traceback.print_exc()
                raise

        print(f"\n💾 Storing circuit '{spec.title}' in graph database...")
        print(f"  📊 Components: {len(spec.components)}, Nets: {len(spec.nets)}")

        # Generate embedding from description
        embedding = self.get_embedding(spec.description)

        # === LAYER 1: Description node ===
        desc = CircuitDescription(
            description=spec.description,
            embedding=embedding,
            title=spec.title,
            created_at=str(np.datetime64('now')),
            confidence_score=getattr(spec, 'confidence_score', 0.95)
        ).save(self.memgraph)

        print(f"  ✓ Created description node (ID: {desc._id})")

        # === LAYER 2: Circuit topology ===
        component_nodes = {}
        net_nodes = {}
        pin_ref_nodes = {}

        # Create all components first
        print(f"  🔌 Creating {len(spec.components)} components...")
        for comp in spec.components:
            metadata_str = json.dumps(comp.metadata) if comp.metadata else None

            comp_node = ComponentNode(
                ref=comp.ref,
                type=comp.type,
                part_number=getattr(comp, 'part_number', None),
                value=comp.value,
                #footprint=comp.footprint,
                metadata=metadata_str
            ).save(self.memgraph)
            component_nodes[comp.ref] = comp_node
            print(f"    ✓ Created {comp.ref} (ID: {comp_node._id})")

            # Create relationship using Cypher
            create_rel_query = """
            MATCH (desc:CircuitDescription), (comp:ComponentNode)
            WHERE ID(desc) = $desc_id AND ID(comp) = $comp_id
            CREATE (desc)-[:HAS_COMPONENT]->(comp)
            """
            self.memgraph.execute(create_rel_query, {
                'desc_id': desc._id,
                'comp_id': comp_node._id
            })

        # Create all nets
        print(f"  📡 Creating {len(spec.nets)} nets...")
        for net in spec.nets:
            # handle both dict and Pydantic object
            net_name = net['name'] if isinstance(net, dict) else net.name
            net_type = net.get('net_type', 'signal') if isinstance(net, dict) else (net.net_type or 'signal')
            net_pins = net['connected_pins'] if isinstance(net, dict) else net.connected_pins

            net_node = NetNode(
                name=net_name,
                net_type=net_type
            ).save(self.memgraph)
            net_nodes[net_name] = net_node
            print(f"    ✓ Created net '{net_name}' with {len(net_pins)} pins (ID: {net_node._id})")

            create_rel_query = """
            MATCH (desc:CircuitDescription), (net:NetNode)
            WHERE ID(desc) = $desc_id AND ID(net) = $net_id
            CREATE (desc)-[:HAS_NET]->(net)
            """
            self.memgraph.execute(create_rel_query, {
                'desc_id': desc._id,
                'net_id': net_node._id
            })

        # Create pin connections
        print(f"  🔗 Creating pin connections...")
        connection_count = 0
        for net in spec.nets:
            net_name = net['name'] if isinstance(net, dict) else net.name
            net_pins = net['connected_pins'] if isinstance(net, dict) else net.connected_pins
            net_node = net_nodes[net_name]

            for pin_ref in net_pins:
                # handle both dict and Pydantic object
                comp_ref = pin_ref['component_ref'] if isinstance(pin_ref, dict) else pin_ref.component_ref
                pin_num  = pin_ref.get('pin_number', '') if isinstance(pin_ref, dict) else (pin_ref.pin_number or '')
                pin_name = pin_ref.get('pin_name') if isinstance(pin_ref, dict) else getattr(pin_ref, 'pin_name', None)
                pin_dir  = pin_ref.get('pin_direction') if isinstance(pin_ref, dict) else getattr(pin_ref, 'pin_direction', None)

                pin_key = f"{comp_ref}.{pin_num}"   # ← fixed: was pin_ref.pin

                if pin_key not in pin_ref_nodes:
                    pin_node = PinRefNode(
                        component_ref=comp_ref,
                        pin_number=pin_num,
                        pin_name=pin_name,
                        pin_direction=pin_dir
                    ).save(self.memgraph)
                    pin_ref_nodes[pin_key] = pin_node
                    print(f"    ✓ Created pin {pin_key} (ID: {pin_node._id})")

                    if comp_ref in component_nodes:
                        create_comp_pin_query = """
                        MATCH (comp:ComponentNode), (pin:PinRefNode)
                        WHERE ID(comp) = $comp_id AND ID(pin) = $pin_id
                        CREATE (comp)-[:COMPONENT_HAS_PIN]->(pin)
                        """
                        self.memgraph.execute(create_comp_pin_query, {
                            'comp_id': component_nodes[comp_ref]._id,
                            'pin_id': pin_node._id
                        })
                        print(f"      → Linked {comp_ref} to pin {pin_num}")  # ← fixed
                    else:
                        print(f"      ⚠️ Component {comp_ref} not found!")
                else:
                    pin_node = pin_ref_nodes[pin_key]

                create_pin_net_query = """
                MATCH (pin:PinRefNode), (net:NetNode)
                WHERE ID(pin) = $pin_id AND ID(net) = $net_id
                CREATE (pin)-[:CONNECTED_TO_NET]->(net)
                """
                self.memgraph.execute(create_pin_net_query, {
                    'pin_id': pin_node._id,
                    'net_id': net_node._id
                })
                connection_count += 1
                print(f"      → Connected pin {pin_key} to net '{net_name}'")

        print(f"\n  ✅ Storage complete:")
        print(f"    • {len(component_nodes)} components")
        print(f"    • {len(net_nodes)} nets")
        print(f"    • {len(pin_ref_nodes)} pin nodes")
        print(f"    • {connection_count} pin-to-net connections\n")

        # Verify connections were created
        verify_query = """
        MATCH (desc:CircuitDescription)-[r]-(n)
        WHERE ID(desc) = $desc_id
        RETURN type(r) as rel_type, count(*) as count
        """
        verification = list(self.memgraph.execute_and_fetch(verify_query, {'desc_id': desc._id}))
        print(f"  🔍 Verification - Relationships from description node:")
        for row in verification:
            print(f"    • {row['rel_type']}: {row['count']}")
        
        set_dirty(self.memgraph)

        return desc._id
    
    def _reconstruct_circuit_spec(self, desc_id: int) -> Dict[str, Any]:
        """
        Reconstruct circuit from graph structure.
        Returns components and nets in your original format.
        """
        import json
        
        # Get all components
        comp_query = """
        MATCH (desc:CircuitDescription)-[:HAS_COMPONENT]->(comp:ComponentNode)
        WHERE ID(desc) = $desc_id
        RETURN comp
        """
        comp_results = list(self.memgraph.execute_and_fetch(comp_query, {'desc_id': desc_id}))
        
        components = []
        for comp_result in comp_results:
            comp_props = comp_result['comp']._properties
            
            # Deserialize metadata
            metadata = json.loads(comp_props.get('metadata', '[]')) if comp_props.get('metadata') else []
            
            components.append({
                'ref': comp_props['ref'],
                'type': comp_props['type'],
                'value': comp_props.get('value'),
                'footprint': comp_props.get('footprint'),
                'metadata': metadata,
                'part_number': comp_props.get('part_number'),  # ← ADD THIS!

            })
        
        # Get all nets with their pin connections
     
        net_query = """
        MATCH (desc:CircuitDescription)-[:HAS_NET]->(net:NetNode)
        WHERE ID(desc) = $desc_id
        OPTIONAL MATCH (pin:PinRefNode)-[:CONNECTED_TO_NET]->(net)
        RETURN net, collect({
        component_ref: pin.component_ref,
        pin_number: pin.pin_number,
        pin_name: pin.pin_name,
        pin_direction: pin.pin_direction
        }) as pins
        """


        net_results = list(self.memgraph.execute_and_fetch(net_query, {'desc_id': desc_id}))
        
        nets = []
        for net_result in net_results:
            net_props = net_result['net']._properties
            pins = [p for p in net_result['pins'] if p.get('component_ref')]
            
            nets.append({
                'name': net_props['name'],
                'net_type': net_props['net_type'],
                # 'is_global': net_props.get('net_type', 'signal') in ('power', 'ground'),
                'connected_pins': pins
            })
        
        return {
            'desc_id': desc_id, 
            'components': components,
            'nets': nets,
            'stats': {
                'num_components': len(components),
                'num_nets': len(nets),
                'num_connections': sum(len(n['connected_pins']) for n in nets)
            }
        }
    
    def get_statistics(self):
        """Get statistics about stored circuits"""
        query = """
        MATCH (desc:CircuitDescription)
        OPTIONAL MATCH (desc)-[:HAS_COMPONENT]->(comp:ComponentNode)
        OPTIONAL MATCH (desc)-[:HAS_NET]->(net:NetNode)
        RETURN desc.title as title, 
               desc.confidence_score as confidence,
               count(DISTINCT comp) as num_components,
               count(DISTINCT net) as num_nets
        """
        results = list(self.memgraph.execute_and_fetch(query))
        
        print("\n📈 Circuit Knowledge Base Statistics:")
        print("=" * 70)
        for result in results:
            print(f"  {result['title']}")
            print(f"    Confidence: {result['confidence']:.2f}")
            print(f"    Components: {result['num_components']}, Nets: {result['num_nets']}")
        print("=" * 70)
        
        return results
    
    def visualize_circuit(self, title: str):
        """Generate Cypher query to visualize in Memgraph Lab"""
        query = f"""
        MATCH (desc:CircuitDescription {{title: '{title}'}})-[:HAS_COMPONENT]->(comp:ComponentNode)
        OPTIONAL MATCH (comp)-[:COMPONENT_HAS_PIN]->(pin:PinRefNode)-[:CONNECTED_TO_NET]->(net:NetNode)
        RETURN desc, comp, pin, net
        """
        print(f"\n📊 Visualization query for '{title}':")
        print(query)
        print("\n👉 Copy this query to Memgraph Lab to visualize the circuit graph")
        return query
    
    def clear_database(self):
        """Clear all data from Memgraph"""
        self.memgraph.execute_and_fetch("MATCH (n) DETACH DELETE n")
        print("✓ Database cleared")
    
    def bulk_load_circuits_to_memgraph(self, json_file_path: str) -> Dict:

        import json
        
        print(f"\n{'='*70}")
        print("BULK LOADING CIRCUITS TO MEMGRAPH")
        print(f"{'='*70}\n")
        
        # Load JSON file
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Handle different JSON structures
        if isinstance(data, list):
            circuits = data
        elif isinstance(data, dict) and 'circuits' in data:
            circuits = data['circuits']
        else:
            circuits = [data]
        
        total_circuits = len(circuits)
        print(f"Found {total_circuits} circuits in {json_file_path}\n")
        
        successfully_stored = 0
        failed = 0
        circuit_ids = []
        errors = []
        
        for idx, circuit_json in enumerate(circuits, 1):
            circuit_name = circuit_json.get('title', f'Circuit {idx}')
            
            try:
                print(f"[{idx}/{total_circuits}] Loading: {circuit_name}")
                
                # Convert JSON to CircuitSpec format
                # Import from YOUR actual file where these classes are defined
                # Replace this import with your actual import statement
                # For example: from circuit_models import Component, Net, PinRef, CircuitSpec
                
                # Parse components
                components = []
                for comp in circuit_json.get('components', []):
                    components.append(Component(
                        ref=comp['ref'],
                        type=comp['type'],
                        part_number=comp.get('part_number') or comp.get('footprint'),
                        value=comp.get('value'),
                        metadata=comp.get('metadata', [])
                    ))
                
                # Parse nets
                nets = []
                for net in circuit_json.get('nets', []):
                    connected_pins = [
                        PinRef(
                            component_ref=pin['component_ref'],
                            pin_number=pin.get('pin') or pin.get('pin_number', ''),
                            pin_name=pin.get('pinfunction') or pin.get('pin_name'),
                            pin_direction=pin.get('pintype') or pin.get('pin_direction')
                        )
                        for pin in net.get('connected_pins', [])
                    ]

                    nets.append(Net(
                        name=net['name'],
                        net_type=net.get('net_type', 'signal'),   # ← dict key access
                        connected_pins=connected_pins
                    ))
                
                # Create CircuitSpec
                spec = CircuitSpec(
                    title=circuit_json.get('title', ''),
                    description=circuit_json.get('description', ''),
                    components=components,
                    nets=nets,
                    confidence_score=circuit_json.get('confidence_score', 0.95),
                    needs_validation=False,
                    checklist=[]
                )
                
                # Store in Memgraph
                desc_id = memgraph.store_circuit_spec(spec)
                circuit_ids.append(desc_id)
                successfully_stored += 1
                
                print(f"  ✓ Stored (ID: {desc_id})\n")
                
            except Exception as e:
                import traceback
                failed += 1
                error_info = {
                    "circuit": circuit_name,
                    "index": idx,
                    "error": str(e)
                }
                errors.append(error_info)
                print(f"  ✗ Failed: {str(e)}")
                traceback.print_exc()   # ← prints full stack trace
                print()
        
        # Print summary
        print(f"{'='*70}")
        print("BULK LOAD SUMMARY")
        print(f"{'='*70}")
        print(f"Total Circuits:        {total_circuits}")
        print(f"Successfully Stored:   {successfully_stored}")
        print(f"Failed:                {failed}")
        print(f"{'='*70}\n")
        
        # Show knowledge base statistics
        if successfully_stored > 0:
            print("Updated Knowledge Base Statistics:")
            memgraph.get_statistics()
            set_dirty(self.memgraph)
        
        return {
            "total_circuits": total_circuits,
            "successfully_stored": successfully_stored,
            "failed": failed,
            "circuit_ids": circuit_ids,
            "errors": errors
        } 
    


    # ▼▼▼ ADDED FOR SUBCIRCUITS ▼▼▼
    def store_subcircuit(self, parent_desc_id: int, subcircuit_json: dict) -> int:
        """
        Store a sub-circuit derived from an already-stored parent circuit.
        Does NOT create new ComponentNodes — only COMPOSED_OF_COMPONENT edges
        pointing to existing nodes in the parent circuit.

        Args:
            parent_desc_id: desc_id of the parent CircuitDescription node
            subcircuit_json: dict with keys: title, description, components, nets
                             Same structure as the main circuit JSON.
        Returns:
            sub_id: ID of the created SubCircuitDescription node
        """
        name        = subcircuit_json.get('title', 'Unnamed Sub-circuit')
        description = subcircuit_json.get('description', '')
        confidence  = subcircuit_json.get('confidence_score', 0.95)

        print(f"\n💾 Storing sub-circuit '{name}' (parent ID: {parent_desc_id})...")

        embedding = self.get_embedding(description)

        sub_node = SubCircuitDescription(
            name=name,
            description=description,
            embedding=embedding,
            source_circuit_id=parent_desc_id,
            created_at=str(np.datetime64('now')),
            confidence_score=confidence
        ).save(self.memgraph)

        print(f"  ✓ Created SubCircuitDescription node (ID: {sub_node._id})")

        # HAS_SUBCIRCUIT edge: parent CircuitDescription → SubCircuitDescription
        self.memgraph.execute("""
            MATCH (desc:CircuitDescription), (sub:SubCircuitDescription)
            WHERE ID(desc) = $desc_id AND ID(sub) = $sub_id
            CREATE (desc)-[:HAS_SUBCIRCUIT]->(sub)
        """, {'desc_id': parent_desc_id, 'sub_id': sub_node._id})

        # COMPOSED_OF_COMPONENT edges — look up existing ComponentNode by ref
        comp_found   = 0
        comp_missing = 0
        for comp in subcircuit_json.get('components', []):
            ref = comp['ref']
            results = list(self.memgraph.execute_and_fetch("""
                MATCH (desc:CircuitDescription)-[:HAS_COMPONENT]->(c:ComponentNode {ref: $ref})
                WHERE ID(desc) = $desc_id
                RETURN ID(c) AS comp_id
            """, {'desc_id': parent_desc_id, 'ref': ref}))

            if not results:
                print(f"  ⚠️  Component '{ref}' not found in parent — skipping")
                comp_missing += 1
                continue

            self.memgraph.execute("""
                MATCH (sub:SubCircuitDescription), (c:ComponentNode)
                WHERE ID(sub) = $sub_id AND ID(c) = $comp_id
                CREATE (sub)-[:COMPOSED_OF_COMPONENT]->(c)
            """, {'sub_id': sub_node._id, 'comp_id': results[0]['comp_id']})
            comp_found += 1

        print(f"  ✓ COMPOSED_OF_COMPONENT edges: {comp_found} created, {comp_missing} missing")
        print(f"  ✅ Sub-circuit '{name}' stored (ID: {sub_node._id})\n")
        return sub_node._id

    def get_subcircuits_for_circuit(self, parent_desc_id: int, query_embedding: Optional[List[float]] = None) -> List[Dict]:
        """
        Returns all SubCircuitDescription nodes linked to a parent circuit.
        Traverses COMPOSED_OF_COMPONENT → ComponentNode → pins → NetNode
        to collect component refs and net names.
        Filters net pins to only those belonging to sub-circuit components.

        Args:
            parent_desc_id: desc_id of the parent CircuitDescription
            query_embedding: optional embedding to compute a 'similarity' score
                              per subcircuit via cosine similarity against
                              the subcircuit's stored embedding.
        Returns:
            List of dicts: {name, description, component_refs, nets, similarity}
            where nets is a list of {name, net_type, internal_pins}
        """
        # Step 1: get all subcircuits and their component refs for this parent
        rows = list(self.memgraph.execute_and_fetch("""
            MATCH (desc:CircuitDescription)-[:HAS_SUBCIRCUIT]->(sub:SubCircuitDescription)
            WHERE ID(desc) = $desc_id
            OPTIONAL MATCH (sub)-[:COMPOSED_OF_COMPONENT]->(c:ComponentNode)
            RETURN ID(sub) AS sub_id,
                   sub.name AS name,
                   sub.description AS description,
                   sub.embedding AS embedding,
                   collect(DISTINCT c.ref) AS component_refs
        """, {'desc_id': parent_desc_id}))

        subcircuits = []
        for row in rows:
            sub_id         = row['sub_id']
            component_refs = set(row['component_refs'])

            # Step 2: traverse components → pins → nets
            net_rows = list(self.memgraph.execute_and_fetch("""
                MATCH (sub:SubCircuitDescription)-[:COMPOSED_OF_COMPONENT]->(c:ComponentNode)
                      -[:COMPONENT_HAS_PIN]->(pin:PinRefNode)
                      -[:CONNECTED_TO_NET]->(n:NetNode)
                WHERE ID(sub) = $sub_id
                RETURN n.name     AS net_name,
                       n.net_type AS net_type,
                       pin.component_ref AS comp_ref,
                       pin.pin_number    AS pin_number,
                       pin.pin_name      AS pin_name,
                       pin.pin_direction AS pin_direction
            """, {'sub_id': sub_id}))

            # Step 3: group by net, filter pins to internal components only            
            nets_dict = {}
            for nr in net_rows:
                if nr['comp_ref'] not in component_refs:
                    continue                          # external pin — skip
                net_name = nr['net_name']
                if net_name not in nets_dict:
                    nets_dict[net_name] = {
                        'name':           net_name,
                        'net_type':       nr['net_type'],
                        'internal_pins':  []
                    }
                nets_dict[net_name]['internal_pins'].append({
                    'component_ref': nr['comp_ref'],
                    'pin_number':    nr['pin_number'],
                    'pin_name':      nr['pin_name'],
                    'pin_direction': nr['pin_direction'],
                })

        
            # keep all nets — signal, power, and ground
            signal_nets = list(nets_dict.values())


            sim_score = None
            if query_embedding and row.get('embedding'):
                sim_score = _cosine(query_embedding, row['embedding'])

            subcircuits.append({
                'name':           row['name'],
                'description':    row['description'],
                'component_refs': list(component_refs),
                'nets':           signal_nets,
                'similarity':     sim_score,

            })

        return subcircuits
    # ▲▲▲ ADDED FOR SUBCIRCUITS ▲▲▲



# %%
# ─────────────────────────────────────────────────────────────
# GraphRAG Traversal Tools
# ─────────────────────────────────────────────────────────────

# ── Helpers ────────────────────────────────────────────


def _embed(text: str, client: OpenAI) -> List[float]:
    return client.embeddings.create(
        model="text-embedding-3-small",
        input=text
    ).data[0].embedding

def _cosine(a: List[float], b: List[float]) -> float:
    va, vb = np.array(a, dtype=float), np.array(b, dtype=float)
    denom = np.linalg.norm(va) * np.linalg.norm(vb)
    return float(np.dot(va, vb) / denom) if denom > 0  else 0.0

# ── Tool 1: find_similar_patterns ──────────────────────

def find_similar_patterns(query: str, db, openai_client: OpenAI, top_k: int = 2) -> List[Dict]:
    """
    Embeds query text and compares against embedded PatternNode names.
    Also fetches structural_embedding from each PatternNode for use in Tool 5.
    Returns top-k {name, similarity, structural_embedding} dicts.
    """
    query_emb = _embed(query, openai_client)
    patterns = list(db.execute_and_fetch(
        "MATCH (p:PatternNode) RETURN p.name AS name, p.structural_embedding AS struct_emb"
    ))
    scored = []
    for row in patterns:
        name_emb = _embed(row['name'], openai_client)
        sim = _cosine(query_emb, name_emb)
        scored.append({'name': row['name'], 'similarity': sim,
                       'structural_embedding': row.get('struct_emb')})
    scored.sort(key=lambda x: x['similarity'], reverse=True)
    return scored[:top_k]

# ── Tool 2: fetch_circuits_with_pattern ──────────────────

def fetch_circuits_with_pattern(pattern_name: str, db, top_k: int = 3) -> List[Dict]:
    """Returns up to top_k circuits that contain the given pattern."""
    results = list(db.execute_and_fetch(
        "MATCH (d:CircuitDescription)-[:CONTAINS_PATTERN]->(p:PatternNode {name: $name}) "
        "RETURN d.title AS title, ID(d) AS desc_id",
        {'name': pattern_name}
    ))
    return [{'title': r['title'], 'desc_id': r['desc_id']} for r in results[:top_k]]

# ── Tool 3: expand_net_neighbors ─────────────────────────

def expand_net_neighbors(desc_id: int, net_name: str, db) -> Dict:
    """
    Returns all components connected to a specific net.
    Implemented but not called in the fixed pipeline — available for future use.
    """
    results = list(db.execute_and_fetch("""
        MATCH (d)-[:HAS_NET]->(net:NetNode {name: $net_name})
            <-[:CONNECTED_TO_NET]-(pin:PinRefNode)
            <-[:COMPONENT_HAS_PIN]-(comp:ComponentNode)
        WHERE ID(d) = $desc_id
        RETURN comp.ref AS ref, comp.type AS type,
               pin.pin_number AS pin_number, pin.pin_name AS pin_name
    """, {'desc_id': desc_id, 'net_name': net_name}))
    return {
        'net_name': net_name,
        'connections': [{'ref': r['ref'], 'type': r['type'],
                         'pin_number': r['pin_number'], 'pin_name': r['pin_name']}
                        for r in results]
    }

# ── Tool 4: get_component_spec ───────────────────────────

def get_component_spec(desc_id: int, component_ref: str, db) -> Dict:
    """Returns full component details including all connected pins."""
    comp_results = list(db.execute_and_fetch(
        "MATCH (d)-[:HAS_COMPONENT]->(c:ComponentNode {ref: $ref}) "
        "WHERE ID(d) = $desc_id RETURN c",
        {'desc_id': desc_id, 'ref': component_ref}
    ))
    if not comp_results:
        return {}
    comp = comp_results[0]['c']._properties
    pin_results = list(db.execute_and_fetch("""
        MATCH (d)-[:HAS_COMPONENT]->(c:ComponentNode {ref: $ref})
              -[:COMPONENT_HAS_PIN]->(pin:PinRefNode)
        WHERE ID(d) = $desc_id
        RETURN pin.pin_number AS pin_number, pin.pin_name AS pin_name,
               pin.pin_direction AS pin_direction
    """, {'desc_id': desc_id, 'ref': component_ref}))
    return {
        'ref': comp.get('ref'), 'type': comp.get('type'),
        'part_number': comp.get('part_number'), 'value': comp.get('value'),
        'metadata': comp.get('metadata'),
        'pins': [{'pin_number': r['pin_number'], 'pin_name': r['pin_name'],
                  'pin_direction': r['pin_direction']} for r in pin_results]
    }

# ── Tool 5: find_structurally_similar_circuits ───────────────

def find_structurally_similar_circuits(
    query: str, db, openai_client: OpenAI,
    top_k: int = 3,
    reference_structural_emb: Optional[List[float]] = None,
    query_embedding: Optional[List[float]] = None,
    circuits_only: bool = False   # if False, also include SubCircuitDescription nodes in results
) -> List[Dict]:
    """
    Combined text + structural similarity retrieval.
    Score = 0.6 * text_sim + 0.4 * structural_sim.
    reference_structural_emb: 16-d embedding from the top matched PatternNode,
    used as a structural proxy for the query topology.
    Falls back to text-only score if not provided or circuit has no structural_embedding.
    """
    query_emb = query_embedding if query_embedding is not None else _embed(query, openai_client)
    circuits = list(db.execute_and_fetch(
        "MATCH (d:CircuitDescription) "
        "RETURN ID(d) AS desc_id, d.title AS title, "
        "d.embedding AS embedding, d.structural_embedding AS structural_embedding"
    ))
    scored = []
    for row in circuits:
        text_emb = row.get('embedding')
        if not text_emb:
            continue
        text_sim = _cosine(query_emb, text_emb)
        struct_emb = row.get('structural_embedding')
        if struct_emb and reference_structural_emb:
            score = 0.6 * text_sim + 0.4 * _cosine(reference_structural_emb, struct_emb)
        else:
            score = text_sim

        # ▼▼▼ ADDED FOR SUBCIRCUITS  both type and parent title
        scored.append({'title': row['title'], 'similarity': score, 'desc_id': row['desc_id'],'type':'circuit' , 'parent_title': None})
         # also score SubCircuitDescription embeddings

    if not circuits_only:
            subcircuits = list(db.execute_and_fetch(
                "MATCH (d:CircuitDescription)-[:HAS_SUBCIRCUIT]->(sub:SubCircuitDescription) "
                "RETURN ID(sub) AS desc_id, sub.name AS title, "
                "sub.embedding AS embedding, d.title AS parent_title"
            ))

            for row in subcircuits:
                text_emb = row.get('embedding')
                if not text_emb:
                    continue
                score = _cosine(query_emb, text_emb)
                scored.append({
                    'title':        row['title'],
                    'similarity':   score,
                    'desc_id':      row['desc_id'],
                    'type':         'subcircuit',    # marks this as a sub-circuit
                    'parent_title': row['parent_title'],
                })
    # ▲▲▲ ADDED FOR SUBCIRCUITS ▲▲▲
    scored.sort(key=lambda x: x['similarity'], reverse=True)
    return scored[:top_k]

# ── AgenticTraversalAgent ─────────────────────────────────

class AgenticTraversalAgent:
    """
    Fixed-order retrieval pipeline for PCB schematic generation.
    Replaces rag_retrieval_node internals in Milestone 5.
    """

    def __init__(self, db, openai_client: OpenAI, memgraph_manager=None ,retrieval_mode: str = 'approach2'):
        self.db = db
        self.client = openai_client
        self.memgraph_manager = memgraph_manager  # CircuitMemgraph; used for _reconstruct_circuit_spec
        self.retrieval_mode = retrieval_mode # approach 2 : treat circuits & sub the same, approach 1: reterive subcircuits as a part of the main circuit retrieval

    def run(self, user_request: str) -> str:
        """
        Fixed-order pipeline:
        1. find_similar_patterns
        2. fetch_circuits_with_pattern for each pattern (top_k)
        3. find_structurally_similar_circuits (top pattern struct_emb as proxy)
        4. [skipped — expand_net_neighbors available for future use]
        5. Format context string matching current rag_retrieval_node output format
        """
        # Step 1
        query_embedding = _embed(user_request, self.client)

        patterns = find_similar_patterns(user_request, self.db, self.client, top_k=2)
        

        # Step 2
        for p in patterns:
            fetch_circuits_with_pattern(p['name'], self.db, top_k=2)

        # Use top pattern's structural embedding as structural proxy for step 3
        top_struct_emb = next(
            (p['structural_embedding'] for p in patterns if p.get('structural_embedding')),
            None
        )

        # Step 3 :depening on choosen approach
        if self.retrieval_mode == 'approach1':
            similar_circuits = find_structurally_similar_circuits(
                user_request, self.db, self.client,
                top_k=1, reference_structural_emb=top_struct_emb,
                query_embedding=query_embedding,
                circuits_only=True   # only return full circuits
            )
        else: # approach 2 : retrieve sub-circuits as part of the main circuit retrieval        
            similar_circuits = find_structurally_similar_circuits(
                user_request, self.db, self.client,
                top_k=1, reference_structural_emb=top_struct_emb,
                query_embedding=query_embedding,
                circuits_only=False  # return mix of full circuits and sub-circuits
            )
        # ▼▼▼ ADDED FOR SUBCIRCUITS ▼▼▼
        print(f"\n📋 RAG Top-K Results ({len(similar_circuits)} returned):")
        for i, r in enumerate(similar_circuits, 1):
            result_type = r.get('type', 'circuit')
            if result_type == 'subcircuit':
                print(f"  {i}. [SUBCIRCUIT] '{r['title']}' (sim: {r['similarity']:.3f}) — part of: {r['parent_title']}")
            else:
                print(f"  {i}. [CIRCUIT]    '{r['title']}' (sim: {r['similarity']:.3f})")
        print()
        # ▲▲▲ ADDED FOR SUBCIRCUITS ▲▲▲
        
        # ▼▼▼ ADDED FOR SUBCIRCUITS ▼▼▼
        # Step 5 — format context string
        
        context = "=== SIMILAR CIRCUITS FROM KNOWLEDGE BASE ===\n\n"
        for idx, circuit_info in enumerate(similar_circuits, 1):
            desc_id     = circuit_info['desc_id']
            result_type = circuit_info.get('type', 'circuit')

            if result_type == 'subcircuit':
                # ── Approach 2 only: subcircuit as standalone result ──
                sc_rows = list(self.db.execute_and_fetch("""
                    MATCH (sub:SubCircuitDescription)-[:COMPOSED_OF_COMPONENT]->(c:ComponentNode)
                    WHERE ID(sub) = $sub_id
                    RETURN c.ref AS ref, c.type AS type,
                           c.part_number AS part_number, c.value AS value,
                           c.metadata AS metadata
                """, {'sub_id': desc_id}))

                net_rows = list(self.db.execute_and_fetch("""
                    MATCH (sub:SubCircuitDescription)-[:COMPOSED_OF_COMPONENT]->(c:ComponentNode)
                          -[:COMPONENT_HAS_PIN]->(pin:PinRefNode)
                          -[:CONNECTED_TO_NET]->(n:NetNode)
                    WHERE ID(sub) = $sub_id
                    RETURN n.name AS net_name, n.net_type AS net_type,
                           pin.component_ref AS comp_ref,
                           pin.pin_number AS pin_number,
                           pin.pin_name AS pin_name,
                           pin.pin_direction AS pin_direction
                """, {'sub_id': desc_id}))

                sub_comp_refs = {r['ref'] for r in sc_rows}
                nets_dict = {}
                for nr in net_rows:
                    if nr['comp_ref'] not in sub_comp_refs:
                        continue
                    net_name = nr['net_name']
                    if net_name not in nets_dict:
                        nets_dict[net_name] = {
                            'name':          net_name,
                            'net_type':      nr['net_type'],
                            'internal_pins': []
                        }
                    nets_dict[net_name]['internal_pins'].append({
                        'component_ref': nr['comp_ref'],
                        'pin_number':    nr['pin_number'],
                        'pin_name':      nr['pin_name'],
                        'pin_direction': nr['pin_direction'],
                    })

                context += (
                    f"--- Example {idx}: {circuit_info['title']} "
                    f"(similarity: {circuit_info['similarity']:.3f}) "
                    f"[Sub-circuit — contained inside: {circuit_info['parent_title']}] ---\n"
                )
                context += f"Components ({len(sc_rows)}):\n"
                for c in sc_rows:
                    context += f"- {c['ref']}:\n"
                    context += f"    type: {c['type']}\n"
                    context += f"    part_number: {c.get('part_number')}\n"
                    context += f"    value: {c.get('value')}\n"
                    context += f"    metadata: {c.get('metadata')}\n"
                for n in nets_dict.values():
                    context += f"- Net {n['name']} ({n['net_type']}):\n"
                    for pin in n['internal_pins']:
                        context += f"    {pin['component_ref']}.{pin['pin_number']} ({pin.get('pin_name')}) ({pin.get('pin_direction')})\n"

            else:
                # ── Both approaches: full circuit block ──
                circuit_data = self.memgraph_manager._reconstruct_circuit_spec(desc_id)
                desc_row = list(self.db.execute_and_fetch(
                    "MATCH (d:CircuitDescription) WHERE ID(d) = $desc_id "
                    "RETURN d.description AS description",
                    {'desc_id': desc_id}
                ))
                description = desc_row[0]['description'] if desc_row else ''

                context += (
                    f"--- Example {idx}: {circuit_info['title']} "
                    f"(similarity: {circuit_info['similarity']:.3f}) ---\n"
                )
                context += f"Description: {description}\n"
                context += f"Components ({circuit_data['stats']['num_components']}):\n"
                for c in circuit_data['components']:
                    context += f"- {c['ref']}:\n"
                    context += f"    type: {c['type']}\n"
                    context += f"    part_number: {c.get('part_number') or c.get('footprint')}\n"
                    context += f"    value: {c.get('value')}\n"
                    context += f"    metadata: {c.get('metadata')}\n"
                for n in circuit_data['nets']:
                    context += f"- Net {n['name']} ({n['net_type']}):\n"
                    for pin in n['connected_pins']:
                        context += f"    {pin['component_ref']}.{pin['pin_number']} ({pin.get('pin_name')}) ({pin.get('pin_direction')})\n"

                # ── Approach 1 only: annotate subcircuits under parent ──
                if self.retrieval_mode == "approach1":
                    subcircuits = self.memgraph_manager.get_subcircuits_for_circuit(
                        desc_id, query_embedding=query_embedding
                    )
                    print(f"  📎 Subcircuits for '{circuit_info['title']}': {len(subcircuits)} found")  # ← add this

                    if subcircuits:
                        context += f"\nSub-circuits ({len(subcircuits)}):\n"
                        for sc in subcircuits:
                            score_str = f" (similarity: {sc['similarity']:.3f})" if sc.get('similarity') is not None else ""
                            context += f"  - {sc['name']}{score_str}:\n"
                            context += f"      Description: {sc['description']}\n"
                            context += f"      Components: {', '.join(sc['component_refs'])}\n"
                            if sc['nets']:
                                context += f"      Internal nets:\n"
                                for n in sc['nets']:
                                    pins_str = ', '.join(
                                        f"{p['component_ref']}.{p['pin_number']}"
                                        for p in n['internal_pins']
                                    )
                                    context += f"        - {n['name']} ({n['net_type']}): {pins_str}\n"

        return context
        # ▲▲▲ ADDED FOR SUBCIRCUITS ▲▲▲


# %%

# ▼▼▼ ADDED FOR SUBCIRCUITS ▼▼▼
def load_subcircuits_from_json(
    subcircuits_json_path: str,
    parent_title: str,
    memgraph_manager: "CircuitMemgraph"
) -> Dict:
    """
    PoC loader: reads a pre-generated subcircuits JSON file (e.g. NANO33IoTV2_subcircuits.json)
    and stores each sub-circuit under the matching parent CircuitDescription.

    Use this instead of extract_subcircuits_with_llm when you already have
    the LLM output saved to disk.

    Args:
        subcircuits_json_path: path to the subcircuits JSON file
        parent_title:          title of the parent circuit as stored in Memgraph
                               (must match CircuitDescription.title exactly)
        memgraph_manager:      CircuitMemgraph instance

    Returns:
        dict with keys: total, stored, failed, sub_ids
    """
    import json

    print(f"\n{'='*60}")
    print(f"LOADING SUB-CIRCUITS FROM FILE")
    print(f"  File   : {subcircuits_json_path}")
    print(f"  Parent : {parent_title}")
    print(f"{'='*60}")

    # Look up parent CircuitDescription by title
    results = list(memgraph_manager.memgraph.execute_and_fetch("""
        MATCH (d:CircuitDescription {title: $title})
        RETURN ID(d) AS desc_id
    """, {'title': parent_title}))

    if not results:
        print(f"  ❌ Parent circuit '{parent_title}' not found in Memgraph.")
        print(f"     Make sure it was stored via store_circuit_spec first.")
        return {'total': 0, 'stored': 0, 'failed': 0, 'sub_ids': []}

    parent_desc_id = results[0]['desc_id']
    print(f"  ✓ Found parent circuit (ID: {parent_desc_id})")

    with open(subcircuits_json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    subcircuit_list = data.get('subcircuits', [])
    print(f"  ✓ Found {len(subcircuit_list)} sub-circuit(s) in file\n")

    total  = len(subcircuit_list)
    stored = 0
    failed = 0
    sub_ids = []

    for sc_json in subcircuit_list:
        try:
            sub_id = memgraph_manager.store_subcircuit(parent_desc_id, sc_json)
            sub_ids.append(sub_id)
            stored += 1
        except Exception as e:
            import traceback
            print(f"  ✗ Failed to store '{sc_json.get('title', '?')}': {e}")
            traceback.print_exc()
            failed += 1

    print(f"\n  Summary: {stored}/{total} sub-circuits stored, {failed} failed")
    print(f"{'='*60}\n")
    return {'total': total, 'stored': stored, 'failed': failed, 'sub_ids': sub_ids}
# ▲▲▲ ADDED FOR SUBCIRCUITS ▲▲▲



def add(left, right):
    """Can also import `add` from the `operator` built-in."""
    return left + right

_component_counter = count(12)  # starts at 12, increments forever

class PinRef(BaseModel):
    component_ref: str = Field(..., description="U1, R3, etc.")
    pin_number: str = Field(..., description="1,2,3,....")
    pin_name: Optional[str] = Field(None, description="B1, GND, etc.")
    pin_direction: Optional[str] = Field(..., description="INPUT, OUTPUT, INOUT")

class Component(BaseModel):
    ref: str = Field(default_factory=lambda: f"$1I{next(_component_counter)}")
    type: str = Field(..., description="Component category/type (e.g., resistor, capacitor, microcontroller)")
    part_number: Optional[str] = Field(..., description="Part number for the component")
    value: str | None
    metadata: Optional[List[str]] = Field(
        default_factory=list,
        description="Free-form metadata notes (key: value)"
    )
     
    
    # In Component model — validator uses pre-loaded set, never queries DB:
    @field_validator("part_number", mode="before")
    @classmethod
    def validate_part_number(cls, v, info):
        if not v:
            return v

        v_stripped = str(v).strip()

        # Use pre-loaded set — no DB query here
        if not _VALID_PART_NUMBERS:
            return v_stripped  # DB not loaded — pass through

        if v_stripped in _VALID_PART_NUMBERS:
            return v_stripped  # exact match ✓

        # Case-insensitive fallback
        v_upper = v_stripped.upper()
        for pn in _VALID_PART_NUMBERS:
            if pn.upper() == v_upper:
                return pn  # return correctly cased version ✓

        # Not in library — warn and return None
        print(
            f"  ⚠️  part_number '{v_stripped}' not in library — setting to None"
        )
        return None

    @field_validator("part_number", mode="after")
    @classmethod
    def check_required_part_number(cls, v, info):
        """
        Warn if part_number is None for non-symbol components.
        Does not raise — lets the spec through so checklist can handle it.
        """
        comp_type = info.data.get("type", "")
        ref       = info.data.get("ref", "?")
        # Only warn for ICs and active components — not passives
        if not v and comp_type not in SKIP_TYPES_pn:
            print(
                f"  ⚠️  Component '{ref}' ({comp_type}) has no valid part_number "
                f"— will appear as missing in checklist"
            )
        return v



class Net(BaseModel):
    name: str = Field(..., description="Net name — global name (e.g. GND, +5V) or signal name")
    net_type: str  # signal, power, ground
    connected_pins: List[PinRef]






class ChecklistItem(BaseModel):
    """Represents a single item requiring human validation"""
    type: Literal["missing", "low_confidence", "alternatives"] = Field(
        ..., 
        description="'missing' for unavailable info, 'low_confidence' for items with confidence < 0.85, 'alternatives' for items with multiple options"
    )
    question: str = Field(
        ..., 
        description="Clear question with at least 3 recommended options with pros/cons"
    )
  
    category: str = Field(
        ..., 
        description="Category: 'component_selection', 'power_supply', 'support_components', 'calculations', etc."
    )
    current_value: Optional[str] = Field(
        None, 
        description="Current value if available (for low_confidence items)"
    )
    confidence: Optional[float] = Field(
        None, 
        ge=0.0, 
        le=1.0, 
        description="Confidence score for this specific item (only for low_confidence type)"
    )
    priority: int = Field(
        ...,
        description="Lower number = higher priority (1 is most urgent)"
    )
    rationale: Optional[str] = Field(
        None,
        description="Why this issue should be addressed early"
    )
    
class CircuitSpec(BaseModel):
    title: str
    description: str
    components: List[Component]
    nets: List[Net]
    confidence_score: float = Field(..., ge=0.0, le=1.0)
    needs_validation: bool
    # GROUPED CHECKLIST
    checklist: List[ChecklistItem] = Field(
        default_factory=list,
        description="Grouped alternatives and issues as actionable checklist items"
    )

class StructuralIssue(BaseModel):
    code: str
    message: str
  
from typing import TypedDict, Optional

class GraphState(TypedDict):
    raw_description: str
    spec: Optional[CircuitSpec]
    feedback: Annotated[List[str], add]
    confidence_threshold: Optional[float]=0.85
    retrieved_examples: Optional[str] 
    iteration_count: Optional[int]
    structural_issues: Optional[List[StructuralIssue]]
    import_status:  str          # "ok" | "failed" | "skipped"
    import_message: str
    edn_path:             Optional[str]   
    drc_result:           Optional[Dict]
    drc_summary:          Optional[str]
    verification_verdict: Optional[str]
    drc_instructions:     Optional[str]   # most recent DRC fix — no reducer, replaced each cycle
    from_rag: Optional[bool] 
    chatMode:Optional[str]


THREAD_ID = str(uuid.uuid4())

config = {
    "configurable": {
        "thread_id": THREAD_ID
    }
}





# %%

memgraph = CircuitMemgraph()
client = OpenAI()

# ── Pattern mining ─────────────────────────────────────────
summary = run_pattern_mining_pipeline(
    db=memgraph.memgraph,     
    openai_client=client,
    min_cooccurrence=2
)

if summary.get("status") == "complete":
    clear_dirty(memgraph.memgraph)  

print(f"\nDone: {summary}")

# ── Agent ──────────────────────────────────────────────────
agent = AgenticTraversalAgent(
    db=memgraph.memgraph,
    openai_client=client,
    memgraph_manager=memgraph,
    retrieval_mode='approach2'   # set to 'approach1' to treat sub-circuits as part of main circuit, 'approach2' to retrieve sub-circuits as standalone results
)
print(f"🔀 Retrieval mode active: {agent.retrieval_mode}")



# %%


@tool
def search_component_datasheet(component_name: str, specific_query: str = None) -> str:
    """
    Search for component datasheet information.
    Priority: persistent cache → lib_merged.db datasheet URL → Tavily.
    Tavily is only called when the library has no datasheet URL for this part.

    Args:
        component_name: Part number or component name (e.g. "ATMEGA328-AUR", "FT232RL")
        specific_query: What you need (e.g. "pinout", "typical application circuit",
                        "max input voltage"). Optional — full specs returned either way.
    """
    suffix = f"\n\nExtract from above: {specific_query}" if specific_query else ""
    
    # ── 1. Persistent cache ────────────────────────────────────────────────────
    cached = _cache_get(component_name)
    if cached:
        print(f"✅ [CACHE HIT] {component_name} (source: {cached['source']})")
        return cached["raw_text"] + suffix

    # ── 2. Check lib_merged.db for a datasheet URL ─────────────────────────────
    datasheet_url = None
    lib_results = search_library_db(
        query   = component_name,
        db_path = LIBRARY_DB,
        top_k   = 1,
    )
    if lib_results:
        url_candidate = lib_results[0].get("datasheet", "")
        if url_candidate and url_candidate not in ("N/A", "", "None"):
            datasheet_url = url_candidate

    # ── 2b. If URL found, fetch it directly — skip Tavily entirely ─────────────
    if datasheet_url:
        print(f"📄 [LIB URL] {component_name} → {datasheet_url}")
        try:
            resp = requests.get(datasheet_url, timeout=15)
            resp.raise_for_status()

            content_type = resp.headers.get("Content-Type", "")

            if "pdf" in content_type.lower() or datasheet_url.lower().endswith(".pdf"):
                # PDF — extract text with pdfminer so the LLM gets readable content
                from pdfminer.high_level import extract_text
                import io
                raw_content = extract_text(io.BytesIO(resp.content))
                raw_content = _truncate(raw_content, max_chars=3600)
            else:
                # HTML / plain text
                raw_content = _truncate(resp.text, max_chars=3600)

            raw_text = (
                f"=== {component_name} Datasheet (source: library URL) ===\n"
                f"URL: {datasheet_url}\n\n"
                f"{raw_content}"
            )
            _cache_set(component_name, raw_text, source="lib_url", datasheet_url=datasheet_url)
            return raw_text + suffix

        except Exception as e:
            # Fetch failed — log and fall through to Tavily
            print(f"⚠️  [LIB URL FAILED] {datasheet_url}: {e} — falling back to Tavily")

    # ── 3. Tavily — only reached when lib has no URL or fetch failed ───────────
    print(f"🌐 [TAVILY] {component_name} — no library URL found")
    query   = f"{component_name} datasheet pinout footprint typical application circuit specifications"
    results = tavily_search.invoke({"query": query})

    if not results:
        raw_text = f"No datasheet information found for {component_name}."
    else:
        lines = [f"=== {component_name} Datasheet (source: Tavily) ===\n"]
        if datasheet_url:
            lines.append(f"Datasheet URL: {datasheet_url}\n")
        for idx, result in enumerate(results, 1):
            content = _truncate(result.get("content", ""), max_chars=1200)
            url     = result.get("url", "")
            lines.append(f"{idx}. {content}\n   URL: {url}\n")
        raw_text = "\n".join(lines)

    # ── 4. Cache the Tavily result ─────────────────────────────────────────────
    _cache_set(
        component_name = component_name,
        raw_text       = raw_text,
        source         = "db+tavily" if datasheet_url else "tavily",
        datasheet_url  = datasheet_url,
    )
    return raw_text + suffix

# %%


llm = ChatAnthropic(model='claude-sonnet-4-5', temperature=0)
llm_with_tools = llm.bind_tools([search_component_datasheet, search_library_batch])
spec_llm = llm_with_tools.with_structured_output(CircuitSpec)

class VerificationVerdict(BaseModel):
    verdict:      Literal["FIX", "BLOCK", "WARNING"]
    reason:       str
    instructions: str = ""

llm_verifier        = ChatAnthropic(model='claude-haiku-4-5-20251001', temperature=0)
structured_verifier = llm_verifier.with_structured_output(VerificationVerdict)


# %%
tavily_search = TavilySearchResults(
        max_results    = 3,
        search_depth   = "advanced",
        include_answer = True,
    )
def _truncate(text: str, max_chars: int = 3600) -> str:
    """Truncate text to max_chars while preserving word boundaries."""
    if len(text) <= max_chars:
        return text
    truncated = text[:max_chars]
    last_space = truncated.rfind(' ')
    if last_space > 0:
        truncated = truncated[:last_space]
    return truncated + "..."
def generate_spec_with_tools(
    circuit_description: str,
    confidence_threshold: float,
    rag_examples: str = None,
    structural_issues: str = None,
    max_iterations: int = 3,
    state: GraphState = None,
) -> CircuitSpec:
    """
    Generate specification with autonomous tool calling.
    LLM can call search_component_datasheet and search_library as needed.
    """
    rag_context = ""
    if rag_examples:
        rag_context = f"""

REFERENCE EXAMPLES FROM DATABASE (FOR LEARNING PATTERNS ONLY):

The following circuits are PROVIDED AS ABSTRACT DESIGN EXAMPLES.

STRICT RULES:
- Make use of component values, footprints, part numbers, nets, pins in inspiration rag examples
- Treat all component choices as EXAMPLES, not defaults.
- Extract:
  • common topology patterns
  • typical support component roles
  • net naming conventions
  • functional relationships BETWEEN COMPONENTS

If a reference example suggests a component, you MUST:
- Either verify its function using search_component_datasheet
- OR propose it as an ALTERNATIVE in the checklist for user selection

- understand how similar problems are structured
- suggest reasonable OPTIONS to the user
- avoid missing required support components

- Think independently FIRST, then consult examples for validation
- If examples conflict with your analysis: explain the discrepancy
- If examples are missing something you identified: include it anyway
Use them as design inspiration and pattern recognition, never as copy-paste templates.

REFERENCE EXAMPLES:
{rag_examples}
"""

    system_msg = f"""You are an expert PCB and schematic engineer familiar with PADS Pro.
Convert circuit descriptions into a strict JSON specification as connectivity JSON.
{LIBRARY_SYSTEM_ADDITION}

Also, YOU HAVE ACCESS TO A DATASHEET SEARCH TOOL: search_component_datasheet
- Use it AUTOMATICALLY when you need component specifications
- Use it for: pinouts, footprint, voltage ranges, current ratings, typical circuits,
  recommended support components, values

REQUIREMENTS:

1. If user's answer is vague or they don't know, complete the spec with reasonable
   defaults (use tool to verify).

2. NULL VALUES: If you find ANYTHING that is null, either:
   a) Use the search tool to find the correct value, OR
   b) Mark it as low_confidence in checklist 
   
3. CRITICAL CONNECTION RULES (MANDATORY)
    a) LED drive MUST follow this exact topology:
    IC output pin → current limiting resistor → LED Anode → LED Cathode → GND
       
    b) PIN UNIQUENESS — ONE PIN ONE NET (MANDATORY)
    Each (component_ref, pin_number) pair MUST appear on EXACTLY ONE net.

    BEFORE WRITING NETS:
    Keep a running list of every (component_ref, pin_number) used.
    If a pin is already on a net → do NOT add it to another net.


    c) CRITICAL: SHORT CIRCUIT PREVENTION (MANDATORY)
    A short circuit occurs when the same pin appears on two different nets.

    VALIDATION STEP (mandatory before output):
    For every net:
        Step 1: Does any (component_ref, pin_number) already appear on a previous net?
                YES → remove it from this net
        Step 2: Does this net connect at least 2 DIFFERENT components?
                NO  → remove this net entirely
        Step 3: Does any component have both pins on the same net?
                YES → fix the net assignment

    d) There must be ONE ground net (GND) in the design.
    unless the description explicitly requires separate ground planes.
    If a component's ground pin is not in the GND net → add it to GND net.

    CRITICAL: GND AND POWER ARE NETS, NOT COMPONENTS 

    GND, VCC,..  are NET NAMES — not components.

    HOW TO CONNECT GROUND:
    1. Every component that needs GND must have a pin explicitly on the GND net

    HOW TO CONNECT POWER:
    1. The power source (connector, regulator) provides the rail
    2. Every component needing that rail connects its power pin to that net
    3. Never use "VCC" or "3V3" as a component_ref — they are net names only


4. NET CONNECTION RULES:
- Nets connect component pins only, never other nets
- If you want to connect to another net:
  1. Find a component whose pin is on that net (resistor, cap, connector)
  2. Reference that component's pin
  3. The net name itself handles the connection

5. CRITICAL RULES:
   - Never use component_ref that doesn't exist in components[]
   - Every component must connect to at least one net
   - Every net must have at least 2 pins
   - Connect all pins logically based on circuit function
   - Every component in components[] MUST connect to at least one net

6. CALCULATIONS: Make ALL necessary calculations (current, voltage drops, power,
   resistor/capacitor values).

7. SUPPORT COMPONENTS: include for each IC/module:
   - Decoupling capacitors
   - Pull-up/pull-down resistors where needed
   - Voltage dividers if required
   - Reset circuitry for microcontrollers

{rag_context}

8. CHECKLIST ITEMS - Create when missing or low confidence:
   - "type": "missing" or "low_confidence" or "alternatives" 
   - use "alternatives" only when component is not found in library
   - "question": clear question with AT LEAST 3 OPTIONS WITH PROS
   - "category": component_selection, power_supply, support_components, calculations
   - "current_value": current value (for low_confidence)
   - "confidence": score (for low_confidence)

MANDATORY: Every component_ref in connected_pins MUST exist in components[].ref

VALIDATION BEFORE OUTPUT:
1. List all component refs from components[]
2. For EVERY connected_pins entry, verify component_ref is in that list
3. If NOT in list → you MUST either:
   a) Add a real component with that ref to components[], OR
   b) Remove that pin reference entirely

NO EXCEPTIONS. Every component_ref MUST be findable in components[].

9. CONFIDENCE
CONFIDENCE_THRESHOLD = {confidence_threshold}

IMPORTANT:
- Treat CONFIDENCE_THRESHOLD as a numeric constant.
- Apply confidence rules strictly using this value.
CONFIDENCE_SCORE in spec (STRICT, NUMERIC RULES):

The confidence_score MUST be set according to the checklist status.
These rules are MANDATORY and MUST NOT be violated.

Use the following exact values:

A) If checklist contains ANY item of type "missing":
   → confidence_score = 0.60

B) Else if checklist contains ANY item of type "alternatives":
   → confidence_score = 0.70

C) Else if checklist contains ANY item of type "low_confidence":
   → confidence_score = 0.80

D) ONLY if checklist is EMPTY:
   → confidence_score MUST be one of:
      - 0.85  (reasonable assumptions, typical values)
      - 0.90  (mostly datasheet-backed)
      - 0.95  (fully datasheet/reference-design backed)

DO NOT use any other confidence values.
DO NOT output confidence_score >= confidence_threshold when checklist is NOT empty.

10. RESOLVED DECISIONS RULE (GLOBAL):
If the human explicitly answers a question or selects an option,
that decision is considered FINAL and RESOLVED.
The model MUST:
- Treat it as ground truth
- Apply it directly to the spec
- NEVER re-ask the same question in different wording
- NEVER request reconfirmation unless new conflicting information appears

11. NEEDS_VALIDATION (DETERMINISTIC):
Set needs_validation = true IF AND ONLY IF:
- checklist is NOT empty OR confidence_score < confidence_threshold

Set needs_validation = false ONLY IF:
- checklist is EMPTY AND confidence_score >= confidence_threshold

12. For each checklist item:
- Assign a priority (1 = most urgent)
- more than 1 item can have same priority
- Use priority to reflect electrical correctness, safety, and completeness

Only output valid JSON matching the provided schema."""

    messages = [
        SystemMessage(content=system_msg),
        HumanMessage(content=circuit_description),
    ]

    iteration      = 0
    tool_call_log  = []   # track all tool calls for summary

    # ── Tool-calling loop ──────────────────────────────────────────────────────
    while iteration < max_iterations:
        print(f"\n🤖 LLM iteration {iteration + 1}/{max_iterations}")
        response = llm_with_tools.invoke(messages)

        if hasattr(response, "tool_calls") and response.tool_calls:
            n = len(response.tool_calls)
            print(f"🔧 LLM requesting {n} tool call{'s' if n > 1 else ''}:")

            messages.append(response)

            for tool_call in response.tool_calls:
                tool_name = tool_call["name"]
                tool_args = tool_call["args"]
                tool_id   = tool_call["id"]

                # ── search_component_datasheet ─────────────────────────────
                if tool_name == "search_component_datasheet":
                    comp     = tool_args.get("component_name", "")
                    specific = tool_args.get("specific_query", "")
                    arg_str  = f"'{comp}'"
                    if specific:
                        arg_str += f" | query='{specific}'"

                    # Check cache status BEFORE invoking
                    from sqlit_lib_tool import _normalize_component
                    import sqlite3
                    cache_hit = False
                    try:
                        conn = sqlite3.connect(LIBRARY_DB)
                        row  = conn.execute(
                            "SELECT source, created_at FROM datasheet_cache "
                            "WHERE component_name = ?",
                            (_normalize_component(comp),)
                        ).fetchone()
                        conn.close()
                        if row:
                            cache_hit = True
                            cache_source = row[0]
                            cache_date   = row[1][:10] if row[1] else "?"
                    except Exception:
                        pass

                    if cache_hit:
                        print(f"  🔍 search_component_datasheet({arg_str})")
                        print(f"     ✅ [CACHE HIT] source={cache_source} cached={cache_date}")
                    else:
                        print(f"  🔍 search_component_datasheet({arg_str})")
                        print(f"     🌐 [TAVILY] fetching from web...")

                    tool_result = search_component_datasheet.invoke(tool_args)

                    # Show first 2 lines of result as preview
                    result_preview = "\n".join(
                        tool_result.split("\n")[:4]
                    ).strip()
                    print(f"     Preview: {result_preview[:120]}...")

                   # Check if result starts with cache indicator
                    cache_hit_actual = "CACHE HIT" in tool_result or "DB DATASHEET" in tool_result

                    tool_call_log.append({
                        "tool":      "search_component_datasheet",
                        "args":      arg_str,
                        "cache_hit": cache_hit_actual,   # ← use actual result not pre-check
                    })

                # ── search_library_batch ───────────────────────────────
                elif tool_name == "search_library_batch":
                    queries = tool_args.get("queries", [])
                    print(f"  📚 search_library_batch({len(queries)} queries):")
                    for q in queries:
                        print(f"     • {q.get('query','')} "
                              f"[cat={q.get('category','-')} val={q.get('value','-')}]")
                    tool_result = search_library_batch.invoke(tool_args)
                    found = tool_result.count("--- Candidate")
                    print(f"     → {found} candidate(s) returned across all queries")
                    tool_call_log.append({
                        "tool":    "search_library_batch",
                        "queries": len(queries),
                        "found":   found,
                    })

                else:
                    print(f"  ⚠️  Unknown tool: {tool_name}")
                    tool_result = f"Unknown tool: {tool_name}"

                messages.append(ToolMessage(content=tool_result, tool_call_id=tool_id))

            iteration += 1

        else:
            print("✅ LLM finished (no more tool calls)")
            break

    # ── Tool call summary ──────────────────────────────────────────────────────
    if tool_call_log:
        lib_calls    = [t for t in tool_call_log if t["tool"] == "search_library_batch"]
        ds_calls     = [t for t in tool_call_log if t["tool"] == "search_component_datasheet"]
        cache_hits   = sum(1 for t in ds_calls if t.get("cache_hit"))
        tavily_calls = len(ds_calls) - cache_hits

        print(f"\n{'─'*55}")
        print(f"📊 Tool call summary:")
        print(f"   search_library_batch   : {len(lib_calls)} call(s)")
        print(f"   search_component_ds    : {len(ds_calls)} call(s) "
              f"({cache_hits} cache hits, {tavily_calls} Tavily)")
        if lib_calls:
            print(f"   Library queries:")
            for t in lib_calls:
                print(f"     • {t.get('queries','?')} queries → {t.get('found','?')} result(s)")
        if ds_calls:
            print(f"   Datasheet queries:")
            for t in ds_calls:
                status = "✅ cache" if t.get("cache_hit") else "🌐 Tavily"
                print(f"     • {t['args']}  [{status}]")
        print(f"{'─'*55}\n")

    # ── Structural issues — append as HumanMessage so system_msg isn't resent ───
    if structural_issues:
        issue_text = "\n".join(
            f"- [{i.code}] {i.message}" for i in structural_issues
        )
        messages.append(HumanMessage(content=f"""
STRUCTURAL VALIDATION FAILED.

The generated circuit specification contains INVALID STRUCTURAL ERRORS.
These are NOT user questions and MUST be fixed automatically.

Detected issues:
{issue_text}

MANDATORY INSTRUCTIONS:
- Fix ALL issues listed above.
- Preserve the original intended topology.
- Do NOT remove required functional blocks mentioned in the description.
- Regenerate a COMPLETE, VALID CircuitSpec.
"""))

    # ── Generate final structured spec — reuse messages (system prompt sent once) ─
    print("📝 Generating final structured specification...")
    final_spec = spec_llm.invoke(messages)
    #state.get("structural_issues", []).clear()

    return final_spec

# %%
def construct_revision_prompt(state):
    """
    Constructs a comprehensive revision prompt based on human feedback.
    This is called by spec_interpreter_node when revising.
    """
    feedback         = state.get("feedback", "")
    drc_instructions = state.get("drc_instructions", "")
    original_goal    = state.get("raw_description", "")

    drc_section = (
        f"=== DRC FIX INSTRUCTIONS ===\n{drc_instructions}\n"
        if drc_instructions else ""
    )

    revision_prompt = f"""
    ORIGINAL DESIGN GOAL:
{original_goal}
=== HUMAN VALIDATOR FEEDBACK ===
{feedback}

{drc_section}
INSTRUCTIONS FOR REVISION:
1. Address ALL feedback points above
2. If user confirmed low-confidence items, update confidence to 1.0 for those items and remove from checklist
3. If all issues resolved: set needs_validation=false, checklist=[], update confidence_score in spec to at least 0.85
4. The human answers questions with the highest priority first.
   - Once all highest-priority items are resolved, they MUST NOT be asked again.
   - If any lower-priority items remain unresolved, set needs_validation = true.


"""

    
    return revision_prompt

# %%
def enforce_confidence(spec: CircuitSpec, threshold: float):
    if any(i.type == "missing" for i in spec.checklist):
        spec.confidence_score = 0.60
        spec.needs_validation = True
    elif any(i.type == "alternatives" for i in spec.checklist):
        spec.confidence_score = 0.70
        spec.needs_validation = True
    elif any(i.type == "low_confidence" for i in spec.checklist):
        spec.confidence_score = 0.80
        spec.needs_validation = True
    else:
        if spec.confidence_score < threshold:
            spec.needs_validation = True
        else:
            spec.needs_validation = False
    return spec

# %%
def spec_interpreter_node(state):
    """
    Generate circuit specification from description.
    Uses tool-enabled LLM for autonomous datasheet searching.
    """
    iteration = state.get("iteration_count", 0)
    threshold = state.get("confidence_threshold", 0.85)
    rag_examples = state.get("retrieved_examples")
    
    if iteration > 0 and state.get("feedback"):
        if isinstance(state.get("spec"), dict) and state["spec"].get("checklist"):
            state["spec"]["checklist"] = []
            print("  🗑️  Checklist cleared — processing human feedback")
            
    if iteration == 0:
        # Initial generation
        circuit_description = state["raw_description"]
        result = generate_spec_with_tools(
            circuit_description,
            confidence_threshold=threshold,
            rag_examples=rag_examples,
            state=state
        )
    else:
        # Revision after human feedback
        circuit_description = construct_revision_prompt(state)
        result = generate_spec_with_tools(
            circuit_description,
            confidence_threshold=threshold,
            rag_examples=rag_examples,
            state=state
        )
    
    # Ensure confidence is enforced
    result = enforce_confidence(result, threshold)
    
    # Correct way to access confidence_score for Pydantic object
    confidence_score = getattr(result, "confidence_score", 0.0)
    
    result_dict = result.model_dump() 
    

    return {
        "spec" : result_dict,
        "iteration_count": iteration + 1,
        "raw_description": state["raw_description"],
        "structural_issues": [],
        "confidence_score": confidence_score
    }


# %%
def validate_structure(state):
    issues = []
    spec_dict = state["spec"]
    spec = CircuitSpec(**spec_dict)
    component_refs = {c.ref for c in spec.components}
    component_connections = defaultdict(set)

    # ── Existing: floating nets, invalid refs, single-component nets ───────────
    for net in spec.nets:
        pins = net.connected_pins
        if len(pins) < 2:
            issues.append(StructuralIssue(
                code    = "FLOATING_NET",
                message = f"Net '{net.name}' has fewer than 2 connections."
            ))
            continue
        for p in pins:
            if p.component_ref not in component_refs:
                issues.append(StructuralIssue(
                    code    = "INVALID_PIN_REF",
                    message = (
                        f"Net '{net.name}' references unknown component "
                        f"'{p.component_ref}'. This ref does not exist in "
                        f"components[]. Add the component or fix the ref."
                    )
                ))
            else:
                component_connections[p.component_ref].add(net.name)


    # ── Existing: floating components ─────────────────────────────────────────
    for comp in spec.components:
        if comp.ref not in component_connections:
            issues.append(StructuralIssue(
                code    = "FLOATING_COMPONENT",
                message = (
                    f"Component '{comp.ref}' ({comp.type}) is not connected "
                    f"to any net. Every component must connect to at least one net."
                )
            ))

    # ── NEW: duplicate pin — one pin on multiple nets ──────────────────────────
    seen_pins = {}  # {(comp_ref, pin_number): first_net_name}
    for net in spec.nets:
        for p in net.connected_pins:
            key = (p.component_ref, str(p.pin_number or ""))
            if key in seen_pins:
                issues.append(StructuralIssue(
                    code    = "DUPLICATE_PIN",
                    message = (
                        f"Pin {key[0]}.pin{key[1]} appears on both "
                        f"'{seen_pins[key]}' and '{net.name}'. "
                        f"Each physical pin can only connect to one net. "
                        f"Remove {key[0]}.pin{key[1]} from '{net.name}' "
                        f"and keep it only on '{seen_pins[key]}'."
                    )
                ))
            else:
                seen_pins[key] = net.name

    # ── Store if clean ─────────────────────────────────────────────────────────
    confidence_score = spec.confidence_score
    needs_validation = spec.needs_validation

    if confidence_score >= 0.85 and not needs_validation and not issues:
        try:
            desc_id = memgraph.store_circuit_spec(spec)
            print(f"✓ Circuit stored in graph database (ID: {desc_id})")
            memgraph.visualize_circuit(spec.title)
        except Exception as e:
            print(f"⚠️ Failed to store in graph: {e}")

    # Print summary
    if issues:
        print(f"\n⚠️  Structural validation: {len(issues)} issue(s) found")
        for iss in issues:
            code = iss.code if hasattr(iss, 'code') else iss.get('code', '?')
            msg  = iss.message if hasattr(iss, 'message') else iss.get('message', '')
            print(f"   [{code}] {msg[:100]}{'...' if len(msg) > 100 else ''}")
    else:
        print("✅ Structural validation passed")

    issues = [i.model_dump() for i in issues]
    return {"structural_issues": issues}



# %%

def human_validator_node(state):
    """
    Human validator that shows ONLY the highest-priority checklist items.
    Structural-validation items get the same grouped multi-choice display
    as all other checklist categories.
    """
    spec      = state["spec"]   # assumed to be a dict
    threshold = state.get("confidence_threshold", 0.85)
    iteration = state.get("iteration_count", 1)
 
    if not spec.get("checklist"):
        return interrupt({
            "message":          "No validation required.",
            "confidence_score": spec.get("confidence_score", 0.0),
            "iteration":        iteration,
        })
 
    # 1️⃣  Find highest priority (lowest number = most urgent)
    min_priority  = min(item["priority"] for item in spec["checklist"])
 
    # 2️⃣  Select only those items
    current_items = [
        item for item in spec["checklist"]
        if item["priority"] == min_priority
    ]
 
    # 3️⃣  Group by category and type — structural issues appear naturally here
    grouped = {}
    for item in current_items:
        cat = item["category"]
        if cat not in grouped:
            grouped[cat] = {
                "missing":        [],
                "low_confidence": [],
                "alternatives":   [],
            }
        grouped[cat][item["type"]].append(item)
 
    # 4️⃣  Remaining context
    remaining_summary = {
        "total_remaining": len(spec["checklist"]),
        "by_priority":     sorted(set(i["priority"] for i in spec["checklist"])),
    }
 
    # 5️⃣  Surface a helpful label for structural issues in the interrupt payload
    has_structural = any(
        item.get("category") == "structural_validation"
        for item in current_items
    )
 
    human_input = interrupt({
        "iteration": iteration,
        "confidence_score": spec.get("confidence_score", 0.0),
        "confidence_threshold": threshold,
        "current_priority": min_priority,
        "current_group_rationale": current_items[0]["rationale"] if current_items else "",
        "has_structural_issues": has_structural,
        "issues_to_review": grouped,
        "remaining_summary": remaining_summary,
    })

    # Process the input and clear the checklist
    response = str(human_input) if human_input else ""
    
    # Check if user wants to remove everything
    if any(phrase in response.lower() for phrase in ["remove it", "delete it", "remove all", "delete all"]):
        spec["components"] = []
        spec["nets"] = []
        spec["checklist"] = []
        spec["needs_validation"] = False
        spec["confidence_score"] = 0.95
        spec["title"] = "Empty Circuit"
        spec["description"] = "All components and connections have been removed as requested."
        print("  🗑️  All components removed as requested")
        return {
            "feedback": [human_input],
            "spec": spec,
            "iteration_count": 1
        }
    
    # Clear the checklist and set needs_validation to False
    spec["checklist"] = []
    spec["needs_validation"] = False
    spec["confidence_score"] = 0.95
    
    print(f"  ✅ Validation complete - {len(spec.get('components', []))} components, {len(spec.get('nets', []))} nets")
    
    return {
        "feedback": [human_input],
        "spec": spec,
        "iteration_count": 1,
        "needs_validation": False,  # ← Important: signal that validation is done
    }
# %%
def circuitspec_to_edif(spec, output_path: str, from_rag: bool = False) -> str:
    """
    Convert CircuitSpec -> EDIF .edn file via the new EDIF generator.
    Automatically patches common LLM spec issues (VCC/VBUS merge, etc.)
    """
    from collections import defaultdict
    print(f"  🔍 DEBUG circuitspec_to_edif: from_rag={from_rag}, spec.get('from_rag')={spec.get('from_rag') if isinstance(spec, dict) else 'N/A'}")

    def _get(obj, attr, default=None):
        if isinstance(obj, attr.__class__) and isinstance(obj, dict):
            return obj.get(attr, default)
        if isinstance(obj, dict):
            return obj.get(attr, default)
        return getattr(obj, attr, default)

    # Only patch if spec came from LLM generation, not RAG retrieval
    if not from_rag:
        if isinstance(spec, dict):
            spec = _patch_spec_nets(spec)
            
    comps_raw = _get(spec, "components", [])
    nets_raw  = _get(spec, "nets",       [])

    components_by_category = defaultdict(list)
    skipped                = []

    for comp in comps_raw:
        ref      = _get(comp, "ref",          "?")
        ctype    = _get(comp, "type",         "Unknown")
        part_num = _get(comp, "part_number",  None)

        if ctype in SKIP_TYPES:
            print(f"  {ref:6s} | {ctype:12s} | SKIPPED (schematic symbol)")
            continue

        if not part_num:
            if ctype not in SKIP_TYPES_pn:
                skipped.append(f"{ref} ({ctype}) — no part_number")
                continue   # ← still skip in EDIF if no part_number


        category = TYPE_TO_CATEGORY.get(ctype)
        if category is None:
            print(f"  ⚠️  Unknown type '{ctype}' for {ref} — defaulting to IC")
            category = "IC"

        components_by_category[category].append((ref, part_num))  # ← tuple with ref

    if skipped:
        print(f"  Skipped {len(skipped)} components with no part_number:")
        for s in skipped:
            print(f"       {s}")

    nets_list = []
    for net in nets_raw:
        if isinstance(net, dict):
            nets_list.append(net)
        else:
            nets_list.append({
                "name":           net.name,
                "net_type":       net.net_type or "signal",
                "connected_pins": [
                    {
                        "component_ref": p.component_ref,
                        "pin_number":    p.pin_number or "",
                        "pin_name":      getattr(p, "pin_name",      None),
                        "pin_direction": getattr(p, "pin_direction",  None),
                    }
                    for p in net.connected_pins
                ],
            })

    design_name = re.sub(r"[^\w]", "_", _get(spec, "title", "circuit"))

    print(f"\n📄 Generating EDIF for '{design_name}'...")
    print(f"   Components : {sum(len(v) for v in components_by_category.values())}")
    print(f"   Nets       : {len(nets_list)}")

    generate_edif_file(
        design_name            = design_name,
        components_by_category = dict(components_by_category),
        db_path                = LIBRARY_DB,   
        output_path            = output_path,
        nets                   = nets_list,
    )
    return output_path



# %%
def verification_validator_node(state):
    """LLM reviews DRC results and decides next action."""
    print("\n🤖 VERIFICATION: LLM reviewing DRC results...")

    drc_result  = state.get("drc_result", {})
    drc_summary = state.get("drc_summary", "No DRC results.")
    spec        = state.get("spec", {})
    title       = spec.get("title", "Unknown") if isinstance(spec, dict) else getattr(spec, "title", "Unknown")

    if drc_result.get("status") in ("skipped", "error"):
        print("  ⚠️  DRC skipped/errored — treating as WARNING")
        return {"verification_verdict": "WARNING"}

    if drc_result.get("pass_fail") == "PASS":
        print("  ✅ DRC PASS — no errors")
        return {"verification_verdict": "PASS"}

    if drc_result.get("pass_fail") == "SKIP":
        return {"verification_verdict": "WARNING"}

    _SYSTEM = """\
You are a PCB verification expert. Classify DRC errors into exactly one verdict:
- FIX     : Circuit design errors (unconnected pins, floating nets, missing power, pin conflicts). Can be fixed by revising the schematic.
- BLOCK   : Tool/config errors (missing library, license, tool crash). Cannot be LLM-fixed.
- WARNING : Warnings only, no hard errors — safe to continue."""

    result = structured_verifier.invoke([
        SystemMessage(content=_SYSTEM),
        HumanMessage(content=f"Circuit: {title}\n\n{drc_summary}"),
    ])

    verdict      = result.verdict
    reason       = result.reason
    instructions = result.instructions

    print(f"  Verdict: {verdict} — {reason}")

    new_drc_instructions = None
    if verdict == "FIX" and instructions:
        iteration = state.get("iteration_count", 0)
        if iteration >= 3:
            print("  ⚠️  Max DRC fix attempts reached — blocking")
            verdict = "BLOCK"
        else:
            new_drc_instructions = (
                f"[DRC VERIFICATION FAILED — please fix the circuit]\n"
                f"{drc_summary}\n\nFix instructions:\n{instructions}"
            )

    return {
        "verification_verdict": verdict,
        "drc_instructions":     new_drc_instructions,
    }

# %%
def route_from_import(state):
    import_status = state.get("import_status")
    if import_status == "ok":
        return "pads_drc"
    return "verification_validator"   # skipped or failed — jump straight to verdict

# %%
def route_from_verification(state):
    verdict = state.get("verification_verdict", "BLOCK")
    if verdict == "FIX":
        return "spec_interpreter"
    return "end"  


# %%
def structural_to_checklist_node(state):
    structural_issues = state.get("structural_issues", [])
    spec = state.get("spec", {})
    iteration = state.get("iteration_count", 0)
 
    structural_checklist_items = []
    for issue in structural_issues:
        issue_dict = issue if isinstance(issue, dict) else issue.__dict__
        code    = issue_dict.get('code', 'UNKNOWN')
        message = issue_dict.get('message', 'No message')
 
        # ── Build a rich multi-choice question per issue type ──────────────
        if code == "FLOATING_COMPONENT":
            question = (
                f"Component is not connected to any net: {message}\n\n"
                f"How should we fix this?\n"
                f"  Option 1: Connect the component to an existing net (provide net name)\n"
                f"  Option 2: Create a new net for this component\n"
                f"  Option 3: Remove the component from the design entirely\n"
                f"  Option 4: Leave it (I will fix it manually later)"
            )
        elif code == "FLOATING_NET":
            question = (
                f"Net has fewer than 2 connections: {message}\n\n"
                f"How should we fix this?\n"
                f"  Option 1: Add a missing pin to this net (specify component ref + pin)\n"
                f"  Option 2: Merge this net into an existing net (provide target net name)\n"
                f"  Option 3: Remove the net entirely if it is unused\n"
                f"  Option 4: Leave it (I will fix it manually later)"
            )
        elif code == "INVALID_PIN_REF":
            question = (
                f"Invalid component reference in net: {message}\n\n"
                f"How should we fix this?\n"
                f"  Option 1: Add the missing component to the design (provide type + value)\n"
                f"  Option 2: Replace the ref with an existing component (provide correct ref)\n"
                f"  Option 3: Remove this pin reference from the net\n"
                f"  Option 4: Leave it (I will fix it manually later)"
            )
        elif code == "SINGLE_COMPONENT_NET":
            question = (
                f"Net connects only one component: {message}\n\n"
                f"How should we fix this?\n"
                f"  Option 1: Add a second component pin to this net (specify component + pin)\n"
                f"  Option 2: Merge with an adjacent net\n"
                f"  Option 3: Remove this net entirely\n"
                f"  Option 4: Leave it (I will fix it manually later)"
            )
        elif code == "DUPLICATE_PIN":
            question = (
                f"A pin appears on more than one net (short circuit): {message}\n\n"
                f"How should we fix this?\n"
                f"  Option 1: Keep the pin on the first net and remove it from the second\n"
                f"  Option 2: Keep the pin on the second net and remove it from the first\n"
                f"  Option 3: Merge both nets into one (provide a new net name)\n"
                f"  Option 4: Leave it (I will fix it manually later)"
            )
        else:
            question = (
                f"Structural issue detected: {message}\n\n"
                f"How should we address this?\n"
                f"  Option 1: Attempt automatic repair\n"
                f"  Option 2: Describe the correct fix (free text)\n"
                f"  Option 3: Skip this issue and continue\n"
                f"  Option 4: Leave it (I will fix it manually later)"
            )
 
        structural_checklist_items.append({
            "type":          "missing",
            "question":      question,
            "category":      "structural_validation",
            "current_value": None,
            "confidence":    0.0,
            "priority":      1,
            "rationale":     (
                f"[{code}] Critical structural error — "
                f"auto-fix failed after {iteration} attempt(s). "
                f"Manual resolution required."
            ),
        })
 
    updated_spec = {**spec}
    updated_spec["checklist"]        = structural_checklist_items + spec.get("checklist", [])
    updated_spec["needs_validation"] = True
 
    print(f"✅ Added {len(structural_checklist_items)} structural issues to checklist")
    print(f"📋 Total checklist items: {len(updated_spec['checklist'])}")
 
    return {
        "spec":              updated_spec,
        "structural_issues": [],
    }
 

def route_from_spec(state):
    max_iterations = 3
    iteration = state.get("iteration_count", 0)
    structural_issues = state.get("structural_issues", [])
    spec = state.get("spec")

    if iteration >= max_iterations and structural_issues:
        return "structural_to_checklist"

    if structural_issues:
        print(f"⚠️ Structural issues detected ({len(structural_issues)}), routing to spec_interpreter (attempt {iteration + 1}/{max_iterations}).")
        return "spec_interpreter"

    if spec is None:
        return "validator"

    # Check if validation is complete (checklist is empty AND needs_validation is False)
    if spec.get("needs_validation", True) or spec.get("checklist"):
        return "validator"
    else:
        # Validation complete - proceed to EDIF generation
        print("  ✅ Validation complete - proceeding to netlist generation")
        return "complete"

# %%
_patterns_checked = False
import time

# Add this near the top of your cell, after the imports
_patterns_checked = False
import time

def _ensure_patterns_fresh(force: bool = False):
    """
    Run pattern mining only when necessary.
    
    Args:
        force: Force re-mining even if patterns exist (for testing)
    """
    global _patterns_checked
    
    # If we already checked this session and patterns exist, skip
    if _patterns_checked and not force:
        print("  ℹ️  Patterns already checked this session - skipping")
        return
    
    _patterns_checked = True
    
    # Check if there are any circuits in the database
    circuit_count = list(memgraph.memgraph.execute_and_fetch(
        "MATCH (d:CircuitDescription) RETURN count(d) as count"
    ))
    
    if not circuit_count or circuit_count[0]['count'] == 0:
        print("  ℹ️  No circuits in database - skipping pattern mining")
        return
    
    # Only run if dirty OR if no patterns exist yet
    has_patterns = list(memgraph.memgraph.execute_and_fetch(
        "MATCH (p:PatternNode) RETURN count(p) as count"
    ))
    pattern_exists = has_patterns and has_patterns[0]['count'] > 0
    
    if not is_dirty(memgraph.memgraph) and pattern_exists:
        print("  ℹ️  Patterns are fresh - skipping mining")
        return
    
    print("  🔄 Running pattern mining...")
    start_time = time.time()
    
    summary = run_pattern_mining_pipeline(
        db=memgraph.memgraph,
        openai_client=client,
        min_cooccurrence=2
    )
    
    elapsed = time.time() - start_time
    if summary.get("status") == "complete":
        clear_dirty(memgraph.memgraph)
        print(f"  ✅ {summary['pattern_nodes_stored']} patterns stored in {elapsed:.1f}s")
    else:
        print(f"  ⚠️  Pattern mining failed: {summary.get('reason')}")


EXACT_MATCH_THRESHOLD = 0.90

def rag_retrieval_node(state):
    raw_description = state.get("raw_description", "")
    intent = state.get("chatMode", "")
    has_existing_circuit = state.get("spec") is not None
 
    print("Classifying Intent....................." , intent)
    print(f"\n{'='*60}\n🔍 RAG RETRIEVAL\n{'='*60}")
    print(f"Query: {raw_description[:120]}{'...' if len(raw_description) > 120 else ''}")
 
    # ── Case 1: QUERY about existing circuit ──────────────────────────────
    if intent == "analyze" and has_existing_circuit:
        print(f"📖 QUERY MODE: Analyzing existing circuit")
        existing_spec = state.get("spec")
        circuit_context = {
            "type": "circuit_analysis",
            "circuit": {
                "title":       existing_spec.get("title", "Current Circuit"),
                "description": existing_spec.get("description", ""),
                "components":  existing_spec.get("components", []),
                "nets":        existing_spec.get("nets", []),
            },
            "user_question": raw_description,
        }
        analysis_prompt = f"""
        You are a helpful circuit design assistant. Answer the user's question about their circuit.
 
        CURRENT CIRCUIT:
        {json.dumps(circuit_context, indent=2)}
 
        USER QUESTION: {raw_description}
 
        RESPONSE FORMAT:
        - First line: ONE SENTENCE answer (max 20 words)
        - Then: ONE optional technical detail line (if relevant)
        - End with: "Need more details? Ask 'tell me more'"
 
        Keep it VERY short. No paragraphs. No lists.
        """
        analysis_response = llm.invoke(analysis_prompt)
        return {
            "spec": {
                "type":             "circuit_analysis",
                "analysis":         analysis_response.content,
                "original_circuit": existing_spec,
            },
            "skip_llm":    True,
            "is_analysis": True,   # ← flag so route_from_rag can exit early
        }
 
    # ── Case 2: NEW DESIGN ────────────────────────────────────────────────
    elif intent == "generate":
        print(f"🎨 NEW DESIGN MODE: Finding similar circuits for inspiration")
 
        if not raw_description:
            print("⚠️  raw_description missing — skipping RAG")
            return {"retrieved_examples": None, "skip_llm": False}
 
        _ensure_patterns_fresh()
        context_str = agent.run(raw_description)
 
        # ── Exact match check — include subcircuits ────────────────────────────
        query_emb = _embed(raw_description, client)
        top_hits  = find_structurally_similar_circuits(
            raw_description, memgraph.memgraph, client,
            top_k=1,
            query_embedding=query_emb,
            circuits_only=False,   # ← check subcircuits too
        )
 
        if top_hits and top_hits[0]["similarity"] >= EXACT_MATCH_THRESHOLD:
            hit         = top_hits[0]
            desc_id     = hit["desc_id"]
            sim         = hit["similarity"]
            result_type = hit.get("type", "circuit")
 
            print(f"\n  ⚡ EXACT MATCH (similarity: {sim:.3f} ≥ {EXACT_MATCH_THRESHOLD})")
            print(f"     '{hit['title']}' [{result_type}] — skipping LLM generation")
 
            # ── Reconstruct spec differently depending on type ─────────────────
            if result_type == "subcircuit":
                # Fetch components directly from SubCircuitDescription
                sc_rows = list(memgraph.memgraph.execute_and_fetch("""
                    MATCH (sub:SubCircuitDescription)-[:COMPOSED_OF_COMPONENT]->(c:ComponentNode)
                    WHERE ID(sub) = $sub_id
                    RETURN c.ref AS ref, c.type AS type,
                           c.part_number AS part_number, c.value AS value,
                           c.metadata AS metadata
                """, {'sub_id': desc_id}))
 
                net_rows = list(memgraph.memgraph.execute_and_fetch("""
                    MATCH (sub:SubCircuitDescription)-[:COMPOSED_OF_COMPONENT]->(c:ComponentNode)
                          -[:COMPONENT_HAS_PIN]->(pin:PinRefNode)
                          -[:CONNECTED_TO_NET]->(n:NetNode)
                    WHERE ID(sub) = $sub_id
                    RETURN n.name AS net_name, n.net_type AS net_type,
                           pin.component_ref AS comp_ref,
                           pin.pin_number AS pin_number,
                           pin.pin_name AS pin_name,
                           pin.pin_direction AS pin_direction
                """, {'sub_id': desc_id}))
 
                # Build nets dict filtering to internal pins only
                sub_refs  = {r['ref'] for r in sc_rows}
                nets_dict = {}
                for nr in net_rows:
                    if nr['comp_ref'] not in sub_refs:
                        continue
                    nn = nr['net_name']
                    if nn not in nets_dict:
                        nets_dict[nn] = {
                            'name':           nn,
                            'net_type':       nr['net_type'],
                            'connected_pins': []
                        }
                    nets_dict[nn]['connected_pins'].append({
                        'component_ref': nr['comp_ref'],
                        'pin_number':    nr['pin_number'],
                        'pin_name':      nr['pin_name'],
                        'pin_direction': nr['pin_direction'],
                    })
 
                components = [
                    {'ref': r['ref'], 'type': r['type'],
                     'part_number': r['part_number'],
                     'value': r['value'], 'metadata': r['metadata']}
                    for r in sc_rows
                ]
                nets = list(nets_dict.values())
                print(f"     {len(components)} components, {len(nets)} nets "
                      f"(from subcircuit '{hit['title']}')")
 
            else:
                # Full circuit reconstruction
                circuit_data = memgraph._reconstruct_circuit_spec(desc_id)
                components   = circuit_data["components"]
                nets         = circuit_data["nets"]
                print(f"     {circuit_data['stats']['num_components']} components, "
                      f"{circuit_data['stats']['num_nets']} nets")
 
            matched_spec = {
                "title":            hit["title"],
                "description":      raw_description,
                "components":       components,
                "nets":             nets,
                "confidence_score": 0.95,
                "needs_validation": False,
                "checklist":        [],
                "from_rag":         True,
            }
 
            print(f"{'='*60}\n")
            return {
                "retrieved_examples": context_str,
                "skip_llm":           True,
                "spec":               matched_spec,
                "from_rag":           True,
            }
 
        # ── No exact match — pass examples to LLM ─────────────────────────
        if not context_str or "--- Example" not in context_str:
            print("  ❌ No similar circuits found — LLM generates from scratch")
            print(f"{'='*60}\n")
            return {"retrieved_examples": None, "skip_llm": False}
 
        n_examples = context_str.count("--- Example")
        print(f"  ✅ {n_examples} example(s) — {len(context_str):,} chars")
        for block in re.split(r"(?=--- Example \d+:)", context_str):
            title_m = re.match(r"--- Example \d+: (.+?) \(similarity: ([\d.]+)\)", block)
            if not title_m:
                continue
            title, score = title_m.groups()
            print(f"     → {title} ({score})")
        print(f"{'='*60}\n")
        return {"retrieved_examples": context_str, "skip_llm": False}
 
    # ── Fallback: unknown intent ───────────────────────────────────────────
    print(f"⚠️  Unknown intent '{intent}' — skipping RAG")
    print(f"{'='*60}\n")
    return {"retrieved_examples": None, "skip_llm": False}
 

# %%
def route_from_rag(state):
    if state.get("is_analysis"):   # analyze mode → done, no EDIF
        return "end"
    if state.get("skip_llm"):      # generate exact match → EDIF
        return "netlist_generator"
    return "spec_interpreter"      # generate, no match → LLM


# %%
from pathlib import Path
# ── Node 1: Generate EDIF ──────────────────────────────────────────────────────
def netlist_generator_node(state):
    """Convert CircuitSpec dict from GraphState -> EDIF .edn file."""
    print("\n📄 NETLIST GENERATOR: Converting CircuitSpec -> EDIF...")

    spec = state.get("spec")
    from_rag = (spec.get("from_rag", False) if isinstance(spec, dict) else False)
    
    if spec is None:
        return {"edn_path": None, "block_name": None}

    title       = spec.get("title", "circuit") if isinstance(spec, dict) else spec.title
    design_name = re.sub(r"[^\w]", "_", title)

    # Store on F: drive so edifgraf.exe can read it
    edn_path = os.path.join(EDN_OUTPUT_DIR, f"{design_name}.edn")

    try:
        circuitspec_to_edif(spec=spec, output_path=edn_path, from_rag=from_rag)
        print(f"  ✅ EDIF written : {edn_path}")
        print(f"  📦 Block name   : {design_name}")
        return {
            "edn_path":   edn_path,
            "block_name": design_name,   # ← stored for DRC node to use
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"  ❌ EDIF generation failed: {e}")
        return {"edn_path": None, "block_name": None}


# ── Node 2: Import EDIF into PADS ─────────────────────────────────────────────
def pads_import_node(state):
    print("\n📥 PADS IMPORT: Importing EDIF into PADS...")

    edn_path   = state.get("edn_path")
    if edn_path is None: 
        print("edn none")
    block_name = Path(edn_path).stem if edn_path else None  

    if not edn_path or not os.path.exists(edn_path):
        print(f"  ⚠️  EDIF file not found: {edn_path}")
        return {
            "import_status":  "skipped",
            "import_message": "EDIF file not found.",
            "drc_result":  {"pass_fail": "SKIP", "error_count": 0,
                            "warnings": [], "errors": [], "status": "skipped"},
            "drc_summary": "DRC skipped — EDIF file not found.",
        }

    print(f"  📄 Importing : {edn_path}")
    print(f"  📦 Block     : {block_name}")
    
    prj_file = DRC_CONFIG.get("prj_file")
    agent  = PADSAgent.from_file(edn_path, prj_file=prj_file)
    result = agent.import_edif()

    if result.ok():
        print(f"  ✅ Import successful")
        return {"import_status": "ok", "import_message": ""}
    else:
        print(f"  ❌ Import failed: {result.message}")
        if result.log_path:
            print(f"  📋 Log: {result.log_path}")
        return {
            "import_status":  "failed",
            "import_message": result.message,
            "drc_result":  {"pass_fail": "SKIP", "error_count": 0,
                            "warnings": [], "errors": [], "status": "skipped"},
            "drc_summary": f"DRC skipped — import failed: {result.message}",
        }
     
             

# ── Node 3: Run DRC on the imported block ─────────────────────────────────────
def pads_drc_node(state):
    """
    Run vdrc.exe on the block that was just imported into the PADS project.
    block_name comes from netlist_generator_node via state.
    """

    print("\n🔍 DRC: Running pads schematic verification...")
    edn_path   = state.get("edn_path")
    block_name = Path(edn_path).stem if edn_path else None
    if not block_name:
            return {
                "drc_result":  {"pass_fail": "SKIP", "error_count": 0,
                                "warnings": [], "errors": [], "status": "skipped"},
                "drc_summary": "DRC skipped — no block name in state.",
            }
    verify_ini = DRC_CONFIG.get("verify_ini", "")
    if not os.path.exists(verify_ini):
        print(f"  ⚠️  Verify.ini not found: {verify_ini}")
        print(f"       Run Full Verification in pads once to create it.")
        return {
            "drc_result":  {"pass_fail": "SKIP", "error_count": 0,
                            "warnings": [], "errors": [], "status": "skipped"},
            "drc_summary": "DRC skipped — Verify.ini missing.",
        }

    print(f"  📦 Block   : {block_name}")
    print(f"  📄 EDN     : {edn_path}")
    print(f"  📋 Verify  : {verify_ini}")

    try:
        drc_result = run_pads_drc(
            prj_file   = DRC_CONFIG["prj_file"],
            block_name = block_name,         
            verify_ini = verify_ini,
            output_dir = DRC_CONFIG["output_dir"],
        )
    except FileNotFoundError as e:
        print(f"  ⚠️  {e}")
        return {
            "drc_result":  {"pass_fail": "SKIP", "error_count": 0,
                            "warnings": [], "errors": [], "status": "skipped"},
            "drc_summary": str(e),
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        drc_result = {
            "pass_fail": "ERROR", "error_count": 1,
            "errors": [{"message": str(e)}],
            "warnings": [], "status": "error",
        }

    lines = [
        f"DRC Result : {drc_result.get('pass_fail','?')}",
        f"Errors     : {drc_result.get('error_count', 0)}",
        f"Warnings   : {drc_result.get('warning_count', 0)}",
        f"Block      : {block_name}",
        f"EDN file   : {edn_path}",
        "",
    ]
    for e in (drc_result.get("errors") or [])[:10]:
        lines.append(f"  ERROR [{e.get('id','?')}] {e.get('location','?')} — {e.get('message','?')}")
    for w in (drc_result.get("warnings") or [])[:5]:
        lines.append(f"  WARN  {w.get('message','?')}")

    print(f"  Result: {drc_result.get('pass_fail')} — "
          f"{drc_result.get('error_count',0)} errors, "
          f"{drc_result.get('warning_count',0)} warnings")

    return {
        "drc_result":  drc_result,
        "drc_summary": "\n".join(lines),
    }

# %%
graph = StateGraph(GraphState)
graph.add_node("rag_retrieval",           rag_retrieval_node)
graph.add_node("spec_interpreter",        spec_interpreter_node)
graph.add_node("human_validator",         human_validator_node)
graph.add_node("structural_validator",    validate_structure)
graph.add_node("structural_to_checklist", structural_to_checklist_node)
graph.add_node("netlist_generator",       netlist_generator_node)
graph.add_node("pads_import",             pads_import_node)
graph.add_node("pads_drc",               pads_drc_node)
graph.add_node("verification_validator",  verification_validator_node)

graph.set_entry_point("rag_retrieval")
graph.add_edge("spec_interpreter",  "structural_validator")
graph.add_edge("human_validator",   "spec_interpreter")
graph.add_edge("structural_to_checklist", "human_validator")
graph.add_edge("netlist_generator",       "pads_import")
graph.add_conditional_edges(
    "pads_import", route_from_import,
    {
        "pads_drc":               "pads_drc",
        "verification_validator": "verification_validator",
    }
)
graph.add_edge("pads_drc",     "verification_validator")

graph.add_conditional_edges(
    "rag_retrieval", route_from_rag,
    {
        "end":               END,              # ← analyze mode exits here
        "spec_interpreter":  "spec_interpreter",
        "netlist_generator": "netlist_generator",
    }
)
graph.add_conditional_edges(
    "structural_validator", route_from_spec,
    {
        "structural_to_checklist": "structural_to_checklist",
        "validator":               "human_validator",
        "spec_interpreter":        "spec_interpreter",
        "complete":                "netlist_generator",
    }
)
graph.add_conditional_edges(
    "verification_validator", route_from_verification,
    {
        "spec_interpreter": "spec_interpreter",
        "end":              END,   
    }
)
checkpointer = InMemorySaver()
app = graph.compile(checkpointer=checkpointer)



# %%
# THREAD_ID = str(uuid.uuid4())
# config = {"configurable": {"thread_id": THREAD_ID}}

# desc = "NANO33IoTV2 PCB schematic. Main ICs: PRTR5V, PMEG6020, YELLOW, GREEN, MPM3610. Contains 50 components: 15 Capacitors, 5 Connectors, 4 Diodes, 5 ICs, 1 Inductor, 12 Resistors, 2 Switchs, 6 Test Points. Has 91 nets. Power rails: +3V3, VIN. Ground nets: GND."

# result = app.invoke(
#     {
#         "raw_description":      desc,
#         "spec":                 None,
#         "feedback":             [],
#         "confidence_threshold": 0.85,
#         "retrieved_examples":   None,
#         "iteration_count":      0,
#         "structural_issues":    [],
#         "import_status":        "skipped",
#         "import_message":       "",
#         "edn_path":             None,
#         "drc_result":           None,
#         "drc_summary":          None,
#         "verification_verdict": None,
#         "drc_instructions":     None,
#         "from_rag":             False,   # ← add this
#         "chatMode":"generate"
#     },
#     config=config,
# )
# result
# # # %%
