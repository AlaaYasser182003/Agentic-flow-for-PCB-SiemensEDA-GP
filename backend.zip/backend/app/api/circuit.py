from fastapi import APIRouter, HTTPException
from app.models.models import CircuitGenerateRequest, HumanFeedbackRequest, CircuitResponse
from app.services.agent_service import agent_service
import json, re, os

router = APIRouter(prefix="/api/circuit", tags=["circuit"])

# ---------------------------------------------------------------------------
# Load the parts library once at startup.
# Builds two structures:
#   PARTS_BY_PN  – dict  pn -> {category, pins, description}
#   LIBRARY_TEXT – compact text block fed into the LLM prompt
# ---------------------------------------------------------------------------
def _load_library() -> tuple[dict, str]:
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    candidates = [
        os.path.join(base, "StarterLibrary_AllParts.json"),
        os.path.join(base, "app", "StarterLibrary_AllParts.json"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "StarterLibrary_AllParts.json"),
    ]
    path = next((p for p in candidates if os.path.exists(p)), None)
    if not path:
        return {}, ""

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    parts_by_pn: dict = {}
    lines: list[str] = []
    for p in data.get("parts", []):
        pn   = p.get("partNumber", "")
        cat  = p.get("category", "")
        pins = p.get("pins", [])
        desc = (
            p.get("properties", {}).get("Description", "")
            or p.get("properties", {}).get("DEVICE", "")
            or ""
        )[:80]
        parts_by_pn[pn] = {"category": cat, "pins": pins, "description": desc}
        lines.append(f"{pn} | {cat} | pins: {pins} | {desc}")

    return parts_by_pn, "\n".join(lines)


PARTS_BY_PN, LIBRARY_TEXT = _load_library()
VALID_PNS = set(PARTS_BY_PN.keys())


# ---------------------------------------------------------------------------
# Standard circuit routes
# ---------------------------------------------------------------------------

@router.post("/generate", response_model=CircuitResponse)
async def generate_circuit(request: CircuitGenerateRequest):
    print("Received generation request:", request)
    result = await agent_service.generate_circuit(
        description=request.description or "",
        thread_id=request.thread_id,
        chat_mode=request.chat_mode,
        current_spec=request.current_spec
    )

    if not result.get("success"):
        raise HTTPException(
            status_code=500,
            detail=result.get("error", "Generation failed"),
        )

    return CircuitResponse(**result)


@router.post("/validate/{thread_id}", response_model=CircuitResponse)
async def validate_circuit(thread_id: str, request: HumanFeedbackRequest):
    """Process human feedback for circuit validation"""
    if request.thread_id != thread_id:
        raise HTTPException(status_code=400, detail="Thread ID mismatch")

    result = await agent_service.process_feedback(
        thread_id=thread_id,
        feedback=request.feedback,
        resolved_items=request.resolved_items,
    )

    if not result["success"]:
        raise HTTPException(
            status_code=500, detail=result.get("error", "Validation failed")
        )

    return CircuitResponse(**result)


@router.get("/status/{thread_id}")
async def get_status(thread_id: str):
    status = agent_service.get_status(thread_id)
    if not status:
        raise HTTPException(status_code=404, detail="Thread not found")
    return status


@router.get("/spec/{thread_id}")
async def get_spec(thread_id: str):
    spec = agent_service.get_spec(thread_id)
    if not spec:
        raise HTTPException(status_code=404, detail="Thread not found")
    return spec


@router.get("/checklist/{thread_id}")
async def get_checklist(thread_id: str):
    checklist = agent_service.get_checklist(thread_id)
    if not checklist:
        raise HTTPException(status_code=404, detail="Thread not found")
    return checklist

# ---------------------------------------------------------------------------
# Hover-based companion suggestion  –  fully LLM-driven, no hardcoded rules
# ---------------------------------------------------------------------------

@router.post("/suggest-companions")
async def suggest_companions(request: dict):
    """
    Called when the user hovers a component on the canvas.
    The LLM receives the full parts library plus all context about the hovered
    component and returns companion suggestions that include the exact pin names
    to use for wiring (anchorPin on the existing component, newPin on the new one).
    No static rules or part-number whitelists are applied here.
    """
    comp_pn        = request.get("component_pn", "")
    comp_type      = request.get("component_type", "")
    comp_pins      = request.get("component_pins", [])   # pins of the hovered component
    existing_pns   = request.get("existing_pns", [])     # already on canvas
    existing_types = request.get("existing_types", [])   # categories already on canvas

    # Resolve the hovered component's pins from library if not supplied by frontend
    if not comp_pins and comp_pn in PARTS_BY_PN:
        comp_pins = PARTS_BY_PN[comp_pn]["pins"]

    # Build a compact summary of what is already on the canvas so the LLM
    # avoids suggesting duplicates and understands the context.
    canvas_summary = ", ".join(
        f"{pn}({t})" for pn, t in zip(existing_pns, existing_types)
    ) or "empty canvas"

    prompt = f"""You are an expert electronics engineer helping with schematic design.

The user just placed this component on the canvas:
  Part number : {comp_pn}
  Category    : {comp_type}
  Pins        : {comp_pins}

Components already on canvas (DO NOT suggest these again):
  {canvas_summary}

Your task: suggest 2-3 companion components that are commonly used together with
the placed component. For each companion specify which pin on the EXISTING component
to wire from (anchorPin) and which pin on the NEW companion component to wire to
(newPin).  Base your pin choices on standard electronics practice:
  - Decoupling caps connect to a supply/VCC pin; their B1/B2 or +/- pins go to that net.
  - Pull-up/pull-down resistors connect to signal pins.
  - Current-limiting resistors for LEDs connect to the anode pin.
  - Gate resistors for MOSFETs connect to the gate pin (G).
  - Base resistors for BJTs connect to the base pin (B or PIN2 for MMBT3904).
  - Load capacitors for crystals connect to the oscillator pins (N/P).
  - EMI filters for USB connect to D+/D- differential pins.

ONLY suggest parts that exist in the library below.

=== AVAILABLE PARTS LIBRARY ===
{LIBRARY_TEXT}
=== END LIBRARY ===

Respond with ONLY valid JSON, no markdown, no explanation:
{{
  "suggestions": [
    {{
      "pn": "<partNumber from library>",
      "type": "<category>",
      "cat": "<category>",
      "reason": "<one sentence why this companion is needed>",
      "anchorPin": "<pin name on the EXISTING {comp_pn} to connect from>",
      "newPin": "<pin name on the new companion component to connect to>"
    }}
  ]
}}
"""

    try:
        from agent import llm

        result = llm.invoke(prompt)
        text   = re.sub(r"```json|```", "", result.content).strip()
        data   = json.loads(text)

        # Filter: only keep parts that exist in the library and aren't on canvas yet
        existing_set = set(existing_pns)
        filtered = []
        for s in data.get("suggestions", []):
            pn = s.get("pn", "")
            if pn not in VALID_PNS:
                print(f"  [suggest-companions] Skipping unknown PN: {pn!r}")
                continue
            if pn in existing_set:
                print(f"  [suggest-companions] Skipping already-placed PN: {pn!r}")
                continue
            # Enrich with library pin data so the frontend always has them
            lib_entry = PARTS_BY_PN.get(pn, {})
            s["pins"] = lib_entry.get("pins", [])
            filtered.append(s)

        print(f"[suggest-companions] {comp_pn} → {len(filtered)} suggestions")
        return {"suggestions": filtered}

    except json.JSONDecodeError as e:
        print(f"[suggest-companions] JSON parse error: {e}\nRaw: {text!r}")
        return {"suggestions": []}
    except Exception as e:
        print(f"[suggest-companions] Error: {e}")
        return {"suggestions": []}
    

