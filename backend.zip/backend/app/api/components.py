from fastapi import APIRouter, HTTPException, Query
from typing import Optional
import sqlite3 
from pathlib import Path

router = APIRouter(prefix="/api/components", tags=["components"])

# ----------------------------
# DB CONNECTION
# ----------------------------
BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR.parent / "lib.db"
print("database path for backend ", DB_PATH)
def get_db():
    print(f"🔍 Connecting to DB: {DB_PATH}")
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

# ----------------------------
# GET ALL COMPONENTS (NEW)
# ----------------------------
@router.get("/all")
async def get_all_components():
    """Get all components from the database with pagination support"""
    try:
        if not DB_PATH.exists():
            raise HTTPException(
                status_code=500, 
                detail=f"Database not found at {DB_PATH.absolute()}"
            )
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Get total count
        cursor.execute("SELECT COUNT(*) as total FROM parts")
        total = cursor.fetchone()["total"]
        
        # Get all components with pagination
        cursor.execute("""
            SELECT * FROM parts 
            ORDER BY partNumber 
        """)
        
        rows = cursor.fetchall()
        conn.close()
        
        components = [dict(row) for row in rows]
        
        return {
            "success": True,
            "total": total,
            "components": components
        }
    except Exception as e:
        print(f"❌ Error in get_all_components: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ----------------------------
# SEARCH COMPONENTS
# ----------------------------
@router.get("/search")
async def search_components(
    search_term: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    limit: int = Query(50, le=100)
):
    conn = get_db()
    cursor = conn.cursor()

    query = "SELECT * FROM parts WHERE 1=1"
    params = []

    # text search
    if search_term:
        term = f"%{search_term.lower()}%"
        query += """
        AND (
            LOWER(ref) LIKE ?
            OR LOWER(pn) LIKE ?
            OR LOWER(type) LIKE ?
        )
        """
        params.extend([term, term, term])

    # category filter
    if category:
        query += " AND type = ?"
        params.append(category)

    query += " LIMIT ?"
    params.append(limit)

    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()

    return {
        "total": len(rows),
        "components": [dict(r) for r in rows]
    }

# ----------------------------
# GET CATEGORIES
# ----------------------------
@router.get("/categories")
async def get_categories():
    try:
        if not DB_PATH.exists():
            return {"categories": [], "error": f"Database not found at {DB_PATH.absolute()}"}
        
        conn = sqlite3.connect(str(DB_PATH))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Note: Using 'type' column as category based on your schema
        cursor.execute("""
            SELECT DISTINCT type as category
            FROM parts
            WHERE type IS NOT NULL AND type != ''
            ORDER BY type
        """)
        
        rows = cursor.fetchall()
        conn.close()
        
        categories = [r["category"] for r in rows]
        
        return {
            "categories": categories,
            "total": len(categories)
        }
    except Exception as e:
        print(f"❌ Error in categories endpoint: {e}")
        return {"categories": [], "error": str(e)}

# ----------------------------
# GET SINGLE COMPONENT
# ----------------------------
@router.get("/{component_pn}")
async def get_component(component_pn: str):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM parts WHERE pn = ?",
        (component_pn,)
    )

    row = cursor.fetchone()
    conn.close()

    if not row:
        raise HTTPException(status_code=404, detail="Component not found")

    return dict(row)