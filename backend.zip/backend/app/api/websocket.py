from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from app.services.agent_service import agent_service
import json

router = APIRouter(tags=["websocket"])

class ConnectionManager:
    def __init__(self):
        self.active_connections: dict = {}
    
    async def connect(self, websocket: WebSocket, thread_id: str):
        await websocket.accept()
        self.active_connections[thread_id] = websocket
    
    def disconnect(self, thread_id: str):
        if thread_id in self.active_connections:
            del self.active_connections[thread_id]
    
    async def send_message(self, thread_id: str, message: dict):
        if thread_id in self.active_connections:
            await self.active_connections[thread_id].send_json(message)

manager = ConnectionManager()

@router.websocket("/ws/{thread_id}")
async def websocket_endpoint(websocket: WebSocket, thread_id: str):
    await manager.connect(websocket, thread_id)
    
    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            message_type = message.get("type")
            
            if message_type == "generate":
                await manager.send_message(thread_id, {
                    "type": "status",
                    "status": "generating",
                    "message": "Starting circuit generation..."
                })
                
                # Run generation (you might want to do this in background)
                result = await agent_service.generate_circuit(
                    description=message.get("description", ""),
                    thread_id=thread_id
                )
                
                await manager.send_message(thread_id, {
                    "type": "complete",
                    "result": result
                })
            
            elif message_type == "feedback":
                await manager.send_message(thread_id, {
                    "type": "status",
                    "status": "processing_feedback",
                    "message": "Processing your feedback..."
                })
                
                result = await agent_service.process_feedback(
                    thread_id=thread_id,
                    feedback=message.get("feedback", ""),
                    resolved_items=message.get("resolved_items", [])
                )
                
                await manager.send_message(thread_id, {
                    "type": "complete",
                    "result": result
                })
            
            elif message_type == "ping":
                await manager.send_message(thread_id, {"type": "pong"})
                
    except WebSocketDisconnect:
        manager.disconnect(thread_id)