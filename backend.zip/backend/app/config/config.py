import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # API Keys
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "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")
    TAVILY_API_KEY = os.getenv("TAVILY_API_KEY", "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")
    
    # Memgraph Database
    MEMGRAPH_HOST = os.getenv("MEMGRAPH_HOST", "localhost")
    MEMGRAPH_PORT = int(os.getenv("MEMGRAPH_PORT", 7687))
    
    # Server Settings
    API_HOST = os.getenv("API_HOST", "0.0.0.0")
    API_PORT = int(os.getenv("API_PORT", 8000))
    
    # CORS - Allow your frontend origin
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:5500,http://127.0.0.1:5500,http://127.0.0.1:5501").split(",")
    
    # Agent Settings
    MAX_ITERATIONS = int(os.getenv("MAX_ITERATIONS", 8))
    CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", 0.85))

config = Config()