from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# from load_data import load_database_data_into_Json

from .api import circuit, components, websocket
from .config import config

# Create FastAPI app
app = FastAPI(
    title="CircuitAI Agent API",
    description="API for circuit design AI agent",
    version="1.0.0"
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=[        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "http://localhost:5173",  # Common Vite port
        "http://127.0.0.1:5173",],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(circuit.router)
app.include_router(components.router)
app.include_router(websocket.router)
print("✅ Components router registered")  # Add this
@app.get("/")
async def root():
    return {
        "service": "CircuitAI Agent API",
        "version": "1.0.0",
        "endpoints": {
            "generate": "POST /api/circuit/generate",
            "validate": "POST /api/circuit/validate/{thread_id}",
            "status": "GET /api/circuit/status/{thread_id}",
            "spec": "GET /api/circuit/spec/{thread_id}",
            "checklist": "GET /api/circuit/checklist/{thread_id}",
            "components": "GET /api/components/search",
            "categories": "GET /api/components/categories",
            "search": "GET /api/components/search",
            "websocket": "WS /ws/{thread_id}",
            "search":"GET /api/components/"
        }
    }

@app.get("/health")
async def health():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app:app",
        host=config.config.API_HOST,
        port=config.config.API_PORT,
        reload=True
    )

    # load_database_data_into_Json()