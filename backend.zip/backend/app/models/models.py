from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum

class CircuitGenerateRequest(BaseModel):
    description: str
    thread_id: Optional[str] = None
    confidence_threshold: Optional[float] = 0.85
    component_info: Optional[Dict[str, Any]] = None
    chat_mode:Optional[str]
    current_spec: Optional[Dict[str, Any]] = None
    
class HumanFeedbackRequest(BaseModel):
    thread_id: str
    feedback: str
    resolved_items: Optional[List[str]] = None

class ComponentSearchRequest(BaseModel):
    search_term: Optional[str] = None
    category: Optional[str] = None

class CircuitResponse(BaseModel):
    success: bool
    thread_id: Optional[str] = None
    spec: Optional[Dict[str, Any]] = None
    confidence_score: float = 0.0
    needs_validation: bool = False
    checklist: List[Any] = []
    message: str = ""
    drc_result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    # ── New recommendation fields ──
    is_recommendation: bool = False
    recommendations: List[Dict[str, Any]] = []

class ThreadStatus(BaseModel):
    thread_id: str
    status: str  # processing, needs_human, complete, error
    current_iteration: int
    confidence_score: float
    has_checklist: bool
    created_at: str