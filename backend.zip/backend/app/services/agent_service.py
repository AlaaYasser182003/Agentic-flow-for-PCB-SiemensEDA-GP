import uuid
from typing import Dict, Any, Optional
from datetime import datetime
from aiohttp import request
from langgraph.checkpoint.memory import InMemorySaver

# Import your existing agent components
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import re as _re

from agent import (
    app as agent_app
)


class AgentService:
    def __init__(self):
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.thread_states: Dict[str, Dict[str, Any]] = {}
        self.checkpointer = InMemorySaver()

    @staticmethod
    def _desc_key(description: str) -> str:
        """Normalised lower-case key used to deduplicate in-memory sessions."""
        return _re.sub(r"\s+", " ", description.strip().lower())

    def create_session(self, description: str, thread_id: Optional[str] = None) -> str:
        """Create a new agent session"""
        if not thread_id:
            thread_id = f"thread_{datetime.now().timestamp()}_{uuid.uuid4().hex[:6]}"
        
        self.sessions[thread_id] = {
            "created_at": datetime.now().isoformat(),
            "status": "processing",
            "iteration": 0,
            "description": description,
            "messages": []
        }
        
        return thread_id
    
    def get_config(self, thread_id: str) -> Dict:
        """Get LangGraph config for a thread"""
        return {
            "configurable": {
                "thread_id": thread_id
            }
        }

    async def generate_circuit(
        self,
        description: str,
        thread_id: Optional[str] = None,
        chat_mode: Optional[str] = None,
        current_spec: Optional[Dict[str, Any]] = None,
        # is_recommendation: bool = False
    ) -> Dict[str, Any]:

        # ============================================================
        # CASE 1: NORMAL CIRCUIT GENERATION FLOW 
        # ============================================================
        
        print(f"📝 Generating circuit - Description: {description[:100]}...")
        print(f"   Thread ID: {thread_id}")
        print(f"   Has current_spec: {current_spec is not None}")
        
        # Check if we have a stored spec from previous messages in the same thread
        stored_spec = None
        if thread_id and thread_id in self.thread_states:
            stored_state = self.thread_states[thread_id]
            stored_spec = stored_state.get("spec")
            if stored_spec:
                print(f"♻️ Found stored spec for thread {thread_id}")
        
        spec_to_use = current_spec or stored_spec
        
        # Create or get session
        if not thread_id or thread_id not in self.sessions:
            thread_id = self.create_session(description, thread_id)
        
        config = self.get_config(thread_id)
        initial_state = {
            "raw_description": description,
            "spec": spec_to_use, 
            "confidence_score": spec_to_use.get("confidence_threshold", 0.0) if spec_to_use else 0.0,
            "retrieved_examples": None,
            "iteration_count": 0,
            "feedback": [],
            "import_status":"skipped",
            "import_message":"",
            "structural_issues": [],
            "chatMode": chat_mode,
            "edn_path":None,
            "drc_result":None,
            "drc_summary":None,
            "verification_verdict":None,
            "drc_instructions":None,
            "from_rag":False,   
        }
        
        print(f"   Initial state has spec: {initial_state['spec'] is not None}")
        
        try:
            result = agent_app.invoke(initial_state, config=config)
            print(f"✅ Generation completed for {thread_id}: result: {result} ")

            needs_validation = result.get("spec", {}).get("needs_validation", True) if result.get("spec") else True
            self.sessions[thread_id]["status"] = "needs_human" if needs_validation else "complete"
            self.sessions[thread_id]["iteration"] = result.get("iteration_count", 0)
            
            self.thread_states[thread_id] = result
            spec = result.get("spec")
            
            if spec and spec.get("type") == "circuit_analysis":
                print("📖 Returning circuit analysis response")

                return {
                    "success": True,
                    "thread_id": thread_id,

                    "spec": spec,
                    "confidence_score": result.get("confidence_threshold", 0.0),

                    "retrieved_examples": result.get("retrieved_examples"),
                    "iteration_count": result.get("iteration_count", 0),
                    "feedback": result.get("feedback", []),

                    "import_status": result.get("import_status"),
                    "import_message": result.get("import_message"),

                    "structural_issues": result.get("structural_issues", []),

                    "chatMode": result.get("chatMode"),

                    "edn_path": result.get("edn_path"),
                    "drc_result": result.get("drc_result"),
                    "drc_summary": result.get("drc_summary"),

                    "verification_verdict": result.get("verification_verdict"),
                    "drc_instructions": result.get("drc_instructions"),

                    "from_rag": result.get("from_rag", False),

                    "needs_validation": False,
                    "checklist": [],

                    "message": "Circuit analysis complete",
                }
            
            return {
                "success": True,
                "thread_id": thread_id,

                "spec": result.get("spec"),
                "confidence_score": result.get("confidence_threshold", 0.0),

                "retrieved_examples": result.get("retrieved_examples"),
                "iteration_count": result.get("iteration_count", 0),
                "feedback": result.get("feedback", []),

                "import_status": result.get("import_status"),
                "import_message": result.get("import_message"),

                "structural_issues": result.get("structural_issues", []),

                "chatMode": result.get("chatMode"),

                "edn_path": result.get("edn_path"),
                "drc_result": result.get("drc_result"),
                "drc_summary": result.get("drc_summary"),

                "verification_verdict": result.get("verification_verdict"),
                "drc_instructions": result.get("drc_instructions"),

                "from_rag": result.get("from_rag", False),

                "needs_validation": (
                    result.get("spec", {}).get("needs_validation", True)
                    if result.get("spec")
                    else True
                ),

                "checklist": (
                    result.get("spec", {}).get("checklist", [])
                    if result.get("spec")
                    else []
                ),

                "message": "Circuit generated successfully",
            }

        except Exception as e:
            import traceback
            traceback.print_exc()
            
            self.sessions[thread_id]["status"] = "error"
            
            return {
                "success": False,
                "thread_id": thread_id,
                "drc_result": None,
                "error": str(e),
                "message": f"Generation failed: {str(e)}"
            }

    async def process_feedback(self, feedback: str, thread_id: Optional[str] = None, resolved_items: Optional[list] = None) -> Dict[str, Any]:
        """Process human feedback and revise circuit"""
        
        if thread_id not in self.thread_states:
            return {
                "success": False,
                "thread_id": thread_id,
                "error": "Thread not found",
                "drc_result": None,
                "message": "No active session found for this thread"
            }
        
        config = self.get_config(thread_id)
        
        feedback_message = feedback
        if resolved_items:
            feedback_message += f"\n\nResolved: {', '.join(resolved_items)}"
        
        try:
            from langgraph.types import Command
            
            result = agent_app.invoke(Command(resume=feedback_message), config=config)
            
            self.thread_states[thread_id] = result
            self.sessions[thread_id]["iteration"] = result.get("iteration_count", 0)
            
            spec = result.get("spec")
            needs_validation = spec.get("needs_validation", True) if spec else True
            self.sessions[thread_id]["status"] = "needs_human" if needs_validation else "complete"
            
            return {
                "success": True,
                "thread_id": thread_id,

                "spec": spec,
                "confidence_score": result.get("confidence_threshold", 0.0),

                "retrieved_examples": result.get("retrieved_examples"),
                "iteration_count": result.get("iteration_count", 0),
                "feedback": result.get("feedback", []),

                "import_status": result.get("import_status"),
                "import_message": result.get("import_message"),

                "structural_issues": result.get("structural_issues", []),

                "chatMode": result.get("chatMode"),

                "edn_path": result.get("edn_path"),
                "drc_result": result.get("drc_result"),
                "drc_summary": result.get("drc_summary"),

                "verification_verdict": result.get("verification_verdict"),
                "drc_instructions": result.get("drc_instructions"),

                "from_rag": result.get("from_rag", False),

                "needs_validation": needs_validation,
                "checklist": spec.get("checklist", []) if spec else [],

                "message": "Feedback processed successfully",
            }
            
        except Exception as e:
                return {
                    "success": False,
                    "thread_id": thread_id,

                    "spec": None,
                    "confidence_score": 0.0,

                    "retrieved_examples": None,
                    "iteration_count": 0,
                    "feedback": [],

                    "import_status": "error",
                    "import_message": str(e),

                    "structural_issues": [],

                    "chatMode": None,

                    "edn_path": None,
                    "drc_result": None,
                    "drc_summary": None,

                    "verification_verdict": None,
                    "drc_instructions": None,

                    "from_rag": False,

                    "error": str(e),
                    "message": f"Feedback processing failed: {str(e)}",
                }
        
    def get_status(self, thread_id: str) -> Optional[Dict]:
        """Get session status"""
        if thread_id not in self.sessions:
            return None
        
        session = self.sessions[thread_id]
        state = self.thread_states.get(thread_id, {})
        
        return {
            "thread_id": thread_id,
            "status": session["status"],
            "current_iteration": session["iteration"],
            "confidence_score": state.get("confidence_score", 0.0),
            "drc_result": state.get("drc_result"),
            "has_checklist": bool(state.get("spec", {}).get("checklist")),
            "created_at": session["created_at"]
        }
    
    def get_spec(self, thread_id: str) -> Optional[Dict]:
        """Get current circuit spec"""
        if thread_id not in self.thread_states:
            return None
        
        state = self.thread_states[thread_id]
        return {
            "thread_id": thread_id,

            "spec": state.get("spec"),

            "confidence_score": state.get(
                "confidence_threshold",
                0.0
            ),

            "retrieved_examples": state.get(
                "retrieved_examples"
            ),

            "iteration_count": state.get(
                "iteration_count",
                0
            ),

            "feedback": state.get(
                "feedback",
                []
            ),

            "import_status": state.get(
                "import_status"
            ),

            "import_message": state.get(
                "import_message"
            ),

            "structural_issues": state.get(
                "structural_issues",
                []
            ),

            "chatMode": state.get(
                "chatMode"
            ),

            "edn_path": state.get(
                "edn_path"
            ),

            "drc_result": state.get(
                "drc_result"
            ),

            "drc_summary": state.get(
                "drc_summary"
            ),

            "verification_verdict": state.get(
                "verification_verdict"
            ),

            "drc_instructions": state.get(
                "drc_instructions"
            ),

            "from_rag": state.get(
                "from_rag",
                False
            ),

            "needs_validation": (
                state.get("spec", {}).get(
                    "needs_validation",
                    True
                )
                if state.get("spec")
                else True
            ),
        }
    
def get_checklist(self, thread_id: str) -> Optional[Dict]:
    """Get current checklist items"""

    if thread_id not in self.thread_states:
        return None

    state = self.thread_states[thread_id]

    spec = state.get("spec") or {}
    checklist = spec.get("checklist", [])

    grouped = {}
    for item in checklist:
        priority = item.get("priority", 1)
        grouped.setdefault(priority, []).append(item)

    return {
        "thread_id": thread_id,

        "total_items": len(checklist),
        "grouped_by_priority": grouped,

        "iteration_count": state.get("iteration_count", 0),

        "confidence_score": state.get(
            "confidence_threshold",
            0.0
        ),

        "needs_validation": spec.get(
            "needs_validation",
            True
        ),

        "structural_issues": state.get(
            "structural_issues",
            []
        ),

        "import_status": state.get(
            "import_status"
        ),

        "drc_result": state.get(
            "drc_result"
        ),

        "drc_summary": state.get(
            "drc_summary"
        ),

        "verification_verdict": state.get(
            "verification_verdict"
        ),

        "from_rag": state.get(
            "from_rag",
            False
        ),
    }

# Singleton instance
agent_service = AgentService()
