# """
# PADS Pro EDIF Generator
# Generates complete EDIF 2.0.0 files from SQLite library (lib_merged.db)

# Supports:
#   - Cell + instance blocks for all component categories
#   - Global net symbols derived from net_type (power/ground)
#   - Local and global net connections
#   - CircuitSpec JSON input (usb.json format)
#   - EDIF name encoding (special chars → octal codes)
#   - Lookup by MPN (partNumber) or internal library name (internalPN)

# Usage:
#     python edif_generator.py --db   "F:/GenAI/ads/ads/lib_merged.db"
#                              --spec "D:/output/circuit.json"
#                              --out  "D:/output/output.edn"
# """

# import json
# import sqlite3
# import argparse
# import re
# from pathlib import Path
# from datetime import datetime
# from collections import defaultdict


# # ─────────────────────────────────────────────────────────────
# # EDIF Name Encoding
# # ─────────────────────────────────────────────────────────────

# EDIF_CHAR_MAP = {
#     "-":  "055",   "$":  "044",   ")":  "051",   "(":  "050",
#     "+":  "053",   ".":  "056",   "/":  "057",   " ":  "040",
#     ",":  "054",   ":":  "072",   "=":  "075",   "?":  "077",
#     "@":  "100",   "[":  "133",   "]":  "135",   "!":  "041",
#     "#":  "043",   "%":  "045",   "&":  "046",   "*":  "052",
#     "<":  "074",   ">":  "076",   "~":  "176",   "^":  "136",
#     "'":  "047",   '"':  "042",   "\\":  "134",  "{":  "173",
#     "}":  "175",   ";":  "073",   "`":  "140",
# }

# def _needs_encoding(name: str) -> bool:
#     if not name:
#         return False
#     first = name[0]
#     return (
#         first.isdigit() or
#         first in ('-', '+', '.', '&') or
#         any(ch in name for ch in EDIF_CHAR_MAP)
#     )

# def needs_encoding(name):
#     return _needs_encoding(name)

# def _raw_encode(name):
#     """Encode without digit-prefix fix — used for &-prefixed IDs where & makes it valid."""
#     result = ""
#     for ch in name:
#         result += EDIF_CHAR_MAP.get(ch, ch)
#     return result

# def edif_encode(name):
#     result = _raw_encode(name)
#     # EDIF identifiers must not start with a digit — prefix with underscore
#     if result and result[0].isdigit():
#         result = "_" + result
#     return result

# def edif_ref(name):
#     if _needs_encoding(name):
#         return f'(rename {edif_encode(name)} "{name}")'
#     return name

# def edif_string(value):
#     if value is None:
#         return ""
#     value = str(value).strip()
#     if value.startswith('"') and value.endswith('"') and len(value) > 1:
#         value = value[1:-1]
#     value = value.replace('"', "").replace("%", "")
#     return value

# def _sorted_pins(pin_set):
#     numeric = sorted([p for p in pin_set if p.isdigit()], key=int)
#     alpha   = sorted([p for p in pin_set if not p.isdigit()])
#     return numeric + alpha


# # ─────────────────────────────────────────────────────────────
# # ID Generators
# # ─────────────────────────────────────────────────────────────

# class IDGenerator:
#     def __init__(self, prefix="I", start=12):
#         self.prefix  = prefix
#         self.counter = start

#     def next(self):
#         display = f"$1{self.prefix}{self.counter}"
#         encoded = "&" + _raw_encode(display)
#         self.counter += 1
#         return encoded, display


# # ─────────────────────────────────────────────────────────────
# # SQLite Library Loader
# # ─────────────────────────────────────────────────────────────

# def _row_to_comp(row):
#     """
#     Convert a parts_exact DB row (dict) into the comp dict that
#     generate_cell_block / generate_instance_block expect.
#     """
#     pins = []
#     if row.get("pins_json"):
#         try:
#             raw_pins = json.loads(row["pins_json"])
#             for p in raw_pins:
#                 pin_name = p.get("name", "").strip()
#                 if not pin_name:
#                     continue  # skip unnamed pins — they're internal bus connections
#                 pins.append({
#                 "name":           pin_name,
#                 "number":         str(p.get("number", "")),
#                 "designator":     str(p.get("designator", p.get("number", ""))),
#                 "type":           p.get("type", "ANALOG"),
#                 "edif_direction": p.get("direction", "INOUT"),
#             })
#         except (json.JSONDecodeError, TypeError):
#             pass

#     category   = row.get("category", "")
#     symbol     = row.get("symbol") or row.get("symbol_name") or category
#     ref_prefix = row.get("ref_prefix", "")
#     pinswap    = row.get("pinswap", "")
#     class_     = row.get("class_", "")

#     # Use internalPN as the component name (library key) if available,
#     # otherwise fall back to partNumber (MPN)
#     name = row.get("internalPN") or row.get("partNumber", "")

#     # Normalize DB category to supported EDIF library category
#     CATEGORY_NORMALIZE = {"Switch": "Connector", "jumper": "Connector"}
#     category = CATEGORY_NORMALIZE.get(category, category)

#     return {
#         "name":        name,
#         "category":    category,
#         "ref_prefix":  ref_prefix,
#         "symbol":      symbol,
#         "pinswap":     pinswap,
#         "pins":        pins,
#         "symbol_data": {
#             "PINSWAP": pinswap,
#             "PARTS":   str(row.get("gates", 1) or 1),
#             "CLASS":   class_,
#         },
#         "databook": {
#             "Manufacturer":    row.get("manufacturer", ""),
#             "ManufacturerPN":  row.get("partNumber", ""),
#             "Description":     row.get("description", ""),
#             "Datasheet":       row.get("datasheet", ""),
#             "Supplier":        row.get("supplier", ""),
#             "SupplierPN":      row.get("supplierPN", ""),
#             "Value":           row.get("value", ""),
#             "Value_raw":       row.get("value_numeric"),
#             "PKG_TYPE":        row.get("package", ""),
#         },
#     }


# def lookup_part(db_conn, part_number, category):
#     cur = db_conn.cursor()

#     # 1. MPN match in category
#     cur.execute(
#         "SELECT * FROM parts_exact WHERE partNumber = ? AND category = ? LIMIT 1",
#         (part_number, category)
#     )
#     row = cur.fetchone()
#     if row:
#         return _row_to_comp(dict(zip([d[0] for d in cur.description], row)))

#     # 2. internalPN match in category
#     cur.execute(
#         "SELECT * FROM parts_exact WHERE internalPN = ? AND category = ? LIMIT 1",
#         (part_number, category)
#     )
#     row = cur.fetchone()
#     if row:
#         return _row_to_comp(dict(zip([d[0] for d in cur.description], row)))

#     # 3. MPN match in any category
#     cur.execute(
#         "SELECT * FROM parts_exact WHERE partNumber = ? LIMIT 1",
#         (part_number,)
#     )
#     row = cur.fetchone()
#     if row:
#         d = dict(zip([d[0] for d in cur.description], row))
#         print(f"  NOTE: '{part_number}' found in '{d.get('category')}' not '{category}'")
#         d["category"] = category
#         return _row_to_comp(d)

#     # 4. internalPN match in any category  ← NOW REACHABLE
#     cur.execute(
#         "SELECT * FROM parts_exact WHERE internalPN = ? LIMIT 1",
#         (part_number,)
#     )
#     row = cur.fetchone()
#     if row:
#         d = dict(zip([d[0] for d in cur.description], row))
#         print(f"  NOTE: '{part_number}' matched internalPN in '{d.get('category')}' not '{category}'")
#         d["category"] = category
#         return _row_to_comp(d)

#     return None


# # ─────────────────────────────────────────────────────────────
# # Existing EDIF Parser
# # ─────────────────────────────────────────────────────────────

# import re as _re

# def parse_used_ids(edn_path):
#     if not edn_path or not Path(edn_path).exists():
#         return 11, 26
#     content = Path(edn_path).read_text(encoding="utf-8", errors="ignore")
#     instance_ids = [int(m) for m in _re.findall(r'\$1I(\d+)', content)]
#     net_ids      = [int(m) for m in _re.findall(r'\$1N(\d+)', content)]
#     max_instance = max(instance_ids) if instance_ids else 11
#     max_net      = max(net_ids)      if net_ids      else 26
#     print(f"  Existing EDN: highest instance ID = $1I{max_instance}, highest net ID = $1N{max_net}")
#     print(f"  New IDs will start from: $1I{max_instance + 1}, $1N{max_net + 1}")
#     return max_instance, max_net


# def parse_existing_edn(edn_path):
#     result = {
#         "library_blocks": [], "instance_blocks": [], "net_blocks": [],
#         "board_name": None, "schematic_name": None,
#     }
#     if not edn_path or not Path(edn_path).exists():
#         return result

#     text  = Path(edn_path).read_text(encoding="utf-8", errors="ignore")
#     lines = text.splitlines()

#     for line in lines:
#         if line.strip().startswith("(design "):
#             result["board_name"] = line.strip().split()[1]
#             break

#     board_name   = result["board_name"]
#     in_board_lib = False
#     for line in lines:
#         stripped = line.strip()
#         if board_name and stripped == f"(library {board_name}":
#             in_board_lib = True
#         if in_board_lib and stripped.startswith("(cell "):
#             result["schematic_name"] = stripped.split()[1]
#             break

#     i = 0
#     while i < len(lines):
#         stripped = lines[i].strip()
#         if lines[i].startswith("    (library ") and not lines[i].startswith("      "):
#             lib_name = stripped.split()[1]
#             if lib_name == board_name:
#                 i += 1
#                 continue
#             depth, block_lines = 0, []
#             while i < len(lines):
#                 block_lines.append(lines[i])
#                 depth += lines[i].count("(") - lines[i].count(")")
#                 i += 1
#                 if depth <= 0:
#                     break
#             result["library_blocks"].append("\n".join(block_lines))
#             continue
#         i += 1

#     in_contents = False
#     depth, block_lines, block_type = 0, [], None
#     for line in lines:
#         stripped = line.strip()
#         if stripped == "(contents":
#             in_contents = True
#             continue
#         if not in_contents:
#             continue
#         if stripped.startswith("(instance ") and depth == 0:
#             block_type, block_lines = "instance", [line]
#             depth = line.count("(") - line.count(")")
#             continue
#         if stripped.startswith("(net ") and depth == 0:
#             block_type, block_lines = "net", [line]
#             depth = line.count("(") - line.count(")")
#             continue
#         if block_type and depth > 0:
#             block_lines.append(line)
#             depth += line.count("(") - line.count(")")
#             if depth <= 0:
#                 block_str = "\n".join(block_lines)
#                 result["instance_blocks" if block_type == "instance" else "net_blocks"].append(block_str)
#                 block_lines, block_type, depth = [], None, 0
#             continue
#         if stripped.startswith("(design "):
#             break

#     print(f"  Existing edn: {len(result['library_blocks'])} libraries, "
#           f"{len(result['instance_blocks'])} instances, {len(result['net_blocks'])} nets")
#     return result


# # ─────────────────────────────────────────────────────────────
# # Global Symbol
# # ─────────────────────────────────────────────────────────────

# def _net_to_global_symbol(net_name, net_type):
#     if net_type == "ground":
#         return {"sym_name": "GND",  "pin_label": "GND", "direction": "INPUT",
#                 "net_name": net_name, "view_name": "gnd"}
#     return {"sym_name": f"Source_{net_name}", "pin_label": "VCC", "direction": "INOUT",
#             "net_name": net_name, "view_name": f"source_{net_name.lower()}"}


# # ─────────────────────────────────────────────────────────────
# # Property Definitions Per Category
# # ─────────────────────────────────────────────────────────────

# CELL_PROPERTIES = {
#     "Resistor": [
#         ("PKG_TYPE","PKG_TYPE",""), ("Supplier Part Number","Supplier_Part_Number",""),
#         ("Value","Value",""), ("Datasheet","Datasheet",""),
#         ("Manufacturer Part Number","Manufacturer_Part_Number",""),
#         ("PARTS","PARTS","1"), ("Manufacturer Name","Manufacturer_Name",""),
#         ("PINSWAP","PINSWAP",""), ("Supplier Name","Supplier_Name",""),
#         ("Description","Description",""), ("CLASS","CLASS","RES"),
#     ],
#     "Capacitor": [
#         ("Value","Value",""), ("Datasheet","Datasheet",""),
#         ("Manufacturer Name","Manufacturer_Name",""),
#         ("Manufacturer Part Number","Manufacturer_Part_Number",""),
#         ("Supplier Name","Supplier_Name",""), ("Supplier Part Number","Supplier_Part_Number",""),
#         ("PARTS","PARTS","1"), ("Description","Description",""), ("PINSWAP","PINSWAP",""),
#     ],
#     "IC": [
#         ("Value","Value",""), ("Datasheet","Datasheet",""),
#         ("Manufacturer Name","Manufacturer_Name",""),
#         ("Manufacturer Part Number","Manufacturer_Part_Number",""),
#         ("Supplier Name","Supplier_Name",""), ("Supplier Part Number","Supplier_Part_Number",""),
#         ("PARTS","PARTS","1"), ("Description","Description",""),
#         ("PINSWAP","PINSWAP",""), ("CLASS","CLASS","IC"),
#     ],
#     "Diode": [("Level","Level","STD"), ("PINSWAP","PINSWAP","")],
#     "Transistor": [
#         ("PKG_TYPE","PKG_TYPE",""), ("Supplier Part Number","Supplier_Part_Number",""),
#         ("Datasheet","Datasheet",""),
#         ("Manufacturer Part Number","Manufacturer_Part_Number",""),
#         ("PARTS","PARTS","1"), ("Manufacturer Name","Manufacturer_Name",""),
#         ("Supplier Name","Supplier_Name",""), ("Description","Description",""),
#     ],
#     "Connector": [
#         ("Value","Value",""), ("Datasheet","Datasheet",""),
#         ("Manufacturer Name","Manufacturer_Name",""),
#         ("Manufacturer Part Number","Manufacturer_Part_Number",""),
#         ("PARTS","PARTS","1"), ("Description","Description",""),
#         ("PINSWAP","PINSWAP",""), ("CLASS","CLASS","CON"),
#     ],
#     "Inductor": [
#         ("Value","Value",""), ("Datasheet","Datasheet",""),
#         ("Manufacturer Name","Manufacturer_Name",""),
#         ("Manufacturer Part Number","Manufacturer_Part_Number",""),
#         ("PARTS","PARTS","1"), ("Description","Description",""),
#         ("PINSWAP","PINSWAP",""), ("CLASS","CLASS","IND"),
#     ],
#     "Circuit_Protection": [
#         ("PKG_TYPE","PKG_TYPE",""), ("Supplier Part Number","Supplier_Part_Number",""),
#         ("Value","Value",""), ("Datasheet","Datasheet",""),
#         ("Manufacturer Part Number","Manufacturer_Part_Number",""),
#         ("PARTS","PARTS","1"), ("Manufacturer Name","Manufacturer_Name",""),
#         ("PINSWAP","PINSWAP",""), ("Supplier Name","Supplier_Name",""),
#         ("Description","Description",""),
#     ],
#     "Display": [
#         ("PKG_TYPE","PKG_TYPE",""), ("Supplier Part Number","Supplier_Part_Number",""),
#         ("Value","Value",""), ("Datasheet","Datasheet",""),
#         ("Manufacturer Part Number","Manufacturer_Part_Number",""),
#         ("PARTS","PARTS","1"), ("Manufacturer Name","Manufacturer_Name",""),
#         ("Supplier Name","Supplier_Name",""), ("Description","Description",""),
#     ],
#     "PartQuest":  [("Value","Value",""), ("Manufacturer Part Number","Manufacturer_Part_Number","")],
#     "Oscillator": [("PARTS","PARTS","1"), ("Value","Value","")],
#     "_default": [
#         ("Value","Value",""), ("Datasheet","Datasheet",""),
#         ("Manufacturer Name","Manufacturer_Name",""),
#         ("Manufacturer Part Number","Manufacturer_Part_Number",""),
#         ("Supplier Name","Supplier_Name",""), ("Supplier Part Number","Supplier_Part_Number",""),
#         ("PARTS","PARTS","1"), ("Description","Description",""), ("PINSWAP","PINSWAP",""),
#     ],
# }

# INSTANCE_PROPERTIES = [
#     ("Manufacturer Name",        "Manufacturer"),
#     ("Manufacturer Part Number", "ManufacturerPN"),
#     ("DXDB_LIBNAME",             None),
#     ("Value",                    "Value"),
#     ("Datasheet",                "Datasheet"),
#     ("Description",              "Description"),
#     ("Supplier Name",            "Supplier"),
#     ("Supplier Part Number",     "SupplierPN"),
#     ("Photo",                    "Photo"),
# ]

# PARTQUEST_INSTANCE_PROPERTIES = [
#     ("Datasheet","DatasheetLink"), ("Description","Description"),
#     ("Manufacturer Name","Manufacturer Name"),
#     ("Manufacturer Part Number","Manufacturer Part Number"),
#     ("DXDB_LIBNAME",None), ("Supplier Part Number","Supplier Part Number"),
#     ("Value","Value"),
# ]

# OSCILLATOR_INSTANCE_PROPERTIES = [
#     ("Datasheet","Datasheet"), ("Description","Description"),
#     ("Manufacturer Name","Manufacturer"), ("Manufacturer Part Number","ManufacturerPN"),
#     ("DXDB_LIBNAME",None), ("Photo","Photo"),
#     ("SupplierCategory","SupplierCategory"), ("Value","Value_raw"),
# ]

# def _build_dedup_pin_map(pins, category):
#     """
#     Replicate the same deduplication logic as generate_cell_block so that
#     generate_instance_block and num_to_enc always use identical port names.
#     Returns: {pin_number_str: deduplicated_encoded_name}
#     """
#     seen = set()
#     result = {}
#     for pin in pins:
#         pin_name = pin.get("name", "")
#         pin_num  = pin.get("number", "")
#         encoded  = edif_encode(pin_name)
#         if encoded in seen:
#             encoded = edif_encode(f"{pin_name}_{pin_num}")
#         seen.add(encoded)
#         result[pin_num] = encoded
#     return result

# # ─────────────────────────────────────────────────────────────
# # Cell Block Generator
# # ─────────────────────────────────────────────────────────────
# def generate_cell_block(comp):
#     name        = comp["name"]
#     category    = comp.get("category", "")
#     ref_prefix  = comp.get("ref_prefix", "")
#     symbol_name = comp.get("symbol", "") or category
#     sym_data    = comp.get("symbol_data", {})
#     pins        = comp.get("pins", [])

#     designator  = f"{ref_prefix}?" if ref_prefix else "?"
#     pinswap_val = sym_data.get("PINSWAP", comp.get("pinswap", ""))
#     parts_val   = sym_data.get("PARTS", "1")
#     class_val   = sym_data.get("CLASS", "")
#     prop_defs   = CELL_PROPERTIES.get(category, CELL_PROPERTIES["_default"])

#     L = []
#     if category == "PartQuest":
#         L.append(f'      (cell {name}')
#     else:
#         L.append(f'      (cell  {edif_ref(name)}')

#     L.append(f'        (cellType GENERIC)')

#     if category == "Inductor":
#         L.append(f'        (view  (rename {edif_encode(symbol_name)} "{symbol_name}")')
#     elif category == "Oscillator":
#         L.append(f'        (view {edif_encode(symbol_name.lower())}')
#     else:
#         L.append(f'        (view {edif_encode(symbol_name)}')

#     L.append(f'          (viewType NETLIST)')
#     L.append(f'          (interface')
#     L.append(f'            (designator "{designator}")')

#     for display_name, safe_name, default_val in prop_defs:
#         if category == "Circuit_Protection" and display_name == "Value":
#             val = sym_data.get("raw_properties", {}).get("VALUE", default_val)
#         elif display_name == "PINSWAP":
#             val = pinswap_val
#         elif display_name == "PARTS":
#             val = parts_val
#         elif display_name == "CLASS":
#             val = class_val
#         else:
#             val = default_val

#         prop_str = f'(rename {safe_name} "{display_name}")' if display_name != safe_name else display_name
#         L.append(f'            (property {prop_str}  (string "{edif_string(val)}")')
#         L.append(f'              (owner "Siemens")')
#         L.append(f'            )')

#     if category == "PartQuest":
#         direction, add_pin_type, add_pin_label = "INOUT", False, True
#     elif category == "Oscillator":
#         direction, add_pin_type, add_pin_label = "INOUT", False, False
#     else:
#         direction      = "INOUT" if category in ("Circuit_Protection", "Display", "Inductor") else "INPUT"
#         add_pin_type   = category in ("Resistor", "Capacitor", "Inductor")
#         add_pin_label  = False

#     seen_port_names = set()  # track encoded port names already emitted

#     for pin in pins:
#         pin_name      = pin.get("name", "")
#         pin_num       = pin.get("number", "")
#         pin_type      = pin.get("type", "")
#         direction_pin = pin.get("edif_direction", direction)
#         encoded_pin   = edif_encode(pin_name)

#         if category in ("Diode", "Transistor"):
#             # Deduplicate for Diode/Transistor branch
#             if encoded_pin in seen_port_names:
#                 encoded_pin = edif_encode(f"{pin_name}_{pin_num}")
#             seen_port_names.add(encoded_pin)

#             L.append(f'            (port {encoded_pin}')
#             L.append(f'              (designator "{pin_num}")')
#             L.append(f'            )')
#         else:
#             # Deduplicate for all other categories
#             if encoded_pin in seen_port_names:
#                 encoded_pin = edif_encode(f"{pin_name}_{pin_num}")
#             seen_port_names.add(encoded_pin)

#             L.append(f'            (port {encoded_pin}')
#             L.append(f'              (direction {direction_pin})')
#             L.append(f'              (designator "{pin_num}")')
#             if add_pin_type and pin_type:
#                 L.append(f'              (property  (rename Pin_Type "Pin Type")  (string "{edif_string(pin_type)}")')
#                 L.append(f'                (owner "Siemens")')
#                 L.append(f'              )')
#             if add_pin_label:
#                 label = ("T" + pin_name[len("Terminal_"):]) if pin_name.startswith("Terminal_") else pin_name
#                 L.append(f'              (property PinLabel  (string "{label}")')
#                 L.append(f'                (owner "Siemens")')
#                 L.append(f'              )')
#             L.append(f'            )')

#     L.append(f'          )')
#     L.append(f'        )')
#     L.append(f'      )')
#     return "\n".join(L)

# # ─────────────────────────────────────────────────────────────
# # Global Symbol Cell Block Generator
# # ─────────────────────────────────────────────────────────────

# def generate_global_cell_block(sym):
#     L = []
#     L.append(f'      (cell {edif_encode(sym["sym_name"])}')
#     L.append(f'        (cellType GENERIC)')
#     L.append(f'        (view {edif_encode(sym["view_name"])}')
#     L.append(f'          (viewType NETLIST)')
#     L.append(f'          (interface')
#     L.append(f'            (designator "G?")')
#     L.append(f'            (property  (rename Net_Name "Net Name")  (string "{edif_string(sym["net_name"])}")')
#     L.append(f'              (owner "Siemens")')
#     L.append(f'            )')
#     L.append(f'            (port {sym["pin_label"]}')
#     L.append(f'              (direction {sym["direction"]})')
#     L.append(f'              (designator "{sym["pin_label"]}")')
#     L.append(f'            )')
#     L.append(f'          )')
#     L.append(f'        )')
#     L.append(f'      )')
#     return "\n".join(L)


# # ─────────────────────────────────────────────────────────────
# # Instance Block Generator
# # ─────────────────────────────────────────────────────────────

# def generate_instance_block(comp, encoded_id, display_id):
#     name        = comp["name"]
#     category    = comp.get("category", "")
#     ref_prefix  = comp.get("ref_prefix", "")
#     symbol_name = comp.get("symbol", "") or category
#     pins        = comp.get("pins", [])
#     databook    = comp.get("databook", {})

#     encoded_name   = edif_encode(name)
#     encoded_symbol = edif_encode(symbol_name)
#     designator     = f"{ref_prefix}?" if ref_prefix else "?"

#     # Build the same dedup map that generate_cell_block uses
#     dedup_map = _build_dedup_pin_map(pins, category)

#     L = []
#     L.append(f'            (instance  (rename {encoded_id} "{display_id}")')

#     if category == "Inductor":
#         L.append(f'              (viewRef {encoded_symbol}  (cellRef {encoded_name}  (libraryRef {category})))')
#     elif category == "PartQuest":
#         L.append(f'              (viewRef {edif_encode(symbol_name)}  (cellRef {name}  (libraryRef {category})))')
#     elif category == "Oscillator":
#         L.append(f'              (viewRef {edif_encode(symbol_name.lower())}  (cellRef {encoded_name}  (libraryRef {category})))')
#     else:
#         L.append(f'              (viewRef {edif_encode(symbol_name)}  (cellRef {encoded_name}  (libraryRef {category})))')

#     for pin in pins:
#         pin_num     = pin.get("number", "")
#         # Use deduplicated name — MUST match what generate_cell_block emits
#         encoded_pin = dedup_map.get(pin_num, edif_encode(pin.get("name", "")))
#         L.append(f'              (portInstance {encoded_pin}  (designator "{pin_num}"))')

#     L.append(f'              (designator "{designator}")')

#     if category == "Inductor":
#         val = databook.get("ManufacturerPN", name)
#         L.append(f'              (property (rename Part_Name "Part Name")  (string "{edif_string(val)}")')
#         L.append(f'                (owner "Siemens")')
#         L.append(f'              )')

#     elif category == "Oscillator":
#         for display_name, db_key in OSCILLATOR_INSTANCE_PROPERTIES:
#             val = category if display_name == "DXDB_LIBNAME" else databook.get(db_key)
#             if val is None:
#                 continue
#             val = str(int(val)) if db_key == "Value_raw" and isinstance(val, (int, float)) else str(val)
#             prop_str = f'(rename {display_name.replace(" ","_")} "{display_name}")' if " " in display_name else display_name
#             L.append(f'              (property {prop_str}  (string "{edif_string(val)}")')
#             L.append(f'                (owner "Siemens")')
#             L.append(f'              )')

#     elif category == "PartQuest":
#         for display_name, db_key in PARTQUEST_INSTANCE_PROPERTIES:
#             val = category if display_name == "DXDB_LIBNAME" else databook.get(db_key)
#             if val is None:
#                 continue
#             prop_str = f'(rename {display_name.replace(" ","_")} "{display_name}")' if " " in display_name else display_name
#             L.append(f'              (property {prop_str}  (string "{edif_string(val)}")')
#             L.append(f'                (owner "Siemens")')
#             L.append(f'              )')

#     else:
#         for display_name, db_key in INSTANCE_PROPERTIES:
#             if display_name == "Value" and category in ("Transistor", "Display"):
#                 continue
#             if display_name == "DXDB_LIBNAME":
#                 val = category
#             elif display_name == "Value" and category == "Circuit_Protection":
#                 raw_val = databook.get("Value_raw")
#                 val = str(raw_val) if raw_val is not None else ""
#             elif db_key and databook.get(db_key) is not None:
#                 val = str(databook[db_key])
#             else:
#                 continue
#             prop_str = f'(rename {display_name.replace(" ","_")} "{display_name}")' if " " in display_name else display_name
#             L.append(f'              (property {prop_str}  (string "{edif_string(val)}")')
#             L.append(f'                (owner "Siemens")')
#             L.append(f'              )')

#     L.append(f'            )')
#     return "\n".join(L)


# # ─────────────────────────────────────────────────────────────
# # Global Symbol Instance Block Generator
# # ─────────────────────────────────────────────────────────────

# def generate_global_instance_block(sym, encoded_id, display_id):
#     L = []
#     L.append(f'            (instance  (rename {encoded_id} "{display_id}")')
#     L.append(f'              (viewRef {edif_encode(sym["view_name"])}  (cellRef {edif_encode(sym["sym_name"])}  (libraryRef Globals)))')
#     L.append(f'              (portInstance {sym["pin_label"]}  (designator "{sym["pin_label"]}"))')
#     L.append(f'              (designator "G?")')
#     L.append(f'              (property  (rename Part_Name "Part Name")  (string "{edif_string(sym["sym_name"])}")')
#     L.append(f'                (owner "Siemens")')
#     L.append(f'              )')
#     L.append(f'            )')
#     return "\n".join(L)


# # ─────────────────────────────────────────────────────────────
# # Net Block Generator
# # ─────────────────────────────────────────────────────────────

# def generate_net_block(net_name, connections, is_global, net_id_gen, instance_id_map):
#     # Use _raw_encode for net refs: & prefix already makes digit-starting names valid
#     net_ref = f'(rename &{_raw_encode(net_name)} "{net_name}")' if _needs_encoding(net_name) else net_name

#     L = []
#     L.append(f'            (net {net_ref}')
#     L.append(f'              (joined')
#     for conn in connections:
#         inst_display = conn["instance_id"]
#         inst_encoded = instance_id_map.get(inst_display, "&" + edif_encode(inst_display))
#         encoded_pin = conn["pin"] if conn.get("_pre_encoded") else edif_encode(str(conn["pin"]))
#         L.append(f'                (portRef {encoded_pin} (instanceRef {inst_encoded} ))')
#     L.append(f'              )')
#     if is_global:
#         L.append(f'              (property global (boolean (true))')
#         L.append(f'                (owner "Siemens")')
#         L.append(f'              )')
#     L.append(f'            )')
#     return "\n".join(L)


# # ─────────────────────────────────────────────────────────────
# # Generic Block Builder — queries SQLite instead of JSON dict
# # ─────────────────────────────────────────────────────────────


# def _generate_blocks(part_names, category, id_gen, db_conn, json_pins_by_ref=None):
#     cell_blocks, instance_blocks, not_found = [], [], []
#     seen_cell_names = set()
#     id_map, ref_map, pin_remap = {}, {}, {}

#     # ── PRE-PASS: collect union of all JSON-extra pins per comp_name ──
#     # Maps comp_name → {pin_num: pin_name} for ALL pins across ALL instances
#     union_extras = defaultdict(dict)  # comp_name → {pin_num: pin_name}
    
#     for entry in part_names:
#         ref = entry[0] if isinstance(entry, (list, tuple)) else None
#         part_name = entry[1] if isinstance(entry, (list, tuple)) else entry
#         if not ref or not json_pins_by_ref:
#             continue
#         json_pins = json_pins_by_ref.get(ref, {})
#         if not json_pins:
#             continue
#         comp = lookup_part(db_conn, part_name, category)
#         if not comp:
#             continue
#         comp_name = comp["name"]
#         # Get clean DB pins for this comp
#         db_pins_raw = list(comp.get("pins") or [])
#         db_nums = set()
#         for p in db_pins_raw:
#             pname = p.get("name", "").strip()
#             pnum = str(p.get("number", ""))
#             if pname:
#                 db_nums.add(pnum)
#         # Accumulate extras
#         for pin_num, pin_name in json_pins.items():
#             if pin_num not in db_nums:
#                 union_extras[comp_name][pin_num] = pin_name
#     # ── end pre-pass ──

#     for entry in part_names:
#         if isinstance(entry, (list, tuple)):
#             ref, part_name = entry[0], entry[1]
#         else:
#             ref, part_name = None, entry

#         comp = lookup_part(db_conn, part_name, category)
#         if not comp:
#             not_found.append(part_name)
#             print(f"  WARNING: '{part_name}' not found in {category}")
#             continue

#         encoded_id, display_id = id_gen.next()
#         id_map[display_id] = encoded_id
#         if ref:
#             ref_map[ref] = display_id

#         json_pins = {}
#         if ref and json_pins_by_ref:
#             json_pins = json_pins_by_ref.get(ref, {})

#         db_pins_raw = list(comp.get("pins") or [])

#         # Clean DB pins
#         db_pins = []
#         for p in db_pins_raw:
#             pnum  = str(p.get("number", ""))
#             pname = p.get("name", "").strip()
#             if not pname and pnum in json_pins:
#                 db_pins.append({"name": json_pins[pnum], "number": pnum,
#                                  "type": p.get("type","ANALOG"),
#                                  "edif_direction": p.get("edif_direction","INOUT")})
#             elif pname:
#                 db_pins.append(p)

#         db_pin_nums = {str(p.get("number", "")) for p in db_pins}
#         comp_name = comp["name"]
        
#         # Build lookup by physical designator AND by encoded name
#         db_pin_desigs = set()   # physical designator strings, e.g. "1", "2", "+"
#         db_pin_enc_names = set()  # encoded port names, e.g. "_053", "_055"
#         for p in db_pins:
#             db_pin_desigs.add(str(p.get("number", "")))
#             desig = str(p.get("designator", p.get("number", "")))
#             db_pin_desigs.add(desig)
#             pname = p.get("name", "")
#             if pname:
#                 db_pin_enc_names.add(edif_encode(pname))

#         # THIS instance's extra pins
#         instance_extra = []
#         for pin_num, pin_name in json_pins.items():
#             if pin_num not in db_pin_nums:
#                 instance_extra.append({"name": pin_name, "number": pin_num,
#                                         "type": "ANALOG", "edif_direction": "INOUT"})
#                 print(f"  NOTE: pin {pin_num} ({pin_name}) on {part_name} "
#                       f"missing from DB — adding to cell+instance")

#         # UNION extra pins for cell (superset of all instances)
#         cell_extra = [
#             {"name": pname, "number": pnum, "type": "ANALOG", "edif_direction": "INOUT"}
#             for pnum, pname in union_extras.get(comp_name, {}).items()
#             if pnum not in db_pin_nums
#         ]

#         instance_pins = db_pins + instance_extra
#         cell_pins     = db_pins + cell_extra

#         # pin_remap uses instance pins
#         # ── Build num_to_enc using the SAME dedup as cell/instance blocks ──
#         num_to_enc = _build_dedup_pin_map(instance_pins, category)

#         db_name_to_enc = {}
#         for p in db_pins:
#             pname = p.get("name", "")
#             pnum  = str(p.get("number", ""))
#             if pname and pnum in num_to_enc:
#                 db_name_to_enc[pname] = num_to_enc[pnum]  # "A"→"A", "+"→"_053"

#         for p in instance_extra:
#             pname = p.get("name", "")
#             pnum  = str(p.get("number", ""))
#             if pname in db_name_to_enc:
#                 num_to_enc[pnum] = db_name_to_enc[pname]  # redirect alias key to real port

#         # Add encoded-name self-lookups for name-based JSON references,
#         # but ONLY if the encoded name is not already a key (avoids overwriting
#         # e.g. num_to_enc["A"]="A_A" with num_to_enc["A"]="A")
#         for enc_name in list(num_to_enc.values()):
#             if enc_name not in num_to_enc:
#                 num_to_enc[enc_name] = enc_name

#         pin_remap[display_id] = num_to_enc

#         has_extras = bool(cell_extra)

#         if has_extras:
#             if comp_name not in seen_cell_names:
#                 cell_comp = dict(comp)
#                 cell_comp["pins"] = cell_pins   # ← UNION pins for cell
#                 cell_blocks.append(generate_cell_block(cell_comp))
#                 seen_cell_names.add(comp_name)
#             inst_comp = dict(comp)
#             inst_comp["pins"] = instance_pins   # ← this instance's pins only
#             instance_blocks.append(generate_instance_block(inst_comp, encoded_id, display_id))
#         else:
#             if comp_name not in seen_cell_names:
#                 cell_blocks.append(generate_cell_block(comp))
#                 seen_cell_names.add(comp_name)
#             instance_blocks.append(generate_instance_block(comp, encoded_id, display_id))

#     if not_found:
#         print(f"  {len(not_found)} parts not found: {not_found}")

#     return cell_blocks, instance_blocks, id_map, ref_map, pin_remap

# # ─────────────────────────────────────────────────────────────
# # Category-Specific Block Generators
# # ─────────────────────────────────────────────────────────────

# # FIX: all category generators forward json_pins_by_ref to _generate_blocks
# def generate_resistor_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "Resistor", id_gen, db_conn, json_pins_by_ref)

# def generate_capacitor_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "Capacitor", id_gen, db_conn, json_pins_by_ref)

# def generate_ic_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "IC", id_gen, db_conn, json_pins_by_ref)

# def generate_diode_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "Diode", id_gen, db_conn, json_pins_by_ref)

# def generate_connector_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "Connector", id_gen, db_conn, json_pins_by_ref)

# def generate_transistor_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "Transistor", id_gen, db_conn, json_pins_by_ref)

# def generate_inductor_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "Inductor", id_gen, db_conn, json_pins_by_ref)

# def generate_circuit_protection_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "Circuit_Protection", id_gen, db_conn, json_pins_by_ref)

# def generate_display_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "Display", id_gen, db_conn, json_pins_by_ref)

# def generate_partquest_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "PartQuest", id_gen, db_conn, json_pins_by_ref)

# def generate_oscillator_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
#     return _generate_blocks(part_names, "Oscillator", id_gen, db_conn, json_pins_by_ref)


# GENERATORS = {
#     "Resistor":           generate_resistor_blocks,
#     "Capacitor":          generate_capacitor_blocks,
#     "IC":                 generate_ic_blocks,
#     "Diode":              generate_diode_blocks,
#     "Connector":          generate_connector_blocks,
#     "Transistor":         generate_transistor_blocks,
#     "Inductor":           generate_inductor_blocks,
#     "Circuit_Protection": generate_circuit_protection_blocks,
#     "Display":            generate_display_blocks,
#     "PartQuest":          generate_partquest_blocks,
#     "Oscillator":         generate_oscillator_blocks,
# }


# # ─────────────────────────────────────────────────────────────
# # Net Input Loader
# # ─────────────────────────────────────────────────────────────

# def load_nets(nets_input):
#     if nets_input is None:
#         return []
#     if isinstance(nets_input, str):
#         with open(nets_input, encoding="utf-8") as f:
#             return json.load(f)
#     if isinstance(nets_input, list):
#         return nets_input
#     return []


# # ─────────────────────────────────────────────────────────────
# # EDIF File Generator (top-level)
# # ─────────────────────────────────────────────────────────────

# def generate_edif_file(
#     design_name,
#     components_by_category,
#     db_path,
#     output_path,
#     nets=None,
#     existing_edn=None,
# ):
#     """
#     Generate a complete EDIF file using SQLite library.

#     Args:
#         design_name:             Used as both schematic cell name and board/design name.
#         components_by_category:  {"Resistor": ["MPN1", ...], "IC": [...], ...}
#         db_path:                 Path to lib_merged.db SQLite file.
#         output_path:             Path to write the .edn file.
#         nets:                    List of net dicts (CircuitSpec connected_pins format) or None.
#         existing_edn:            Path to existing .edn to append to (avoids ID collisions).
#     """
#     now = datetime.now()

#     max_instance, max_net = parse_used_ids(existing_edn)
#     existing = parse_existing_edn(existing_edn)

#     id_gen     = IDGenerator(prefix="I", start=max_instance + 1)
#     net_id_gen = IDGenerator(prefix="N", start=max_net + 1)

#     all_cell_blocks          = {}
#     all_instance_blocks      = []
#     global_instance_blocks   = []
#     instance_id_map          = {}
#     existing_library_blocks  = existing["library_blocks"]
#     existing_instance_blocks = existing["instance_blocks"]
#     existing_net_blocks      = existing["net_blocks"]

#     db_conn = sqlite3.connect(db_path)

#     ref_to_display = {}   # component_ref (U1,R1,...) → display_id ($1I12,...)
#     pin_remap_map  = {}   # display_id → {pin_number_str: encoded_port_name}

#     # ── FIX: pre-build json_pins_by_ref from circuit JSON nets ──
#     # Maps component_ref → {pin_number_str: pin_name} for every connected_pin
#     # entry in the nets list. Used to augment cell declarations and net portRefs
#     # when the DB symbol has fewer pins than the circuit JSON references.
#     nets_raw = load_nets(nets)
#     json_pins_by_ref = defaultdict(dict)  # ref → {pin_num: pin_name}
#     for net in nets_raw:
#         for cp in net.get("connected_pins", []):
#             ref      = cp.get("component_ref", "")
#             pin_num  = str(cp.get("pin_number", ""))
#             pin_name = cp.get("pin_name") or pin_num
#             if ref and pin_num:
#                 json_pins_by_ref[ref][pin_num] = pin_name
#     # ── end FIX ──

#     try:
#         # ── Component categories ──────────────────────────────
#         for category, part_names in components_by_category.items():
#             if not part_names:
#                 continue
#             generator = GENERATORS.get(category)
#             if not generator:
#                 print(f"  WARNING: No generator for '{category}' — skipping")
#                 continue

#             print(f"  {category}: {len(part_names)} part(s)...")
#             # FIX: pass json_pins_by_ref into every generator
#             cell_blocks, instance_blocks, id_map, ref_map, p_remap = generator(
#                 part_names, id_gen, db_conn, json_pins_by_ref=dict(json_pins_by_ref)
#             )
#             pin_remap_map.update(p_remap)
#             if cell_blocks:
#                 all_cell_blocks[category] = cell_blocks
#             all_instance_blocks.extend(instance_blocks)
#             instance_id_map.update(id_map)
#             ref_to_display.update(ref_map)

#     finally:
#         db_conn.close()

#     # ── Global symbols derived from nets ──────────────────────
#     nets = nets_raw  # already loaded above
#     seen_syms = {}
#     for net in nets:
#         net_type = net.get("net_type")
#         if net_type not in ("power", "ground"):
#             continue
#         sym = _net_to_global_symbol(net.get("name", ""), net_type)
#         if sym["sym_name"] not in seen_syms:
#             seen_syms[sym["sym_name"]] = sym  # keep first — canonical net name

#     global_cell_blocks = []
#     for sym in seen_syms.values():
#         encoded_id, display_id = id_gen.next()
#         instance_id_map[display_id] = encoded_id
#         cb = generate_global_cell_block(sym)
#         if cb:
#             global_cell_blocks.append(cb)
#         ib = generate_global_instance_block(sym, encoded_id, display_id)
#         if ib:
#             global_instance_blocks.append(ib)

#     # ── Net blocks ────────────────────────────────────────────
#     net_blocks = []
#     for net in nets:
#         is_global = net.get("net_type") in ("power", "ground")
#         net_name  = net.get("name") or net_id_gen.next()[1]

#         connections = net.get("connections") or []
#         if not connections:
#             for cp in net.get("connected_pins", []):
#                 ref      = cp.get("component_ref", "")
#                 pin_num  = str(cp.get("pin_number", ""))
#                 pin_name = cp.get("pin_name") or pin_num
#                 # Resolve component_ref (e.g. "U1") → display_id (e.g. "$1I12")
#                 display_id = ref_to_display.get(ref)
#                 if display_id and instance_id_map.get(display_id):
#                     # ── FIX: prefer JSON-derived pin name over DB remap ──
#                     # pin_remap_map already has JSON pin names injected with
#                     # higher priority in _generate_blocks, so pin_num lookup
#                     # will return the correct encoded name for both DB-known
#                     # and JSON-only pins.
#                     remap = pin_remap_map.get(display_id, {})
#                     encoded_pin_name = edif_encode(pin_name)
#                     if pin_num and pin_num in remap:
#                         # JSON-overridden or DB pin number → correct encoded name
#                         pin_out = remap[pin_num]
#                     elif encoded_pin_name in remap:
#                         # Encoded pin name matches a known port
#                         pin_out = remap[encoded_pin_name]
#                     else:
#                         # Last resort: encode the JSON pin_name directly
#                         pin_out = encoded_pin_name
#                     # ── end FIX ──
#                     connections.append({"instance_id": display_id, "pin": pin_out, "_pre_encoded": True})

#         net_blocks.append(
#             generate_net_block(net_name, connections, is_global, net_id_gen, instance_id_map)
#         )

#     # ── Assemble EDIF ─────────────────────────────────────────
#     L = []
#     L.append(f'  (edif DxD')
#     L.append(f'    (edifVersion 2 0 0)')
#     L.append(f'    (edifLevel 0)')
#     L.append(f'    (keywordMap  (keywordLevel 0))')
#     L.append(f'    (status')
#     L.append(f'      (written')
#     L.append(f'        (timestamp {now.year} {now.month} {now.day} {now.hour} {now.minute} {now.second})')
#     L.append(f'        (author "Siemens")')
#     L.append(f'        (program "xDX Designer Edif Exporter"')
#     L.append(f'          (version "PADS Professional VX.2.12 <21159422>  2022-08-11 21:31:43")')
#     L.append(f'        )')
#     L.append(f'      )')
#     L.append(f'    )')

#     for lib_block in existing_library_blocks:
#         L.append(lib_block)

#     for category, cell_blocks in all_cell_blocks.items():
#         L.append(f'    (library {category}')
#         L.append(f'      (edifLevel 0)')
#         L.append(f'      (technology')
#         L.append(f'        (numberDefinition')
#         L.append(f'          (gridMap 0 0)')
#         L.append(f'        )')
#         L.append(f'        (figureGroup GRAPHICS')
#         L.append(f'        )')
#         L.append(f'      )')
#         for cb in cell_blocks:
#             L.append(cb)
#         L.append(f'    )')

#     if global_cell_blocks:
#         L.append(f'    (library Globals')
#         L.append(f'      (edifLevel 0)')
#         L.append(f'      (technology')
#         L.append(f'        (numberDefinition')
#         L.append(f'          (gridMap 0 0)')
#         L.append(f'        )')
#         L.append(f'        (figureGroup GRAPHICS')
#         L.append(f'        )')
#         L.append(f'      )')
#         for cb in global_cell_blocks:
#             L.append(cb)
#         L.append(f'    )')

#     L.append(f'    (library {design_name}')
#     L.append(f'      (edifLevel 0)')
#     L.append(f'      (technology')
#     L.append(f'        (numberDefinition')
#     L.append(f'          (gridMap 0 0)')
#     L.append(f'        )')
#     L.append(f'        (figureGroup GRAPHICS')
#     L.append(f'        )')
#     L.append(f'      )')
#     L.append(f'      (cell {design_name}')
#     L.append(f'        (cellType GENERIC)')
#     L.append(f'        (view NETLIST_VIEW')
#     L.append(f'          (viewType NETLIST)')
#     L.append(f'          (interface')
#     L.append(f'          )')
#     L.append(f'          (contents')
#     for ib in existing_instance_blocks:
#         L.append(ib)
#     for ib in all_instance_blocks:
#         L.append(ib)
#     for ib in global_instance_blocks:
#         L.append(ib)
#     for nb in existing_net_blocks:
#         L.append(nb)
#     for nb in net_blocks:
#         L.append(nb)
#     L.append(f'          )')
#     L.append(f'        )')
#     L.append(f'      )')
#     L.append(f'    )')

#     L.append(f'    (design {design_name}')
#     L.append(f'      (cellRef {design_name}')
#     L.append(f'        (libraryRef {design_name})')
#     L.append(f'      )')
#     L.append(f'    )')
#     L.append(f'  )')

#     content = "\n".join(L)
#     out = Path(output_path)
#     out.parent.mkdir(parents=True, exist_ok=True)
#     out.write_text(content, encoding="utf-8")

#     print(f"\n  EDIF written  : {output_path}")
#     print(f"  File size     : {out.stat().st_size / 1024:.1f} KB")
#     total = len(existing_instance_blocks) + len(all_instance_blocks) + len(global_instance_blocks)
#     print(f"  Instances     : {total} ({len(existing_instance_blocks)} existing + {len(all_instance_blocks) + len(global_instance_blocks)} new)")
#     print(f"  Nets          : {len(net_blocks)}")
#     return content


# # ─────────────────────────────────────────────────────────────
# # CircuitSpec type → library category
# # ─────────────────────────────────────────────────────────────

# TYPE_TO_CATEGORY = {
#     "IC":                 "IC",
#     "Microcontroller":    "IC",
#     "LED":                "Diode",
#     "Diode":              "Diode",
#     "Resistor":           "Resistor",
#     "Capacitor":          "Capacitor",
#     "Connector":          "Connector",
#     "Switch":             "Connector",
#     "Transistor":         "Transistor",
#     "Inductor":           "Inductor",
#     "Crystal":            "Oscillator",
#     "Oscillator":         "Oscillator",
#     "Circuit_Protection": "Circuit_Protection",
#     "Display":            "Display",
# }

# SKIP_TYPES = {"Ground", "Power", "Symbol"}


# # ─────────────────────────────────────────────────────────────
# # Main — CLI entry point
# # ─────────────────────────────────────────────────────────────

# def main():
#     parser = argparse.ArgumentParser()
#     parser.add_argument("--db",       required=True,
#                         help="Path to lib_merged.db SQLite file")
#     parser.add_argument("--spec",     default=None,
#                         help="Path to CircuitSpec JSON (usb.json etc.)")
#     parser.add_argument("--existing", default=None,
#                         help="Path to existing .edn file to append to")
#     parser.add_argument("--out",      default="output.edn",
#                         help="Output .edn path")
#     args = parser.parse_args()

#     if args.spec:
#         print(f"Loading spec: {args.spec}")
#         with open(args.spec, encoding="utf-8") as f:
#             spec = json.load(f)

#         components_by_category = defaultdict(list)
#         for comp in spec.get("components", []):
#             ctype = comp.get("type", "")
#             if ctype in SKIP_TYPES or not comp.get("part_number"):
#                 continue
#             cat = TYPE_TO_CATEGORY.get(ctype, "IC")
#             # Store as (ref, part_number) tuple so nets can map ref→instance_id
#             components_by_category[cat].append((comp["ref"], comp["part_number"]))

#         design_name = re.sub(r"[^\w]", "_", spec.get("title", "circuit"))
#         nets        = spec.get("nets", [])
#     else:
#         components_by_category = {"Resistor": ["ESR03EZPJ331"], "Diode": ["LTST-C170CKT"]}
#         design_name = "Board1"
#         nets        = []

#     print(f"\nGenerating EDIF for '{design_name}'...")
#     generate_edif_file(
#         design_name            = design_name,
#         components_by_category = dict(components_by_category),
#         db_path                = args.db,
#         output_path            = args.out,
#         nets                   = nets,
#         existing_edn           = args.existing,
#     )


# if __name__ == "__main__":
#     main()

#-----------------------------------------------------------
"""
PADS Pro EDIF Generator
Generates complete EDIF 2.0.0 files from SQLite library (lib_merged.db)
"""

import json
import sqlite3
import argparse
import re
from pathlib import Path
from datetime import datetime
from collections import defaultdict


EDIF_CHAR_MAP = {
    "-":  "055",   "$":  "044",   ")":  "051",   "(":  "050",
    "+":  "053",   ".":  "056",   "/":  "057",   " ":  "040",
    ",":  "054",   ":":  "072",   "=":  "075",   "?":  "077",
    "@":  "100",   "[":  "133",   "]":  "135",   "!":  "041",
    "#":  "043",   "%":  "045",   "&":  "046",   "*":  "052",
    "<":  "074",   ">":  "076",   "~":  "176",   "^":  "136",
    "'":  "047",   '"':  "042",   "\\":  "134",  "{":  "173",
    "}":  "175",   ";":  "073",   "`":  "140",
}

def _needs_encoding(name: str) -> bool:
    if not name:
        return False
    first = name[0]
    return (
        first.isdigit() or
        first in ('-', '+', '.', '&') or
        any(ch in name for ch in EDIF_CHAR_MAP)
    )

def needs_encoding(name):
    return _needs_encoding(name)

def _raw_encode(name):
    result = ""
    for ch in name:
        result += EDIF_CHAR_MAP.get(ch, ch)
    return result

def edif_encode(name):
    result = _raw_encode(name)
    if result and result[0].isdigit():
        result = "_" + result
    return result

def edif_ref(name):
    if _needs_encoding(name):
        return f'(rename {edif_encode(name)} "{name}")'
    return name

def edif_string(value):
    if value is None:
        return ""
    value = str(value).strip()
    if value.startswith('"') and value.endswith('"') and len(value) > 1:
        value = value[1:-1]
    value = value.replace('"', "").replace("%", "")
    return value

def _sorted_pins(pin_set):
    numeric = sorted([p for p in pin_set if p.isdigit()], key=int)
    alpha   = sorted([p for p in pin_set if not p.isdigit()])
    return numeric + alpha


class IDGenerator:
    def __init__(self, prefix="I", start=12):
        self.prefix  = prefix
        self.counter = start

    def next(self):
        display = f"$1{self.prefix}{self.counter}"
        encoded = "&" + _raw_encode(display)
        self.counter += 1
        return encoded, display


def _row_to_comp(row):
    pins = []
    if row.get("pins_json"):
        try:
            raw_pins = json.loads(row["pins_json"])
            for p in raw_pins:
                pin_name = p.get("name", "").strip()
                if not pin_name:
                    continue
                pins.append({
                    "name":           pin_name,
                    "number":         str(p.get("number", "")),
                    "designator":     str(p.get("designator", p.get("number", ""))),
                    "type":           p.get("type", "ANALOG"),
                    "edif_direction": p.get("direction", "INOUT"),
                })
        except (json.JSONDecodeError, TypeError):
            pass

    category   = row.get("category", "")
    symbol     = row.get("symbol") or row.get("symbol_name") or category
    ref_prefix = row.get("ref_prefix", "")
    pinswap    = row.get("pinswap", "")
    class_     = row.get("class_", "")
    name = row.get("internalPN") or row.get("partNumber", "")
    CATEGORY_NORMALIZE = {"Switch": "Connector", "jumper": "Connector"}
    category = CATEGORY_NORMALIZE.get(category, category)

    return {
        "name":        name,
        "category":    category,
        "ref_prefix":  ref_prefix,
        "symbol":      symbol,
        "pinswap":     pinswap,
        "pins":        pins,
        "symbol_data": {
            "PINSWAP": pinswap,
            "PARTS":   str(row.get("gates", 1) or 1),
            "CLASS":   class_,
        },
        "databook": {
            "Manufacturer":    row.get("manufacturer", ""),
            "ManufacturerPN":  row.get("partNumber", ""),
            "Description":     row.get("description", ""),
            "Datasheet":       row.get("datasheet", ""),
            "Supplier":        row.get("supplier", ""),
            "SupplierPN":      row.get("supplierPN", ""),
            "Value":           row.get("value", ""),
            "Value_raw":       row.get("value_numeric"),
            "PKG_TYPE":        row.get("package", ""),
        },
    }


def lookup_part(db_conn, part_number, category):
    cur = db_conn.cursor()
    cur.execute(
        "SELECT * FROM parts_exact WHERE partNumber = ? AND category = ? LIMIT 1",
        (part_number, category)
    )
    row = cur.fetchone()
    if row:
        return _row_to_comp(dict(zip([d[0] for d in cur.description], row)))
    cur.execute(
        "SELECT * FROM parts_exact WHERE internalPN = ? AND category = ? LIMIT 1",
        (part_number, category)
    )
    row = cur.fetchone()
    if row:
        return _row_to_comp(dict(zip([d[0] for d in cur.description], row)))
    cur.execute(
        "SELECT * FROM parts_exact WHERE partNumber = ? LIMIT 1",
        (part_number,)
    )
    row = cur.fetchone()
    if row:
        d = dict(zip([d[0] for d in cur.description], row))
      #  print(f"  NOTE: '{part_number}' found in '{d.get('category')}' not '{category}'")
        d["category"] = category
        return _row_to_comp(d)
    cur.execute(
        "SELECT * FROM parts_exact WHERE internalPN = ? LIMIT 1",
        (part_number,)
    )
    row = cur.fetchone()
    if row:
        d = dict(zip([d[0] for d in cur.description], row))
     #   print(f"  NOTE: '{part_number}' matched internalPN in '{d.get('category')}' not '{category}'")
        d["category"] = category
        return _row_to_comp(d)
    return None


import re as _re

def parse_used_ids(edn_path):
    if not edn_path or not Path(edn_path).exists():
        return 11, 26
    content = Path(edn_path).read_text(encoding="utf-8", errors="ignore")
    instance_ids = [int(m) for m in _re.findall(r'\$1I(\d+)', content)]
    net_ids      = [int(m) for m in _re.findall(r'\$1N(\d+)', content)]
    max_instance = max(instance_ids) if instance_ids else 11
    max_net      = max(net_ids)      if net_ids      else 26
    print(f"  Existing EDN: highest instance ID = $1I{max_instance}, highest net ID = $1N{max_net}")
    print(f"  New IDs will start from: $1I{max_instance + 1}, $1N{max_net + 1}")
    return max_instance, max_net


def parse_existing_edn(edn_path):
    result = {
        "library_blocks": [], "instance_blocks": [], "net_blocks": [],
        "board_name": None, "schematic_name": None,
    }
    if not edn_path or not Path(edn_path).exists():
        return result

    text  = Path(edn_path).read_text(encoding="utf-8", errors="ignore")
    lines = text.splitlines()

    for line in lines:
        if line.strip().startswith("(design "):
            result["board_name"] = line.strip().split()[1]
            break

    board_name   = result["board_name"]
    in_board_lib = False
    for line in lines:
        stripped = line.strip()
        if board_name and stripped == f"(library {board_name}":
            in_board_lib = True
        if in_board_lib and stripped.startswith("(cell "):
            result["schematic_name"] = stripped.split()[1]
            break

    i = 0
    while i < len(lines):
        stripped = lines[i].strip()
        if lines[i].startswith("    (library ") and not lines[i].startswith("      "):
            lib_name = stripped.split()[1]
            if lib_name == board_name:
                i += 1
                continue
            depth, block_lines = 0, []
            while i < len(lines):
                block_lines.append(lines[i])
                depth += lines[i].count("(") - lines[i].count(")")
                i += 1
                if depth <= 0:
                    break
            result["library_blocks"].append("\n".join(block_lines))
            continue
        i += 1

    in_contents = False
    depth, block_lines, block_type = 0, [], None
    for line in lines:
        stripped = line.strip()
        if stripped == "(contents":
            in_contents = True
            continue
        if not in_contents:
            continue
        if stripped.startswith("(instance ") and depth == 0:
            block_type, block_lines = "instance", [line]
            depth = line.count("(") - line.count(")")
            continue
        if stripped.startswith("(net ") and depth == 0:
            block_type, block_lines = "net", [line]
            depth = line.count("(") - line.count(")")
            continue
        if block_type and depth > 0:
            block_lines.append(line)
            depth += line.count("(") - line.count(")")
            if depth <= 0:
                block_str = "\n".join(block_lines)
                result["instance_blocks" if block_type == "instance" else "net_blocks"].append(block_str)
                block_lines, block_type, depth = [], None, 0
            continue
        if stripped.startswith("(design "):
            break

    print(f"  Existing edn: {len(result['library_blocks'])} libraries, "
          f"{len(result['instance_blocks'])} instances, {len(result['net_blocks'])} nets")
    return result


def _net_to_global_symbol(net_name, net_type):
    if net_type == "ground":
        return {"sym_name": "GND",  "pin_label": "GND", "direction": "INPUT",
                "net_name": net_name, "view_name": "gnd"}
    return {"sym_name": f"Source_{net_name}", "pin_label": "VCC", "direction": "INOUT",
            "net_name": net_name, "view_name": f"source_{net_name.lower()}"}


CELL_PROPERTIES = {
    "Resistor": [
        ("PKG_TYPE","PKG_TYPE",""), ("Supplier Part Number","Supplier_Part_Number",""),
        ("Value","Value",""), ("Datasheet","Datasheet",""),
        ("Manufacturer Part Number","Manufacturer_Part_Number",""),
        ("PARTS","PARTS","1"), ("Manufacturer Name","Manufacturer_Name",""),
        ("PINSWAP","PINSWAP",""), ("Supplier Name","Supplier_Name",""),
        ("Description","Description",""), ("CLASS","CLASS","RES"),
    ],
    "Capacitor": [
        ("Value","Value",""), ("Datasheet","Datasheet",""),
        ("Manufacturer Name","Manufacturer_Name",""),
        ("Manufacturer Part Number","Manufacturer_Part_Number",""),
        ("Supplier Name","Supplier_Name",""), ("Supplier Part Number","Supplier_Part_Number",""),
        ("PARTS","PARTS","1"), ("Description","Description",""), ("PINSWAP","PINSWAP",""),
    ],
    "IC": [
        ("Value","Value",""), ("Datasheet","Datasheet",""),
        ("Manufacturer Name","Manufacturer_Name",""),
        ("Manufacturer Part Number","Manufacturer_Part_Number",""),
        ("Supplier Name","Supplier_Name",""), ("Supplier Part Number","Supplier_Part_Number",""),
        ("PARTS","PARTS","1"), ("Description","Description",""),
        ("PINSWAP","PINSWAP",""), ("CLASS","CLASS","IC"),
    ],
    "Diode": [("Level","Level","STD"), ("PINSWAP","PINSWAP","")],
    "Transistor": [
        ("PKG_TYPE","PKG_TYPE",""), ("Supplier Part Number","Supplier_Part_Number",""),
        ("Datasheet","Datasheet",""),
        ("Manufacturer Part Number","Manufacturer_Part_Number",""),
        ("PARTS","PARTS","1"), ("Manufacturer Name","Manufacturer_Name",""),
        ("Supplier Name","Supplier_Name",""), ("Description","Description",""),
    ],
    "Connector": [
        ("Value","Value",""), ("Datasheet","Datasheet",""),
        ("Manufacturer Name","Manufacturer_Name",""),
        ("Manufacturer Part Number","Manufacturer_Part_Number",""),
        ("PARTS","PARTS","1"), ("Description","Description",""),
        ("PINSWAP","PINSWAP",""), ("CLASS","CLASS","CON"),
    ],
    "Inductor": [
        ("Value","Value",""), ("Datasheet","Datasheet",""),
        ("Manufacturer Name","Manufacturer_Name",""),
        ("Manufacturer Part Number","Manufacturer_Part_Number",""),
        ("PARTS","PARTS","1"), ("Description","Description",""),
        ("PINSWAP","PINSWAP",""), ("CLASS","CLASS","IND"),
    ],
    "Circuit_Protection": [
        ("PKG_TYPE","PKG_TYPE",""), ("Supplier Part Number","Supplier_Part_Number",""),
        ("Value","Value",""), ("Datasheet","Datasheet",""),
        ("Manufacturer Part Number","Manufacturer_Part_Number",""),
        ("PARTS","PARTS","1"), ("Manufacturer Name","Manufacturer_Name",""),
        ("PINSWAP","PINSWAP",""), ("Supplier Name","Supplier_Name",""),
        ("Description","Description",""),
    ],
    "Display": [
        ("PKG_TYPE","PKG_TYPE",""), ("Supplier Part Number","Supplier_Part_Number",""),
        ("Value","Value",""), ("Datasheet","Datasheet",""),
        ("Manufacturer Part Number","Manufacturer_Part_Number",""),
        ("PARTS","PARTS","1"), ("Manufacturer Name","Manufacturer_Name",""),
        ("Supplier Name","Supplier_Name",""), ("Description","Description",""),
    ],
    "PartQuest":  [("Value","Value",""), ("Manufacturer Part Number","Manufacturer_Part_Number","")],
    "Oscillator": [("PARTS","PARTS","1"), ("Value","Value","")],
    "_default": [
        ("Value","Value",""), ("Datasheet","Datasheet",""),
        ("Manufacturer Name","Manufacturer_Name",""),
        ("Manufacturer Part Number","Manufacturer_Part_Number",""),
        ("Supplier Name","Supplier_Name",""), ("Supplier Part Number","Supplier_Part_Number",""),
        ("PARTS","PARTS","1"), ("Description","Description",""), ("PINSWAP","PINSWAP",""),
    ],
}

INSTANCE_PROPERTIES = [
    ("Manufacturer Name",        "Manufacturer"),
    ("Manufacturer Part Number", "ManufacturerPN"),
    ("DXDB_LIBNAME",             None),
    ("Value",                    "Value"),
    ("Datasheet",                "Datasheet"),
    ("Description",              "Description"),
    ("Supplier Name",            "Supplier"),
    ("Supplier Part Number",     "SupplierPN"),
    ("Photo",                    "Photo"),
]

PARTQUEST_INSTANCE_PROPERTIES = [
    ("Datasheet","DatasheetLink"), ("Description","Description"),
    ("Manufacturer Name","Manufacturer Name"),
    ("Manufacturer Part Number","Manufacturer Part Number"),
    ("DXDB_LIBNAME",None), ("Supplier Part Number","Supplier Part Number"),
    ("Value","Value"),
]

OSCILLATOR_INSTANCE_PROPERTIES = [
    ("Datasheet","Datasheet"), ("Description","Description"),
    ("Manufacturer Name","Manufacturer"), ("Manufacturer Part Number","ManufacturerPN"),
    ("DXDB_LIBNAME",None), ("Photo","Photo"),
    ("SupplierCategory","SupplierCategory"), ("Value","Value_raw"),
]

def _build_dedup_pin_map(pins, category):
    seen = set()
    result = {}
    for pin in pins:
        pin_name = pin.get("name", "")
        pin_num  = pin.get("number", "")
        encoded  = edif_encode(pin_name)
        if encoded in seen:
            encoded = edif_encode(f"{pin_name}_{pin_num}")
        seen.add(encoded)
        result[pin_num] = encoded
    return result


def generate_cell_block(comp):
    name        = comp["name"]
    category    = comp.get("category", "")
    ref_prefix  = comp.get("ref_prefix", "")
    symbol_name = comp.get("symbol", "") or category
    sym_data    = comp.get("symbol_data", {})
    pins        = comp.get("pins", [])

    designator  = f"{ref_prefix}?" if ref_prefix else "?"
    pinswap_val = sym_data.get("PINSWAP", comp.get("pinswap", ""))
    parts_val   = sym_data.get("PARTS", "1")
    class_val   = sym_data.get("CLASS", "")
    prop_defs   = CELL_PROPERTIES.get(category, CELL_PROPERTIES["_default"])

    L = []
    if category == "PartQuest":
        L.append(f'      (cell {name}')
    else:
        L.append(f'      (cell  {edif_ref(name)}')

    L.append(f'        (cellType GENERIC)')

    if category == "Inductor":
        L.append(f'        (view  (rename {edif_encode(symbol_name)} "{symbol_name}")')
    elif category == "Oscillator":
        L.append(f'        (view {edif_encode(symbol_name.lower())}')
    else:
        L.append(f'        (view {edif_encode(symbol_name)}')

    L.append(f'          (viewType NETLIST)')
    L.append(f'          (interface')
    L.append(f'            (designator "{designator}")')

    for display_name, safe_name, default_val in prop_defs:
        if category == "Circuit_Protection" and display_name == "Value":
            val = sym_data.get("raw_properties", {}).get("VALUE", default_val)
        elif display_name == "PINSWAP":
            val = pinswap_val
        elif display_name == "PARTS":
            val = parts_val
        elif display_name == "CLASS":
            val = class_val
        else:
            val = default_val

        prop_str = f'(rename {safe_name} "{display_name}")' if display_name != safe_name else display_name
        L.append(f'            (property {prop_str}  (string "{edif_string(val)}")')
        L.append(f'              (owner "Siemens")')
        L.append(f'            )')

    if category == "PartQuest":
        direction, add_pin_type, add_pin_label = "INOUT", False, True
    elif category == "Oscillator":
        direction, add_pin_type, add_pin_label = "INOUT", False, False
    else:
        direction      = "INOUT" if category in ("Circuit_Protection", "Display", "Inductor") else "INPUT"
        add_pin_type   = category in ("Resistor", "Capacitor", "Inductor")
        add_pin_label  = False

    seen_port_names = set()

    for pin in pins:
        pin_name      = pin.get("name", "")
        pin_num       = pin.get("number", "")
        pin_type      = pin.get("type", "")
        direction_pin = pin.get("edif_direction", direction)
        encoded_pin   = edif_encode(pin_name)

        if category in ("Diode", "Transistor"):
            if encoded_pin in seen_port_names:
                encoded_pin = edif_encode(f"{pin_name}_{pin_num}")
            seen_port_names.add(encoded_pin)
            L.append(f'            (port {encoded_pin}')
            L.append(f'              (designator "{pin_num}")')
            L.append(f'            )')
        else:
            if encoded_pin in seen_port_names:
                encoded_pin = edif_encode(f"{pin_name}_{pin_num}")
                
            seen_port_names.add(encoded_pin)
            L.append(f'            (port {encoded_pin}')
            L.append(f'              (direction {direction_pin})')
            L.append(f'              (designator "{pin_num}")')
            if add_pin_type and pin_type:
                L.append(f'              (property  (rename Pin_Type "Pin Type")  (string "{edif_string(pin_type)}")')
                L.append(f'                (owner "Siemens")')
                L.append(f'              )')
            if add_pin_label:
                label = ("T" + pin_name[len("Terminal_"):]) if pin_name.startswith("Terminal_") else pin_name
                L.append(f'              (property PinLabel  (string "{label}")')
                L.append(f'                (owner "Siemens")')
                L.append(f'              )')
            L.append(f'            )')

    L.append(f'          )')
    L.append(f'        )')
    L.append(f'      )')
    return "\n".join(L)


def generate_global_cell_block(sym):
    L = []
    L.append(f'      (cell {edif_encode(sym["sym_name"])}')
    L.append(f'        (cellType GENERIC)')
    L.append(f'        (view {edif_encode(sym["view_name"])}')
    L.append(f'          (viewType NETLIST)')
    L.append(f'          (interface')
    L.append(f'            (designator "G?")')
    L.append(f'            (property  (rename Net_Name "Net Name")  (string "{edif_string(sym["net_name"])}")')
    L.append(f'              (owner "Siemens")')
    L.append(f'            )')
    L.append(f'            (port {sym["pin_label"]}')
    L.append(f'              (direction {sym["direction"]})')
    L.append(f'              (designator "{sym["pin_label"]}")')
    L.append(f'            )')
    L.append(f'          )')
    L.append(f'        )')
    L.append(f'      )')
    return "\n".join(L)


def generate_instance_block(comp, encoded_id, display_id):
    name        = comp["name"]
    category    = comp.get("category", "")
    ref_prefix  = comp.get("ref_prefix", "")
    symbol_name = comp.get("symbol", "") or category
    pins        = comp.get("pins", [])
    databook    = comp.get("databook", {})

    encoded_name   = edif_encode(name)
    encoded_symbol = edif_encode(symbol_name)
    designator     = f"{ref_prefix}?" if ref_prefix else "?"

    dedup_map = _build_dedup_pin_map(pins, category)

    L = []
    L.append(f'            (instance  (rename {encoded_id} "{display_id}")')

    if category == "Inductor":
        L.append(f'              (viewRef {encoded_symbol}  (cellRef {encoded_name}  (libraryRef {category})))')
    elif category == "PartQuest":
        L.append(f'              (viewRef {edif_encode(symbol_name)}  (cellRef {name}  (libraryRef {category})))')
    elif category == "Oscillator":
        L.append(f'              (viewRef {edif_encode(symbol_name.lower())}  (cellRef {encoded_name}  (libraryRef {category})))')
    else:
        L.append(f'              (viewRef {edif_encode(symbol_name)}  (cellRef {encoded_name}  (libraryRef {category})))')

    for pin in pins:
        pin_num     = pin.get("number", "")
        encoded_pin = dedup_map.get(pin_num, edif_encode(pin.get("name", "")))
        L.append(f'              (portInstance {encoded_pin}  (designator "{pin_num}"))')

    L.append(f'              (designator "{designator}")')

    if category == "Inductor":
        val = databook.get("ManufacturerPN", name)
        L.append(f'              (property (rename Part_Name "Part Name")  (string "{edif_string(val)}")')
        L.append(f'                (owner "Siemens")')
        L.append(f'              )')
    elif category == "Oscillator":
        for display_name, db_key in OSCILLATOR_INSTANCE_PROPERTIES:
            val = category if display_name == "DXDB_LIBNAME" else databook.get(db_key)
            if val is None:
                continue
            val = str(int(val)) if db_key == "Value_raw" and isinstance(val, (int, float)) else str(val)
            prop_str = f'(rename {display_name.replace(" ","_")} "{display_name}")' if " " in display_name else display_name
            L.append(f'              (property {prop_str}  (string "{edif_string(val)}")')
            L.append(f'                (owner "Siemens")')
            L.append(f'              )')
    elif category == "PartQuest":
        for display_name, db_key in PARTQUEST_INSTANCE_PROPERTIES:
            val = category if display_name == "DXDB_LIBNAME" else databook.get(db_key)
            if val is None:
                continue
            prop_str = f'(rename {display_name.replace(" ","_")} "{display_name}")' if " " in display_name else display_name
            L.append(f'              (property {prop_str}  (string "{edif_string(val)}")')
            L.append(f'                (owner "Siemens")')
            L.append(f'              )')
    else:
        for display_name, db_key in INSTANCE_PROPERTIES:
            if display_name == "Value" and category in ("Transistor", "Display"):
                continue
            if display_name == "DXDB_LIBNAME":
                val = category
            elif display_name == "Value" and category == "Circuit_Protection":
                raw_val = databook.get("Value_raw")
                val = str(raw_val) if raw_val is not None else ""
            elif db_key and databook.get(db_key) is not None:
                val = str(databook[db_key])
            else:
                continue
            prop_str = f'(rename {display_name.replace(" ","_")} "{display_name}")' if " " in display_name else display_name
            L.append(f'              (property {prop_str}  (string "{edif_string(val)}")')
            L.append(f'                (owner "Siemens")')
            L.append(f'              )')

    L.append(f'            )')
    return "\n".join(L)


def generate_global_instance_block(sym, encoded_id, display_id):
    L = []
    L.append(f'            (instance  (rename {encoded_id} "{display_id}")')
    L.append(f'              (viewRef {edif_encode(sym["view_name"])}  (cellRef {edif_encode(sym["sym_name"])}  (libraryRef Globals)))')
    L.append(f'              (portInstance {sym["pin_label"]}  (designator "{sym["pin_label"]}"))')
    L.append(f'              (designator "G?")')
    L.append(f'              (property  (rename Part_Name "Part Name")  (string "{edif_string(sym["sym_name"])}")')
    L.append(f'                (owner "Siemens")')
    L.append(f'              )')
    L.append(f'            )')
    return "\n".join(L)


def generate_net_block(net_name, connections, is_global, net_id_gen, instance_id_map):
    net_ref = f'(rename &{_raw_encode(net_name)} "{net_name}")' if _needs_encoding(net_name) else net_name
    L = []
    L.append(f'            (net {net_ref}')
    L.append(f'              (joined')
    for conn in connections:
        inst_display = conn["instance_id"]
        inst_encoded = instance_id_map.get(inst_display, "&" + edif_encode(inst_display))
        encoded_pin = conn["pin"] if conn.get("_pre_encoded") else edif_encode(str(conn["pin"]))
        L.append(f'                (portRef {encoded_pin} (instanceRef {inst_encoded} ))')
    L.append(f'              )')
    if is_global:
        L.append(f'              (property global (boolean (true))')
        L.append(f'                (owner "Siemens")')
        L.append(f'              )')
    L.append(f'            )')
    return "\n".join(L)


def _generate_blocks(part_names, category, id_gen, db_conn, json_pins_by_ref=None):
    cell_blocks, instance_blocks, not_found = [], [], []
    # ── FIX B: use (comp_name, ref) as key for per-instance cells ──
    # Each instance that has extra pins gets its OWN cell, named comp_name_ref.
    # Instances without extras still share a cell keyed by comp_name alone.
    seen_cell_names = set()  # tracks cell names already emitted
    id_map, ref_map, pin_remap = {}, {}, {}

    for entry in part_names:
        if isinstance(entry, (list, tuple)):
            ref, part_name = entry[0], entry[1]
        else:
            ref, part_name = None, entry

        comp = lookup_part(db_conn, part_name, category)
        if not comp:
            not_found.append(part_name)
            print(f"  WARNING: '{part_name}' not found in {category}")
            continue

        encoded_id, display_id = id_gen.next()
        id_map[display_id] = encoded_id
        if ref:
            ref_map[ref] = display_id

        json_pins = {}
        if ref and json_pins_by_ref:
            json_pins = json_pins_by_ref.get(ref, {})

        db_pins_raw = list(comp.get("pins") or [])

        # Clean DB pins
        db_pins = []
        for p in db_pins_raw:
            pnum  = str(p.get("number", ""))
            pname = p.get("name", "").strip()
            if not pname and pnum in json_pins:
                db_pins.append({"name": json_pins[pnum], "number": pnum,
                                 "type": p.get("type", "ANALOG"),
                                 "edif_direction": p.get("edif_direction", "INOUT")})
            elif pname:
                db_pins.append(p)

        db_pin_nums = {str(p.get("number", "")) for p in db_pins}
        comp_name = comp["name"]

        # THIS instance's extra pins only
        instance_extra = []
        for pin_num, pin_name in json_pins.items():
            if pin_num not in db_pin_nums:
                instance_extra.append({"name": pin_name, "number": pin_num,
                                        "type": "ANALOG", "edif_direction": "INOUT"})
                print(f"  NOTE: pin {pin_num} ({pin_name}) on {part_name} "
                      f"missing from DB — adding to cell+instance")
                
        db_pin_names = {p.get("name", "") for p in db_pins}
        instance_extra = [
            p for p in instance_extra
            if not (p.get("name", "") in db_pin_names
                    and not p.get("name", "").isdigit())
        ]


        instance_pins = db_pins + instance_extra

        # ── FIX B: per-instance cell name when extras exist ──
        # If this instance has extra pins, give it a unique cell name so
        # only its exact pins are declared — no union, no false DRC errors.
        has_extras = bool(instance_extra)
        if has_extras and ref:
            # e.g. "0016_064R_10K_/_CAY16-103J4LF_RN1"
            cell_name_key = f"{comp_name}_{ref}"
        else:
            cell_name_key = comp_name

        # ── FIX A: redirect extra-pin number keys to real DB port names ──
        # Build num_to_enc from the deduplicated map of instance_pins.
        num_to_enc = _build_dedup_pin_map(instance_pins, category)

        # Build a map: pin_name → encoded_port_name from DB pins only.
        # This is used to redirect alias pin lookups to real electrical ports.
        # e.g. DB pin number=1 name="A" → db_name_to_enc["A"] = "A"
        #      DB pin number=1 name="+" → db_name_to_enc["+"] = "_053"
        db_name_to_enc = {}
        for p in db_pins:
            pname = p.get("name", "")
            pnum  = str(p.get("number", ""))
            if pname and pnum in num_to_enc:
                db_name_to_enc[pname] = num_to_enc[pnum]


        for p in instance_extra:
            pname = p.get("name", "")
            pnum  = str(p.get("number", ""))
            if pname in db_name_to_enc and not pname.isdigit(): 
                num_to_enc[pnum] = db_name_to_enc[pname]

        # Also add designator-based lookups (e.g. XIO connector physical pin numbers)
        for p in instance_pins:
            pname = p.get("name", "")
            pnum  = str(p.get("number", ""))
            desig = str(p.get("designator", pnum))
            if pname and desig and desig != pnum:
                num_to_enc[desig] = num_to_enc.get(pnum, edif_encode(pname))

        # Self-lookups for encoded-name based JSON references,
        # only if that encoded name isn't already a key (avoid overwriting fixes above)
        for enc_name in list(num_to_enc.values()):
            if enc_name not in num_to_enc:
                num_to_enc[enc_name] = enc_name

        pin_remap[display_id] = num_to_enc

        # Emit cell if not seen yet for this key
        if cell_name_key not in seen_cell_names:
            cell_comp = dict(comp)
            cell_comp["pins"] = instance_pins
            # If using a per-instance cell name, override the comp name in the cell block
            if has_extras and ref:
                cell_comp = dict(cell_comp)
                cell_comp["name"] = cell_name_key
            cell_blocks.append(generate_cell_block(cell_comp))
            seen_cell_names.add(cell_name_key)

        # Emit instance, pointing to the correct cell name
        inst_comp = dict(comp)
        inst_comp["pins"] = instance_pins
        if has_extras and ref:
            inst_comp = dict(inst_comp)
            inst_comp["name"] = cell_name_key
        instance_blocks.append(generate_instance_block(inst_comp, encoded_id, display_id))

    if not_found:
        print(f"  {len(not_found)} parts not found: {not_found}")

    return cell_blocks, instance_blocks, id_map, ref_map, pin_remap


def generate_resistor_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "Resistor", id_gen, db_conn, json_pins_by_ref)

def generate_capacitor_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "Capacitor", id_gen, db_conn, json_pins_by_ref)

def generate_ic_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "IC", id_gen, db_conn, json_pins_by_ref)

def generate_diode_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "Diode", id_gen, db_conn, json_pins_by_ref)

def generate_connector_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "Connector", id_gen, db_conn, json_pins_by_ref)

def generate_transistor_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "Transistor", id_gen, db_conn, json_pins_by_ref)

def generate_inductor_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "Inductor", id_gen, db_conn, json_pins_by_ref)

def generate_circuit_protection_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "Circuit_Protection", id_gen, db_conn, json_pins_by_ref)

def generate_display_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "Display", id_gen, db_conn, json_pins_by_ref)

def generate_partquest_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "PartQuest", id_gen, db_conn, json_pins_by_ref)

def generate_oscillator_blocks(part_names, id_gen, db_conn, json_pins_by_ref=None):
    return _generate_blocks(part_names, "Oscillator", id_gen, db_conn, json_pins_by_ref)


GENERATORS = {
    "Resistor":           generate_resistor_blocks,
    "Capacitor":          generate_capacitor_blocks,
    "IC":                 generate_ic_blocks,
    "Diode":              generate_diode_blocks,
    "Connector":          generate_connector_blocks,
    "Transistor":         generate_transistor_blocks,
    "Inductor":           generate_inductor_blocks,
    "Circuit_Protection": generate_circuit_protection_blocks,
    "Display":            generate_display_blocks,
    "PartQuest":          generate_partquest_blocks,
    "Oscillator":         generate_oscillator_blocks,
}


def load_nets(nets_input):
    if nets_input is None:
        return []
    if isinstance(nets_input, str):
        with open(nets_input, encoding="utf-8") as f:
            return json.load(f)
    if isinstance(nets_input, list):
        return nets_input
    return []


def generate_edif_file(
    design_name,
    components_by_category,
    db_path,
    output_path,
    nets=None,
    existing_edn=None,
):
    now = datetime.now()

    max_instance, max_net = parse_used_ids(existing_edn)
    existing = parse_existing_edn(existing_edn)

    id_gen     = IDGenerator(prefix="I", start=max_instance + 1)
    net_id_gen = IDGenerator(prefix="N", start=max_net + 1)

    all_cell_blocks          = {}
    all_instance_blocks      = []
    global_instance_blocks   = []
    instance_id_map          = {}
    existing_library_blocks  = existing["library_blocks"]
    existing_instance_blocks = existing["instance_blocks"]
    existing_net_blocks      = existing["net_blocks"]

    db_conn = sqlite3.connect(db_path)

    ref_to_display = {}
    pin_remap_map  = {}

    nets_raw = load_nets(nets)
    json_pins_by_ref = defaultdict(dict)
    for net in nets_raw:
        for cp in net.get("connected_pins", []):
            ref      = cp.get("component_ref", "")
            pin_num  = str(cp.get("pin_number", ""))
            pin_name = cp.get("pin_name") or pin_num
            if ref and pin_num:
                json_pins_by_ref[ref][pin_num] = pin_name

    try:
        for category, part_names in components_by_category.items():
            if not part_names:
                continue
            generator = GENERATORS.get(category)
            if not generator:
                print(f"  WARNING: No generator for '{category}' — skipping")
                continue

            print(f"  {category}: {len(part_names)} part(s)...")
            cell_blocks, instance_blocks, id_map, ref_map, p_remap = generator(
                part_names, id_gen, db_conn, json_pins_by_ref=dict(json_pins_by_ref)
            )
            pin_remap_map.update(p_remap)
            if cell_blocks:
                all_cell_blocks[category] = cell_blocks
            all_instance_blocks.extend(instance_blocks)
            instance_id_map.update(id_map)
            ref_to_display.update(ref_map)

    finally:
        db_conn.close()

    # Global symbols — build net→instance map so each power/ground
    # net gets a portRef to its global symbol instance ──
    nets = nets_raw
    seen_syms = {}
    for net in nets:
        net_type = net.get("net_type")
        if net_type not in ("power", "ground"):
            continue
        sym = _net_to_global_symbol(net.get("name", ""), net_type)
        if sym["sym_name"] not in seen_syms:
            seen_syms[sym["sym_name"]] = sym

    global_cell_blocks = []
    # Maps net_name → (encoded_id, display_id, sym) for wiring into nets
    global_sym_by_net = {}

    for sym in seen_syms.values():
        encoded_id, display_id = id_gen.next()
        instance_id_map[display_id] = encoded_id
        cb = generate_global_cell_block(sym)
        if cb:
            global_cell_blocks.append(cb)
        ib = generate_global_instance_block(sym, encoded_id, display_id)
        if ib:
            global_instance_blocks.append(ib)
        # Store mapping so the net loop can add the portRef
        global_sym_by_net[sym["net_name"]] = (encoded_id, display_id, sym)

    # ── Net blocks ────────────────────────────────────────────
    net_blocks = []
    for net in nets:
        is_global = net.get("net_type") in ("power", "ground")
        net_name  = net.get("name") or net_id_gen.next()[1]

        connections = net.get("connections") or []
        if not connections:
            for cp in net.get("connected_pins", []):
                ref      = cp.get("component_ref", "")
                pin_num  = str(cp.get("pin_number", ""))
                pin_name = cp.get("pin_name") or pin_num
                display_id = ref_to_display.get(ref)
                if display_id and instance_id_map.get(display_id):
                    remap = pin_remap_map.get(display_id, {})
                    encoded_pin_name = edif_encode(pin_name)
                    if encoded_pin_name and encoded_pin_name in remap:   # "GPIO3057P005615" → found ✓
                        pin_out = remap[encoded_pin_name]
                    elif pin_num and pin_num in remap:                   # fallback for passives
                        pin_out = remap[pin_num]
                    else:
                        pin_out = encoded_pin_name
                    connections.append({"instance_id": display_id, "pin": pin_out, "_pre_encoded": True})

        # ── FIX C: add the global symbol portRef to every power/ground net ──
        if is_global and net_name in global_sym_by_net:
            enc_id, disp_id, sym = global_sym_by_net[net_name]
            connections.append({
                "instance_id": disp_id,
                "pin":         sym["pin_label"],   # "VCC" or "GND"
                "_pre_encoded": True
            })

        net_blocks.append(
            generate_net_block(net_name, connections, is_global, net_id_gen, instance_id_map)
        )

    # ── Assemble EDIF ─────────────────────────────────────────
    L = []
    L.append(f'  (edif DxD')
    L.append(f'    (edifVersion 2 0 0)')
    L.append(f'    (edifLevel 0)')
    L.append(f'    (keywordMap  (keywordLevel 0))')
    L.append(f'    (status')
    L.append(f'      (written')
    L.append(f'        (timestamp {now.year} {now.month} {now.day} {now.hour} {now.minute} {now.second})')
    L.append(f'        (author "Siemens")')
    L.append(f'        (program "xDX Designer Edif Exporter"')
    L.append(f'          (version "PADS Professional VX.2.12 <21159422>  2022-08-11 21:31:43")')
    L.append(f'        )')
    L.append(f'      )')
    L.append(f'    )')

    for lib_block in existing_library_blocks:
        L.append(lib_block)

    for category, cell_blocks in all_cell_blocks.items():
        L.append(f'    (library {category}')
        L.append(f'      (edifLevel 0)')
        L.append(f'      (technology')
        L.append(f'        (numberDefinition')
        L.append(f'          (gridMap 0 0)')
        L.append(f'        )')
        L.append(f'        (figureGroup GRAPHICS')
        L.append(f'        )')
        L.append(f'      )')
        for cb in cell_blocks:
            L.append(cb)
        L.append(f'    )')

    if global_cell_blocks:
        L.append(f'    (library Globals')
        L.append(f'      (edifLevel 0)')
        L.append(f'      (technology')
        L.append(f'        (numberDefinition')
        L.append(f'          (gridMap 0 0)')
        L.append(f'        )')
        L.append(f'        (figureGroup GRAPHICS')
        L.append(f'        )')
        L.append(f'      )')
        for cb in global_cell_blocks:
            L.append(cb)
        L.append(f'    )')

    L.append(f'    (library {design_name}')
    L.append(f'      (edifLevel 0)')
    L.append(f'      (technology')
    L.append(f'        (numberDefinition')
    L.append(f'          (gridMap 0 0)')
    L.append(f'        )')
    L.append(f'        (figureGroup GRAPHICS')
    L.append(f'        )')
    L.append(f'      )')
    L.append(f'      (cell {design_name}')
    L.append(f'        (cellType GENERIC)')
    L.append(f'        (view NETLIST_VIEW')
    L.append(f'          (viewType NETLIST)')
    L.append(f'          (interface')
    L.append(f'          )')
    L.append(f'          (contents')
    for ib in existing_instance_blocks:
        L.append(ib)
    for ib in all_instance_blocks:
        L.append(ib)
    for ib in global_instance_blocks:
        L.append(ib)
    for nb in existing_net_blocks:
        L.append(nb)
    for nb in net_blocks:
        L.append(nb)
    L.append(f'          )')
    L.append(f'        )')
    L.append(f'      )')
    L.append(f'    )')

    L.append(f'    (design {design_name}')
    L.append(f'      (cellRef {design_name}')
    L.append(f'        (libraryRef {design_name})')
    L.append(f'      )')
    L.append(f'    )')
    L.append(f'  )')

    content = "\n".join(L)
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(content, encoding="utf-8")

    print(f"\n  EDIF written  : {output_path}")
    print(f"  File size     : {out.stat().st_size / 1024:.1f} KB")
    total = len(existing_instance_blocks) + len(all_instance_blocks) + len(global_instance_blocks)
    print(f"  Instances     : {total} ({len(existing_instance_blocks)} existing + {len(all_instance_blocks) + len(global_instance_blocks)} new)")
    print(f"  Nets          : {len(net_blocks)}")
    return content


# TYPE_TO_CATEGORY = {
#     "IC":                 "IC",
#     "Microcontroller":    "IC",
#     "LED":                "Diode",
#     "Diode":              "Diode",
#     "Resistor":           "Resistor",
#     "Capacitor":          "Capacitor",
#     "Connector":          "Connector",
#     "Switch":             "",
#     "Transistor":         "Transistor",
#     "Inductor":           "Inductor",
#     "Crystal":            "Oscillator",
#     "Oscillator":         "Oscillator",
#     "Circuit_Protection": "Circuit_Protection",
#     "Display":            "Display",
# }
# TYPE_TO_CATEGORY = {
#     # Exact matches from lib category column
#     "Resistor":              "Resistor",
#     "Capacitor":             "Capacitor",
#     "Inductor":              "Inductor",
#     "IC":                    "IC",
#     "Diode":                 "Diode",
#     "Transistor":            "Transistor",
#     "Connector":             "Connector",
#     "Oscillator":            "Oscillator",
#     "Circuit_Protection":    "Circuit_Protection",
#     "Display":               "Display",
#     "Switch":                "Switch",
#     "PartQuest":             "PartQuest",
#     "Capacitor (Polarized)": "Capacitor",
#     "Test Point":            "Connector",
#     "Fuse":                  "Circuit_Protection",
#     "Voltage Regulator":     "IC",
#     "op_amp": "IC",
#     "Sensor": "Sensor",
#     "Filter":                "Filter",
#     "LED":                   "Diode",
#     "Transformer": "Transformer",
#     "ferritebead": "Ferrite Bead",
#     "ferrite_bead": "Ferrite Bead", 
#     "op_amp": "IC",
#     "ground": "Connector",
#     "schottky_diode": "Diode",
#     "tvs_diode": "Diode",
#     "fb": "Ferrite Bead",  # footprint prefix
#     "Unknown":               "Unclassified",
# }

TYPE_TO_CATEGORY = {
    # Standard
    "Resistor":              "Resistor",
    "Capacitor":             "Capacitor",
    "Capacitor (Polarized)": "Capacitor",
    "Inductor":              "Inductor",
    "ferritebead":           "Inductor",   # ← was "Ferrite Bead" (unmapped)
    "ferrite_bead":          "Inductor",
    "fb":                    "Inductor",
    "Transformer":           "Inductor",   # ← was "Transformer" (unmapped)
    "IC":                    "IC",
    "Microcontroller":       "IC",
    "Voltage Regulator":     "IC",
    "op_amp":                "IC",
    "Op Amp":                "IC",
    "Sensor":                "IC",         # ← was "Sensor" (unmapped)
    "Filter":                "IC",         # ← was "Filter" (unmapped)
    "Unknown":               "IC",         # ← was "Unclassified" (unmapped)
    "Unclassified":          "IC",
    "Diode":                 "Diode",
    "LED":                   "Diode",
    "schottky_diode":        "Diode",
    "tvs_diode":             "Diode",
    "Transistor":            "Transistor",
    "Connector":             "Connector",
    "Switch":                "Connector",  # ← was "Switch" (unmapped)
    "Test Point":            "Connector",
    "Fuse":                  "Circuit_Protection",
    "Crystal":               "Oscillator",
    "Oscillator":            "Oscillator",
    "Circuit_Protection":    "Circuit_Protection",
    "Display":               "Display",
    "PartQuest":             "PartQuest",
}
SKIP_TYPES = {
    "ground", "power", "vcc", "gnd",
    "Test Point",
}
SKIP_TYPES_pn= {"ground", "power", "vcc", "gnd",
    "Resistor", "Capacitor", "Inductor",   # ← these skip passives with no part_number
    "Test Point", "Ferrite Bead",
    
}

def _patch_spec_nets(spec: dict) -> dict:
    """
    Fix common LLM spec issues before EDIF generation.

    Fixes applied in order:
      1. Merge VCC into VBUS when both exist
      2. Merge all ground islands (net_type=ground, name!=GND) into GND
      3. Merge single-pin ground/power nets into GND
      4. Remove duplicate pins (same pin on multiple nets)
      5. Remove single-component nets (short circuits)
      6. Change small regulated output nets from power → signal
      7. Clear part_number from Ground/Power symbol components
    """
    import copy
    spec = copy.deepcopy(spec)

    POWER_SYMBOL_PATTERNS = {
        "GND", "VCC", "VDD", "VSS", "PWR", "POWER",
        "SUPPLY", "3V3", "5V", "12V", "AGND", "DGND",
    }

    def _is_power_ref(ref: str) -> bool:
        return any(ref.upper().startswith(p) for p in POWER_SYMBOL_PATTERNS)

    def _refresh():
        return spec["nets"], {n["name"]: n for n in spec["nets"]}

    spec.setdefault("nets", [])
    nets, net_map = _refresh()

    # ── Fix 1: Merge VCC into VBUS ────────────────────────────────────────────
    vbus = net_map.get("VBUS")
    vcc  = net_map.get("VCC")
    if vbus and vcc:
        real_vcc_pins = [
            p for p in vcc["connected_pins"]
            if not _is_power_ref(p["component_ref"])
        ]
        existing = {
            (p["component_ref"], p["pin_number"])
            for p in vbus["connected_pins"]
        }
        moved = 0
        for pin in real_vcc_pins:
            key = (pin["component_ref"], pin["pin_number"])
            if key not in existing:
                vbus["connected_pins"].append(pin)
                existing.add(key)
                moved += 1
        vbus["net_type"] = "power"
        spec["nets"] = [n for n in nets if n["name"] != "VCC"]
        if moved:
            print(f"  🔧 Merged VCC into VBUS — {moved} pin(s) moved")
        nets, net_map = _refresh()

    # ── Fix 2: Merge all ground islands into GND ──────────────────────────────
    # Any net with net_type="ground" and name != "GND" is an island
    gnd_net = net_map.get("GND")
    if gnd_net:
        islands = [
            n for n in nets
            if n["name"] != "GND" and n.get("net_type") == "ground"
        ]
        for island in islands:
            existing_gnd = {
                (p["component_ref"], p["pin_number"])
                for p in gnd_net["connected_pins"]
            }
            real_pins = [
                p for p in island["connected_pins"]
                if not _is_power_ref(p["component_ref"])
            ]
            moved = 0
            for pin in real_pins:
                key = (pin["component_ref"], pin["pin_number"])
                if key not in existing_gnd:
                    gnd_net["connected_pins"].append(pin)
                    existing_gnd.add(key)
                    moved += 1
            print(
                f"  🔧 Merged ground island '{island['name']}' into GND "
                f"— {moved} pin(s) moved"
            )
        spec["nets"] = [
            n for n in nets
            if not (n["name"] != "GND" and n.get("net_type") == "ground")
        ]
        nets, net_map = _refresh()

    # ── Fix 3: Merge single-pin ground/power nets into GND ───────────────────
    gnd_net = net_map.get("GND")
    if gnd_net:
        nets_to_remove = []
        for net in nets:
            if net["name"] == "GND":
                continue
            if net.get("net_type") not in ("ground", "power"):
                continue
            real_pins = [
                p for p in net["connected_pins"]
                if not _is_power_ref(p["component_ref"])
            ]
            if len(real_pins) <= 1:
                existing_gnd = {
                    (p["component_ref"], p["pin_number"])
                    for p in gnd_net["connected_pins"]
                }
                for pin in real_pins:
                    key = (pin["component_ref"], pin["pin_number"])
                    if key not in existing_gnd:
                        gnd_net["connected_pins"].append(pin)
                        existing_gnd.add(key)
                nets_to_remove.append(net["name"])
                print(f"  🔧 Merged single-pin net '{net['name']}' into GND")
        spec["nets"] = [n for n in nets if n["name"] not in nets_to_remove]
        nets, net_map = _refresh()

    # ── Fix 4: Remove duplicate pins (same pin on multiple nets) ─────────────
    seen_pins = {}  # {(comp_ref, pin_number): first_net_name}
    for net in nets:
        clean = []
        for pin in net.get("connected_pins", []):
            key = (pin["component_ref"], str(pin.get("pin_number", "")))
            if key not in seen_pins:
                seen_pins[key] = net["name"]
                clean.append(pin)
            else:
                print(
                    f"  🔧 Removed duplicate pin {key[0]}.pin{key[1]} "
                    f"from '{net['name']}' — already on '{seen_pins[key]}'"
                )
        net["connected_pins"] = clean

    before = len(spec["nets"])
    spec["nets"] = [
        n for n in nets
        if len(n.get("connected_pins", [])) >= 2
    ]
    removed = before - len(spec["nets"])
    if removed:
        print(f"  🔧 Removed {removed} net(s) with < 2 pins after dedup")
    nets, net_map = _refresh()

    # ── Fix 5: Remove single-component nets (short circuits) ─────────────────
    clean_nets = []
    for net in nets:
        pins      = net.get("connected_pins", [])
        comp_refs = [p["component_ref"] for p in pins]
        if len(pins) > 0 and len(set(comp_refs)) == 1:
            print(
                f"  🔧 Removed single-component net '{net['name']}' "
                f"— all pins on '{comp_refs[0]}'"
            )
            continue
        clean_nets.append(net)
    spec["nets"] = clean_nets
    nets, net_map = _refresh()

    # ── Fix 6: Change small regulated output nets from power → signal ─────────
    # Prevents EDIF generator from marking them global (causes drc-116)
    KEEP_AS_POWER = {
        "VBUS", "VCC", "VDD", "VSS",
        "GND", "AGND", "DGND", "PGND",
    }
    for net in spec["nets"]:
        if net.get("net_type") != "power":
            continue
        if net["name"].upper() in KEEP_AS_POWER:
            continue
        real_pins = [
            p for p in net.get("connected_pins", [])
            if not _is_power_ref(p["component_ref"])
        ]
        if len(real_pins) <= 2:
            net["net_type"] = "signal"
            print(
                f"  🔧 Changed '{net['name']}' net_type: power → signal "
                f"({len(real_pins)} real pin(s))"
            )

    # ── Fix 7: Clear part_number from Ground/Power symbol components ──────────
    SYMBOL_TYPES = {"Ground", "Power", "Supply", "PWR_FLAG", "NetTie"}
    for comp in spec.get("components", []):
        if comp.get("type") in SYMBOL_TYPES and comp.get("part_number"):
            print(
                f"  🔧 Cleared part_number '{comp['part_number']}' "
                f"from symbol {comp['ref']} (type={comp['type']})"
            )
            comp["part_number"] = None
            comp["value"]       = ""

    return spec


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db",       required=True)
    parser.add_argument("--spec",     default=None)
    parser.add_argument("--existing", default=None)
    parser.add_argument("--out",      default="output.edn")
    args = parser.parse_args()

    if args.spec:
        print(f"Loading spec: {args.spec}")
        with open(args.spec, encoding="utf-8") as f:
            spec = json.load(f)

        components_by_category = defaultdict(list)
        for comp in spec.get("components", []):
            ctype = comp.get("type", "")
            if ctype in SKIP_TYPES or not comp.get("part_number"):
                continue
            cat = TYPE_TO_CATEGORY.get(ctype, "IC")
            components_by_category[cat].append((comp["ref"], comp["part_number"]))

        design_name = re.sub(r"[^\w]", "_", spec.get("title", "circuit"))
        nets        = spec.get("nets", [])
    else:
        components_by_category = {"Resistor": ["ESR03EZPJ331"], "Diode": ["LTST-C170CKT"]}
        design_name = "Board1"
        nets        = []

    print(f"\nGenerating EDIF for '{design_name}'...")
    generate_edif_file(
        design_name            = design_name,
        components_by_category = dict(components_by_category),
        db_path                = args.db,
        output_path            = args.out,
        nets                   = nets,
        existing_edn           = args.existing,
    )


if __name__ == "__main__":
    main()
