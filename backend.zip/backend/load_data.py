# from agent import CircuitMemgraph, CircuitSpec, Component, Net, PinRef

# # # def load_led_flasher():
# # #     mg = CircuitMemgraph()

# # #     spec = CircuitSpec(
# # #         title="LED_Flasher",
# # #         description="LED_Flasher PCB schematic. Main ICs: CD74AC14M, NE555DR. Contains 20 components: 3 Capacitors, 1 Connector, 6 Diodes, 2 ICs, 8 Resistors. Has 19 nets. Power rails: VCC. Ground nets: DGND.",
# # #         confidence_score=0.95,
# # #         needs_validation=False,
# # #         checklist=[],
# # #         components=[
# # #             # Capacitors
# # #             Component(
# # #                 ref="C1", type="Capacitor", value="1uF",
# # #                 part_number="VJ0603V105MXQPW1BC",
# # #                 manufacturer="Vishay Vitramon",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             Component(
# # #                 ref="C3", type="Capacitor", value="1uF",
# # #                 part_number="VJ0603V105MXQPW1BC",
# # #                 manufacturer="Vishay Vitramon",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             Component(
# # #                 ref="C4", type="Capacitor", value="4.7uF",
# # #                 part_number="CC0603ZRY5V5BB475",
# # #                 manufacturer="Yageo",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             # Connector (USB mini B)
# # #             Component(
# # #                 ref="J1", type="Connector", value="USB_mini_B",
# # #                 part_number="0548190572",
# # #                 manufacturer="Molex",
# # #                 pins=["1", "5", "6", "7", "8", "9"]
# # #             ),
# # #             # LEDs (Diodes)
# # #             Component(
# # #                 ref="CR1", type="Diode", value="LED_RED",
# # #                 part_number="HLMP-6000-E0011",
# # #                 manufacturer="Broadcom Limited",
# # #                 pins=["A", "C"]
# # #             ),
# # #             Component(
# # #                 ref="CR2", type="Diode", value="LED_RED",
# # #                 part_number="HLMP-6000-E0011",
# # #                 manufacturer="Broadcom Limited",
# # #                 pins=["A", "C"]
# # #             ),
# # #             Component(
# # #                 ref="CR3", type="Diode", value="LED_RED",
# # #                 part_number="HLMP-6000-E0011",
# # #                 manufacturer="Broadcom Limited",
# # #                 pins=["A", "C"]
# # #             ),
# # #             Component(
# # #                 ref="CR4", type="Diode", value="LED_RED",
# # #                 part_number="HLMP-6000-E0011",
# # #                 manufacturer="Broadcom Limited",
# # #                 pins=["A", "C"]
# # #             ),
# # #             Component(
# # #                 ref="CR5", type="Diode", value="LED_RED",
# # #                 part_number="HLMP-6000-E0011",
# # #                 manufacturer="Broadcom Limited",
# # #                 pins=["A", "C"]
# # #             ),
# # #             Component(
# # #                 ref="CR6", type="Diode", value="LED_RED",
# # #                 part_number="HLMP-6000-E0011",
# # #                 manufacturer="Broadcom Limited",
# # #                 pins=["A", "C"]
# # #             ),
# # #             # ICs
# # #             Component(
# # #                 ref="U1", type="IC", value="CD74AC14M",
# # #                 part_number="CD74AC14M",
# # #                 manufacturer="Texas Instruments",
# # #                 pins=["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"]
# # #             ),
# # #             Component(
# # #                 ref="U2", type="IC", value="NE555DR",
# # #                 part_number="NE555DR",
# # #                 manufacturer="Texas Instruments",
# # #                 pins=["1", "2", "3", "4", "5", "6", "7", "8"]
# # #             ),
# # #             # Resistors
# # #             Component(
# # #                 ref="R1", type="Resistor", value="330",
# # #                 part_number="RT0603DRD07330RL",
# # #                 manufacturer="Yageo",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             Component(
# # #                 ref="R2", type="Resistor", value="330",
# # #                 part_number="RT0603DRD07330RL",
# # #                 manufacturer="Yageo",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             Component(
# # #                 ref="R3", type="Resistor", value="330",
# # #                 part_number="RT0603DRD07330RL",
# # #                 manufacturer="Yageo",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             Component(
# # #                 ref="R4", type="Resistor", value="330",
# # #                 part_number="RT0603DRD07330RL",
# # #                 manufacturer="Yageo",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             Component(
# # #                 ref="R5", type="Resistor", value="330",
# # #                 part_number="RT0603DRD07330RL",
# # #                 manufacturer="Yageo",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             Component(
# # #                 ref="R6", type="Resistor", value="330",
# # #                 part_number="RT0603DRD07330RL",
# # #                 manufacturer="Yageo",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             Component(
# # #                 ref="R7", type="Resistor", value="10K",
# # #                 part_number="AC0603JR-0710KL",
# # #                 manufacturer="Yageo",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             Component(
# # #                 ref="R8", type="Resistor", value="1K",
# # #                 part_number="RT0603FRE071KL",
# # #                 manufacturer="Yageo",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #         ],
# # #         nets=[
# # #             # Power and Ground
# # #             Net(name="VCC", net_type="power", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="14"),
# # #                 PinRef(component_ref="U2", pin="8"),
# # #                 PinRef(component_ref="U2", pin="4"),
# # #                 PinRef(component_ref="J1", pin="1"),
# # #                 PinRef(component_ref="C3", pin="B1"),
# # #                 PinRef(component_ref="R7", pin="B1"),
# # #                 PinRef(component_ref="R8", pin="B1"),  # R8 connected to VCC
# # #             ]),
# # #             Net(name="DGND", net_type="ground", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="7"),
# # #                 PinRef(component_ref="U2", pin="1"),
# # #                 PinRef(component_ref="J1", pin="5"),
# # #                 PinRef(component_ref="J1", pin="6"),
# # #                 PinRef(component_ref="J1", pin="7"),
# # #                 PinRef(component_ref="J1", pin="8"),
# # #                 PinRef(component_ref="J1", pin="9"),
# # #                 PinRef(component_ref="C1", pin="B2"),
# # #                 PinRef(component_ref="C3", pin="B2"),
# # #                 PinRef(component_ref="C4", pin="B1"),
# # #                 PinRef(component_ref="CR1", pin="C"),
# # #                 PinRef(component_ref="CR2", pin="C"),
# # #                 PinRef(component_ref="CR3", pin="C"),
# # #                 PinRef(component_ref="CR4", pin="C"),
# # #                 PinRef(component_ref="CR5", pin="C"),
# # #                 PinRef(component_ref="CR6", pin="C"),
# # #             ]),
# # #             # 555 Timer timing network with R8 as discharge resistor
# # #             Net(name="TIMING_RC", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="R7", pin="B2"),
# # #                 PinRef(component_ref="R8", pin="B2"),  # R8 other side to timing cap
# # #                 PinRef(component_ref="C4", pin="B2"),
# # #                 PinRef(component_ref="U2", pin="2"),
# # #                 PinRef(component_ref="U2", pin="6"),
# # #                 PinRef(component_ref="U2", pin="7"),
# # #             ]),
# # #             # 555 Control voltage
# # #             Net(name="CONTROL", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U2", pin="5"),
# # #                 PinRef(component_ref="C1", pin="B1"),
# # #             ]),
# # #             # 555 Output to Schmitt Trigger
# # #             Net(name="CLK_OUT", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U2", pin="3"),
# # #                 PinRef(component_ref="U1", pin="1"),
# # #             ]),
# # #             # LED1 path
# # #             Net(name="LED1_DRIVE", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="2"),
# # #                 PinRef(component_ref="R1", pin="B1"),
# # #             ]),
# # #             Net(name="LED1", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="R1", pin="B2"),
# # #                 PinRef(component_ref="CR1", pin="A"),
# # #             ]),
# # #             # LED5 path
# # #             Net(name="LED5_DRIVE", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="4"),
# # #                 PinRef(component_ref="R5", pin="B1"),
# # #             ]),
# # #             Net(name="LED5", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="R5", pin="B2"),
# # #                 PinRef(component_ref="CR5", pin="A"),
# # #             ]),
# # #             # LED4 path
# # #             Net(name="LED4_DRIVE", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="6"),
# # #                 PinRef(component_ref="R4", pin="B1"),
# # #             ]),
# # #             Net(name="LED4", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="R4", pin="B2"),
# # #                 PinRef(component_ref="CR4", pin="A"),
# # #             ]),
# # #             # LED2 path
# # #             Net(name="LED2_DRIVE", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="8"),
# # #                 PinRef(component_ref="R2", pin="B1"),
# # #             ]),
# # #             Net(name="LED2", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="R2", pin="B2"),
# # #                 PinRef(component_ref="CR2", pin="A"),
# # #             ]),
# # #             # LED3 path
# # #             Net(name="LED3_DRIVE", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="10"),
# # #                 PinRef(component_ref="R3", pin="B1"),
# # #             ]),
# # #             Net(name="LED3", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="R3", pin="B2"),
# # #                 PinRef(component_ref="CR3", pin="A"),
# # #             ]),
# # #             # LED6 path
# # #             Net(name="LED6_DRIVE", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="12"),
# # #                 PinRef(component_ref="R6", pin="B1"),
# # #             ]),
# # #             Net(name="LED6", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="R6", pin="B2"),
# # #                 PinRef(component_ref="CR6", pin="A"),
# # #             ]),
# # #             # Feedback connections (ring oscillator stages)
# # #             Net(name="FEEDBACK_D", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="9"),
# # #                 PinRef(component_ref="U1", pin="8"),
# # #             ]),
# # #             Net(name="FEEDBACK_E", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="11"),
# # #                 PinRef(component_ref="U1", pin="10"),
# # #             ]),
# # #             Net(name="FEEDBACK_F", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="13"),
# # #                 PinRef(component_ref="U1", pin="12"),
# # #             ]),
# # #             Net(name="FEEDBACK_C", net_type="signal", connected_pins=[
# # #                 PinRef(component_ref="U1", pin="5"),
# # #                 PinRef(component_ref="U1", pin="6"),
# # #             ]),
# # #         ]
# # #     )

# # #     mg.store_circuit_spec(spec)
# # #     print("✅ LED Flasher circuit loaded successfully with R8 properly connected!")
# # #     print()
# # #     print("Circuit Summary:")
# # #     print("  Main ICs: CD74AC14M (Hex Schmitt Trigger) + NE555 (Timer)")
# # #     print("  Power: USB VBUS (5V) -> VCC rail")
# # #     print("  Ground: DGND")
# # #     print("  LEDs: 6x red LEDs with 330Ω current limiting resistors")
# # #     print("  Timing: 555 in astable mode (R7=10KΩ, R8=1KΩ, C4=4.7µF)")
# # #     print()
# # #     print("R8 connections (FIXED):")
# # #     print("  - B1 connected to VCC")
# # #     print("  - B2 connected to timing capacitor C4 and 555 pins 2,6,7")





# # # from agent import CircuitMemgraph, CircuitSpec, Component, Net, PinRef
# # # from gqlalchemy import Memgraph

# # # def delete_all():
# # #     mg = Memgraph(host="127.0.0.1", port=7687)
# # #     mg.execute("MATCH (n) DETACH DELETE n")
# # #     print("✅ All old data deleted!")

# # # def load_buck_converter():
# # #     mg = CircuitMemgraph()

# # #     spec = CircuitSpec(
# # #         title="12V to 5V Buck Converter",
# # #         description="DC-DC buck converter using LMR62014XMFE boost regulator with input/output capacitors and inductor. All components from StarterLibrary.",
# # #         confidence_score=0.92,
# # #         needs_validation=False,
# # #         checklist=[],
# # #         components=[
# # #             # Main IC - exact match in library
# # #             Component(
# # #                 ref="U1", type="IC", value="LMR62014XMFE",
# # #                 footprint="SOT95P280X145-5AN",
# # #                 part_number="LMR62014XMFE",
# # #                 manufacturerPN="LMR62014XMFE/NOPB",
# # #                 manufacturer="Texas Instruments",
# # #                 pins=["~SHDN", "Vin", "GND", "FB", "SW"]
# # #             ),
# # #             # Inductor - exact match in library
# # #             Component(
# # #                 ref="L1", type="Inductor", value="BK2125HS102-T",
# # #                 footprint="INDC2013X130N",
# # #                 part_number="BK2125HS102-T",
# # #                 manufacturerPN="BK2125HS102-T",
# # #                 manufacturer="Taiyo Yuden",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             # Diode - exact match in library (Schottky)
# # #             Component(
# # #                 ref="D1", type="Diode", value="MBR120VLSFT1G",
# # #                 footprint="SOD3716X135N",
# # #                 part_number="MBR120VLSFT1G",
# # #                 manufacturerPN="MBR120VLSFT1G",
# # #                 manufacturer="On Semi",
# # #                 pins=["A", "C"]
# # #             ),
# # #             # Input capacitor 0.1uF - C1206-104-100-10 from library
# # #             Component(
# # #                 ref="C1", type="Capacitor", value="0.1uF",
# # #                 footprint="CAPC3216X105N",
# # #                 part_number="C1206-104-100-10",
# # #                 manufacturerPN="C1206F104K1RACTU",
# # #                 manufacturer="Kemet",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             # Output capacitor 10uF - C1206-106-25-10 from library
# # #             Component(
# # #                 ref="C2", type="Capacitor", value="10uF",
# # #                 footprint="CAPC3216X105N",
# # #                 part_number="C1206-106-25-10",
# # #                 manufacturerPN="CL31A106KAHNNNE",
# # #                 manufacturer="Samsung",
# # #                 pins=["B1", "B2"]
# # #             ),
        
# # #             # Feedback resistor upper 10k - R0603-103-5-025 from library
# # #             Component(
# # #                 ref="R1", type="Resistor", value="10k",
# # #                 footprint="RESC1608X50AN",
# # #                 part_number="R0603-103-5-025",
# # #                 manufacturerPN="ESR03EZPJ103",
# # #                 manufacturer="Rohm",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             # Feedback resistor lower 1k - R0603-102-5-025 from library
# # #             Component(
# # #                 ref="R2", type="Resistor", value="1k",
# # #                 footprint="RESC1608X50AN",
# # #                 part_number="R0603-102-5-025",
# # #                 manufacturerPN="ESR03EZPJ102",
# # #                 manufacturer="Rohm",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #             # SHDN pullup 4.7k - R0603-472-5-025 from library
# # #             Component(
# # #                 ref="R3", type="Resistor", value="4.7k",
# # #                 footprint="RESC1608X50AN",
# # #                 part_number="R0603-472-5-025",
# # #                 manufacturerPN="ESR03EZPJ472",
# # #                 manufacturer="Rohm",
# # #                 pins=["B1", "B2"]
# # #             ),
# # #         ],
# # #         nets=[
# # #     Net(name="VIN_12V", net_type="power", connected_pins=[
# # #         PinRef(component_ref="U1", pin="Vin"),
# # #         PinRef(component_ref="C1", pin="B1"),
# # #     ]),
# # #     Net(name="SW", net_type="signal", connected_pins=[
# # #         PinRef(component_ref="U1", pin="SW"),
# # #         PinRef(component_ref="L1", pin="B1"),
# # #         PinRef(component_ref="D1", pin="C"),
# # #     ]),
# # #     Net(name="VOUT_5V", net_type="power", connected_pins=[
# # #         PinRef(component_ref="L1", pin="B2"),
# # #         PinRef(component_ref="C2", pin="B1"),
# # #         PinRef(component_ref="R1", pin="B1"),
# # #         PinRef(component_ref="R3", pin="B1"),
# # #     ]),
# # #     Net(name="FB", net_type="signal", connected_pins=[
# # #         PinRef(component_ref="U1", pin="FB"),
# # #         PinRef(component_ref="R1", pin="B2"),
# # #         PinRef(component_ref="R2", pin="B1"),
# # #     ]),
# # #     Net(name="SHDN", net_type="signal", connected_pins=[
# # #         PinRef(component_ref="U1", pin="~SHDN"),
# # #         PinRef(component_ref="R3", pin="B2"),
# # #     ]),
# # #     Net(name="GND", net_type="ground", connected_pins=[
# # #         PinRef(component_ref="U1", pin="GND"),
# # #         PinRef(component_ref="D1", pin="A"),
# # #         PinRef(component_ref="C1", pin="B2"),
# # #         PinRef(component_ref="C2", pin="B2"),
# # #         PinRef(component_ref="R2", pin="B2"),
# # #     ]),
# # #     # Remove the BST net entirely, or if C3 is needed elsewhere:
# # #     # If C3 is your output capacitor, it's already VOUT_5V
# # #     # If C3 is input capacitor, it should be VIN_12V
# # # ]
# # #     )

# # #     mg.store_circuit_spec(spec)
# # #     print("✅ 12V to 5V Buck Converter loaded using StarterLibrary components!")
# # #     print()
# # #     print("Components used from library:")
# # #     print("  U1: LMR62014XMFE (Texas Instruments) - IC REG BOOST ADJ 1.4A SOT23-5")
# # #     print("  L1: BK2125HS102-T (Taiyo Yuden) - Inductor 1000 Ohm")
# # #     print("  D1: MBR120VLSFT1G (On Semi) - DIODE SCHOTTKY 20V 1A")
# # #     print("  C1: C1206-104-100-10 (Kemet) - 0.1uF 100V input cap")
# # #     print("  C2: C1206-106-25-10 (Samsung) - 10uF 25V output cap")
# # #     print("  C3: C1206-225-25-20 (Kemet) - 2.2uF 25V bootstrap cap")
# # #     print("  R1: R0603-103-5-025 (Rohm) - 10k feedback upper")
# # #     print("  R2: R0603-102-5-025 (Rohm) - 1k feedback lower")
# # #     print("  R3: R0603-472-5-025 (Rohm) - 4.7k SHDN pullup")


# # # if __name__ == "__main__":
# # #     delete_all()
# # #     print("📦 Loading LED Flasher circuit with R8 properly connected...")
# # #     load_led_flasher()
# # #     load_buck_converter()


# # from matplotlib.style import library

# # from agent import CircuitMemgraph, CircuitSpec, Component, Net, PinRef
# # from gqlalchemy import Memgraph


# # def load_5v_to_12v_boost():
# #     mg = CircuitMemgraph()

# #     spec = CircuitSpec(
# #         title="5V to 12V Boost Converter",
# #         description="Simple boost converter using LMR62014XMFE/NOPB. Converts USB 5V to 12V output. Ideal for LED strips or small loads.",
# #         confidence_score=0.95,
# #         needs_validation=False,
# #         checklist=[],
# #         components=[
# #             # Main Boost Converter IC
# #             Component(
# #                 ref="U1", type="IC", value="LMR62014XMFE/NOPB",
# #                 footprint="SOT95P280X145-5AN",
# #                 part_number="LMR62014XMFE/NOPB",
# #                 manufacturerPN="LMR62014XMFE/NOPB",
# #                 manufacturer="Texas Instruments",
# #                 pins=["~SHDN", "Vin", "GND", "FB", "SW"]
# #             ),
# #             # Power Inductor
# #             Component(
# #                 ref="L1", type="Inductor", value="10uH",
# #                 footprint="INDC2013X130N",
# #                 part_number="BK2125HS102-T",
# #                 manufacturerPN="BK2125HS102-T",
# #                 manufacturer="Taiyo Yuden",
# #                 pins=["B1", "B2"]
# #             ),
# #             # Schottky Diode
# #             Component(
# #                 ref="D1", type="Diode", value="MBR120VLSFT1G",
# #                 footprint="SOD3716X135N",
# #                 part_number="MBR120VLSFT1G",
# #                 manufacturerPN="MBR120VLSFT1G",
# #                 manufacturer="On Semi",
# #                 pins=["A", "C"]
# #             ),
# #             # Input Capacitor 10uF
# #             Component(
# #                 ref="C1", type="Capacitor", value="10uF",
# #                 footprint="CAPC3216X105N",
# #                 part_number="C1206-106-25-10",
# #                 manufacturerPN="CL31A106KAHNNNE",
# #                 manufacturer="Samsung",
# #                 pins=["B1", "B2"]
# #             ),
# #             # Output Capacitor 10uF
# #             Component(
# #                 ref="C2", type="Capacitor", value="10uF",
# #                 footprint="CAPC3216X105N",
# #                 part_number="C1206-106-25-10",
# #                 manufacturerPN="CL31A106KAHNNNE",
# #                 manufacturer="Samsung",
# #                 pins=["B1", "B2"]
# #             ),
# #             # Feedback Resistor Upper (for 12V: Vout = 1.23V * (1 + R1/R2))
# #             Component(
# #                 ref="R1", type="Resistor", value="88.7k",
# #                 footprint="RESC1608X50AN",
# #                 part_number="R0603-8872-1-025",
# #                 manufacturerPN="ESR03EZPJ8872",
# #                 manufacturer="Rohm",
# #                 pins=["B1", "B2"]
# #             ),
# #             # Feedback Resistor Lower 10k
# #             Component(
# #                 ref="R2", type="Resistor", value="10k",
# #                 footprint="RESC1608X50AN",
# #                 part_number="R0603-103-5-025",
# #                 manufacturerPN="ESR03EZPJ103",
# #                 manufacturer="Rohm",
# #                 pins=["B1", "B2"]
# #             ),
# #             # Enable Pull-up 100k
# #             Component(
# #                 ref="R3", type="Resistor", value="100k",
# #                 footprint="RESC1608X50AN",
# #                 part_number="R0603-104-5-025",
# #                 manufacturerPN="ESR03EZPJ104",
# #                 manufacturer="Rohm",
# #                 pins=["B1", "B2"]
# #             ),
# #             # USB Connector
# #             Component(
# #                 ref="J1", type="Connector", value="USB_Micro_B",
# #                 footprint="ZX62D_B_5P8",
# #                 part_number="0675031020",
# #                 manufacturerPN="0675031020",
# #                 manufacturer="Molex",
# #                 pins=["VBUS", "GND"]
# #             ),
# #         ],
# #         nets=[
# #             Net(name="VIN_5V", net_type="power", connected_pins=[
# #                 PinRef(component_ref="J1", pin="VBUS"),
# #                 PinRef(component_ref="U1", pin="Vin"),
# #                 PinRef(component_ref="C1", pin="B1"),
# #                 PinRef(component_ref="R3", pin="B1"),
# #             ]),
# #             Net(name="SW", net_type="signal", connected_pins=[
# #                 PinRef(component_ref="U1", pin="SW"),
# #                 PinRef(component_ref="L1", pin="B1"),
# #                 PinRef(component_ref="D1", pin="C"),
# #             ]),
# #             Net(name="VOUT_12V", net_type="power", connected_pins=[
# #                 PinRef(component_ref="L1", pin="B2"),
# #                 PinRef(component_ref="D1", pin="A"),
# #                 PinRef(component_ref="C2", pin="B1"),
# #                 PinRef(component_ref="R1", pin="B1"),
# #             ]),
# #             Net(name="FB", net_type="signal", connected_pins=[
# #                 PinRef(component_ref="U1", pin="FB"),
# #                 PinRef(component_ref="R1", pin="B2"),
# #                 PinRef(component_ref="R2", pin="B1"),
# #             ]),
# #             Net(name="ENABLE", net_type="signal", connected_pins=[
# #                 PinRef(component_ref="U1", pin="~SHDN"),
# #                 PinRef(component_ref="R3", pin="B2"),
# #             ]),
# #             Net(name="GND", net_type="ground", connected_pins=[
# #                 PinRef(component_ref="J1", pin="GND"),
# #                 PinRef(component_ref="U1", pin="GND"),
# #                 PinRef(component_ref="C1", pin="B2"),
# #                 PinRef(component_ref="C2", pin="B2"),
# #                 PinRef(component_ref="R2", pin="B2"),
# #             ]),
# #         ]
# #     )

# #     mg.store_circuit_spec(spec)
# #     print("✅ 5V to 12V Boost Converter loaded!")
# #     print()
# #     print("Circuit Summary:")
# #     print("  Input: USB 5V")
# #     print("  Output: 12V at up to 300mA")
# #     print("  Switching Frequency: 1.6MHz")
# #     print("  Efficiency: ~85%")


# # def load_37v_to_5v_power_bank():
# #     mg = CircuitMemgraph()

# #     spec = CircuitSpec(
# #         title="3.7V Li-ion to 5V USB Power Bank",
# #         description="Boost converter from single Li-ion battery (3.7V) to 5V USB output. Perfect for portable battery packs.",
# #         confidence_score=0.95,
# #         needs_validation=False,
# #         checklist=[],
# #         components=[
# #             Component(
# #                 ref="U1", type="IC", value="LMR62014XMFE/NOPB",
# #                 footprint="SOT95P280X145-5AN",
# #                 part_number="LMR62014XMFE/NOPB",
# #                 manufacturerPN="LMR62014XMFE/NOPB",
# #                 manufacturer="Texas Instruments",
# #                 pins=["~SHDN", "Vin", "GND", "FB", "SW"]
# #             ),
# #             Component(
# #                 ref="L1", type="Inductor", value="10uH",
# #                 footprint="INDC2013X130N",
# #                 part_number="BK2125HS102-T",
# #                 manufacturerPN="BK2125HS102-T",
# #                 manufacturer="Taiyo Yuden",
# #                 pins=["B1", "B2"]
# #             ),
# #             Component(
# #                 ref="D1", type="Diode", value="MBR120VLSFT1G",
# #                 footprint="SOD3716X135N",
# #                 part_number="MBR120VLSFT1G",
# #                 manufacturerPN="MBR120VLSFT1G",
# #                 manufacturer="On Semi",
# #                 pins=["A", "C"]
# #             ),
# #             # Input capacitor for battery
# #             Component(
# #                 ref="C1", type="Capacitor", value="22uF",
# #                 footprint="CAPC3216X105N",
# #                 part_number="C1206-226-16-10",
# #                 manufacturerPN="CL31A226KAHNNNE",
# #                 manufacturer="Samsung",
# #                 pins=["B1", "B2"]
# #             ),
# #             # Output capacitor
# #             Component(
# #                 ref="C2", type="Capacitor", value="10uF",
# #                 footprint="CAPC3216X105N",
# #                 part_number="C1206-106-25-10",
# #                 manufacturerPN="CL31A106KAHNNNE",
# #                 manufacturer="Samsung",
# #                 pins=["B1", "B2"]
# #             ),
# #             # For 5V output: standard 10k/3.3k divider
# #             Component(
# #                 ref="R1", type="Resistor", value="30.1k",
# #                 footprint="RESC1608X50AN",
# #                 part_number="R0603-3012-1-025",
# #                 manufacturerPN="ESR03EZPJ3012",
# #                 manufacturer="Rohm",
# #                 pins=["B1", "B2"]
# #             ),
# #             Component(
# #                 ref="R2", type="Resistor", value="10k",
# #                 footprint="RESC1608X50AN",
# #                 part_number="R0603-103-5-025",
# #                 manufacturerPN="ESR03EZPJ103",
# #                 manufacturer="Rohm",
# #                 pins=["B1", "B2"]
# #             ),
# #             Component(
# #                 ref="R3", type="Resistor", value="100k",
# #                 footprint="RESC1608X50AN",
# #                 part_number="R0603-104-5-025",
# #                 manufacturerPN="ESR03EZPJ104",
# #                 manufacturer="Rohm",
# #                 pins=["B1", "B2"]
# #             ),
# #             # Battery connector
# #             Component(
# #                 ref="J1", type="Connector", value="BATTERY",
# #                 footprint="SIP240W50P254L1514H508Q6A",
# #                 part_number="PREC015SAAN-RC",
# #                 manufacturerPN="PREC015SAAN-RC",
# #                 manufacturer="Sullins",
# #                 pins=["1", "2"]
# #             ),
# #             # USB Output connector
# #             Component(
# #                 ref="J2", type="Connector", value="USB_Type_A",
# #                 footprint="ZX62D_B_5P8",
# #                 part_number="0675031020",
# #                 manufacturerPN="0675031020",
# #                 manufacturer="Molex",
# #                 pins=["VBUS", "GND"]
# #             ),
# #         ],
# #         nets=[
# #             Net(name="VIN_BATTERY", net_type="power", connected_pins=[
# #                 PinRef(component_ref="J1", pin="1"),
# #                 PinRef(component_ref="U1", pin="Vin"),
# #                 PinRef(component_ref="C1", pin="B1"),
# #                 PinRef(component_ref="R3", pin="B1"),
# #             ]),
# #             Net(name="BATTERY_GND", net_type="ground", connected_pins=[
# #                 PinRef(component_ref="J1", pin="2"),
# #                 PinRef(component_ref="U1", pin="GND"),
# #                 PinRef(component_ref="C1", pin="B2"),
# #             ]),
# #             Net(name="SW", net_type="signal", connected_pins=[
# #                 PinRef(component_ref="U1", pin="SW"),
# #                 PinRef(component_ref="L1", pin="B1"),
# #                 PinRef(component_ref="D1", pin="C"),
# #             ]),
# #             Net(name="VOUT_5V", net_type="power", connected_pins=[
# #                 PinRef(component_ref="L1", pin="B2"),
# #                 PinRef(component_ref="D1", pin="A"),
# #                 PinRef(component_ref="C2", pin="B1"),
# #                 PinRef(component_ref="R1", pin="B1"),
# #                 PinRef(component_ref="J2", pin="VBUS"),
# #             ]),
# #             Net(name="FB", net_type="signal", connected_pins=[
# #                 PinRef(component_ref="U1", pin="FB"),
# #                 PinRef(component_ref="R1", pin="B2"),
# #                 PinRef(component_ref="R2", pin="B1"),
# #             ]),
# #             Net(name="ENABLE", net_type="signal", connected_pins=[
# #                 PinRef(component_ref="U1", pin="~SHDN"),
# #                 PinRef(component_ref="R3", pin="B2"),
# #             ]),
# #             Net(name="GND", net_type="ground", connected_pins=[
# #                 PinRef(component_ref="J2", pin="GND"),
# #                 PinRef(component_ref="C2", pin="B2"),
# #                 PinRef(component_ref="R2", pin="B2"),
# #             ]),
# #         ]
# #     )

# #     mg.store_circuit_spec(spec)
# #     print("✅ 3.7V Li-ion to 5V Power Bank loaded!")
# #     print()
# #     print("Circuit Summary:")
# #     print("  Input: 3.7V Li-ion battery")
# #     print("  Output: 5V USB at up to 300mA")
# #     print("  Ideal for portable projects")




from gqlalchemy import Memgraph

def delete_circuit_by_title(title):
    mg = Memgraph(host="127.0.0.1", port=7687)
    
    # Find and delete the circuit
    query = f"""
    MATCH (desc:CircuitDescription {{title: '{title}'}})
    DETACH DELETE desc
    RETURN COUNT(desc) as deleted_count
    """
    
    result = list(mg.execute_and_fetch(query))
    deleted = result[0]['deleted_count'] if result else 0
    
    if deleted > 0:
        print(f"✅ Deleted circuit: '{title}'")
    else:
        print(f"❌ Circuit not found: '{title}'")
    
    return deleted

# # Delete the specific circuit


# # if __name__ == "__main__":

# #     delete_circuit_by_title("USB-Powered Indicator Circuit with FT232RL")
# #     # delete_circuit_by_title("3.7V Li-ion to 5V USB Power Bank") 
# #     # load_5v_to_12v_boost()
# #     # load_37v_to_5v_power_bank()



from agent import CircuitMemgraph, CircuitSpec, Component, Net, PinRef


def load_arduino_mega_2560():
    mg = CircuitMemgraph()

    spec = CircuitSpec(
        title="arduino_mega_2560-rev3",
        description=(
        "Build a complete PCB schematic for the Arduino Mega 2560 Rev3, clearly indicating the primary active components including the ATmega2560 microcontroller, ATMEGA8U2 USB-to-serial interface, NCP1117ST50T3G voltage regulator, and LMV358 op-amp, along with all power distribution networks and ground planes for comprehensive circuit analysis."),
        confidence_score=0.95,
        needs_validation=False,
        checklist=[],

        # ── 62 COMPONENTS ──────────────────────────────────────────────────────
        components=[

            # ── Capacitors (17) ───────────────────────────────────────────────
            Component(ref="C1",  type="Capacitor", value="22pF",   part_number="06035A220JAT2A",       manufacturer="AVX Corporation",                    pins=["B1", "B2"]),
            Component(ref="C2",  type="Capacitor", value="0.1uF",  part_number="CC0603KRX7R9BB104",    manufacturer="Yageo",                              pins=["B1", "B2"]),
            Component(ref="C3",  type="Capacitor", value="0.1uF",  part_number="GRM188R71C104KA01D",   manufacturer="Murata Electronics North America",   pins=["B1", "B2"]),
            Component(ref="C4",  type="Capacitor", value="0.1uF",  part_number="GRM188R71C104KA01D",   manufacturer="Murata Electronics North America",   pins=["B1", "B2"]),
            Component(ref="C5",  type="Capacitor", value="0.1uF",  part_number="GRM188R71C104KA01D",   manufacturer="Murata Electronics North America",   pins=["B1", "B2"]),
            Component(ref="C6",  type="Capacitor", value="0.1uF",  part_number="GRM188R71C104KA01D",   manufacturer="Murata Electronics North America",   pins=["B1", "B2"]),
            Component(ref="C7",  type="Capacitor", value="0.1uF",  part_number="CC0603KRX7R9BB104",    manufacturer="Yageo",                              pins=["B1", "B2"]),
            Component(ref="C8",  type="Capacitor", value="0.1uF",  part_number="CC0603KRX7R9BB104",    manufacturer="Yageo",                              pins=["B1", "B2"]),
            Component(ref="C9",  type="Capacitor", value="0.1uF",  part_number="CC0603KRX7R9BB104",    manufacturer="Yageo",                              pins=["B1", "B2"]),
            Component(ref="C10", type="Capacitor", value="1.0uF",  part_number="GRM188R60J105KA01D",   manufacturer="Murata Electronics North America",   pins=["B1", "B2"]),
            Component(ref="C11", type="Capacitor", value="0.1uF",  part_number="GRM188R71C104KA01D",   manufacturer="Murata Electronics North America",   pins=["B1", "B2"]),
            Component(ref="C12", type="Capacitor", value="0.1uF",  part_number="GRM188R71C104KA01D",   manufacturer="Murata Electronics North America",   pins=["B1", "B2"]),
            Component(ref="C13", type="Capacitor", value="1.0uF",  part_number="LMK107B7105KA-T",      manufacturer="Taiyo Yuden",                        pins=["B1", "B2"]),
            Component(ref="C14", type="Capacitor", value="22pF",   part_number="500R14N220JV4T",       manufacturer="Johanson Dielectrics Inc",           pins=["B1", "B2"]),
            Component(ref="C15", type="Capacitor", value="22pF",   part_number="500R14N220JV4T",       manufacturer="Johanson Dielectrics Inc",           pins=["B1", "B2"]),
            Component(ref="PC1", type="Capacitor", value="47uF",   part_number="EMVA250ADA470MF55G",   manufacturer="United Chemi-Con",                   pins=["B1", "B2"]),
            Component(ref="PC2", type="Capacitor", value="47uF",   part_number="EMVA250ADA470MF55G",   manufacturer="United Chemi-Con",                   pins=["B1", "B2"]),

            # ── Connectors (14) ───────────────────────────────────────────────
            Component(ref="ICSP1", type="Connector", part_number="67996-406HLF",  manufacturer="FCI",                       pins=["P1","P2","P3","P4","P5","P6"]),
            Component(ref="J1",    type="Connector", part_number="CP-102A",       manufacturer="CUI",                       pins=["1","2","3"]),
            Component(ref="JP1",   type="Connector", part_number="JUMPER1",       manufacturer=None,                        pins=["PIN1","PIN2"]),
            Component(ref="JP2",   type="Connector", part_number="JUMPER2",       manufacturer=None,                        pins=["PIN1","PIN2"]),
            Component(ref="JP5",   type="Connector", part_number="67996-404HLF",  manufacturer="FCI",                       pins=["P1","P2","P3","P4"]),
            Component(ref="JP6",   type="Connector", part_number=None,            manufacturer=None,                        pins=["P1","P2","P3","P4","P5","P6","P7","P8","P9","P10"]),
            Component(ref="U3",    type="Connector", part_number="535541-6",      manufacturer="TE Connectivity",           pins=["P1","P2","P3","P4","P5","P6","P7","P8"]),
            Component(ref="U4",    type="Connector", part_number="535541-6",      manufacturer="TE Connectivity",           pins=["P1","P2","P3","P4","P5","P6","P7","P8"]),
            Component(ref="U5",    type="Connector", part_number="535541-6",      manufacturer="TE Connectivity",           pins=["P1","P2","P3","P4","P5","P6","P7","P8"]),
            Component(ref="U6",    type="Connector", part_number="535541-6",      manufacturer="TE Connectivity",           pins=["P1","P2","P3","P4","P5","P6","P7","P8"]),
            Component(ref="U7",    type="Connector", part_number="535541-6",      manufacturer="TE Connectivity",           pins=["P1","P2","P3","P4","P5","P6","P7","P8"]),
            Component(ref="U8",    type="Connector", part_number=None,            manufacturer=None,                        pins=[str(i) for i in range(1, 37)]),
            Component(ref="U9",    type="Connector", part_number=None,            manufacturer=None,                        pins=["1","2","3","4","5","6"]),
            Component(ref="X2",    type="Connector", part_number="USB-B1HSW62",   manufacturer="On Shore Technology Inc",   pins=["1","2","3","4","5"]),

            # ── Diodes (7) ────────────────────────────────────────────────────
            Component(ref="D1",  type="Diode", part_number="S2M-13-F",       manufacturer="Diodes Incorporated",  pins=["A", "K"]),
            Component(ref="D2",  type="Diode", part_number="CD1206-S01575",  manufacturer="Bourns Inc.",          pins=["A", "K"]),
            Component(ref="D3",  type="Diode", part_number="CD1206-S01575",  manufacturer="Bourns Inc.",          pins=["A", "K"]),
            Component(ref="D4",  type="Diode", part_number="LTST-C171GKT",   manufacturer="Lite-On Inc",          pins=["A", "C"]),
            Component(ref="D5",  type="Diode", part_number="LTST-S220KSKT",  manufacturer="Lite-On Inc",          pins=["A", "C"]),
            Component(ref="U10", type="Diode", part_number="APT2012YC",      manufacturer="Kingbright",           pins=["A", "K"]),
            Component(ref="U11", type="Diode", part_number="APT2012YC",      manufacturer="Kingbright",           pins=["A", "K"]),

            # ── Fuse (1) ──────────────────────────────────────────────────────
            Component(ref="F1", type="Fuse", part_number="MF-MSMF050-2", manufacturer="Bourns Inc.", pins=["P1", "P2"]),

            # ── ICs (9) ───────────────────────────────────────────────────────
            Component(ref="IC1",  type="IC", part_number="NCP1117ST50T3G",       manufacturer="ON Semiconductor",    pins=["GND", "OUT", "IN", "OUT2"]),
            Component(ref="IC3",  type="IC", part_number="ATMEGA2560-16AU",       manufacturer="Atmel",
                pins=[
                    "VCC_10","VCC_31","VCC_61","VCC_80",
                    "GND_11","GND_32","GND_62","GND_81","AGND",
                    "AVCC","AREF",
                    "PA0","PA1","PA2","PA3","PA4","PA5","PA6","PA7",
                    "PB0","PB1","PB2","PB3","PB4","PB5","PB6","PB7",
                    "PC0","PC1","PC2","PC3","PC4","PC5","PC6","PC7",
                    "PD0","PD1","PD2","PD3","PD7",
                    "PE0","PE1","PE3","PE4","PE5",
                    "PF0","PF1","PF2","PF3","PF4","PF5","PF6","PF7",
                    "PG0","PG1","PG2","PG5",
                    "PH0","PH1","PH3","PH4","PH5","PH6",
                    "PJ0","PJ1",
                    "PK0","PK1","PK2","PK3","PK4","PK5","PK6","PK7",
                    "PL0","PL1","PL2","PL3","PL4","PL5","PL6","PL7",
                    "XTAL1","XTAL2","176Reset",
                ]),
            Component(ref="IC4",  type="IC", part_number="ATMEGA8U2-MUR",         manufacturer="Atmel",
                pins=["XTAL1","XTAL2","GND","VCC","UVCC","UCAP","UGND",
                      "D+","D-","RESET","MOSI","MISO","SCLK","AVCC",
                      "RXD","TXD","PD4","PD5","PD7","PB4","PB5","PB6","PB7",
                      "1","2","3","4","8","9","10","11","13","15","16","17",
                      "18","19","20","21","24","27","28","29","30","31","32"]),
            Component(ref="IC6",  type="IC", part_number="DIGIKEY-296-18476-1-ND", manufacturer="Texas Instruments",  pins=["VIN","GND","ON_OFF","4","VOUT"]),
            Component(ref="IC7",  type="IC", part_number="LMV358IDGKR_2",          manufacturer="Texas Instruments",  pins=["1","2","3","4","5","6","7","8"]),
            Component(ref="MTG1", type="IC", part_number=None,                      manufacturer=None,                 pins=["1"]),
            Component(ref="MTG2", type="IC", part_number=None,                      manufacturer=None,                 pins=["1"]),
            Component(ref="MTG3", type="IC", part_number=None,                      manufacturer=None,                 pins=["1"]),
            Component(ref="MTG4", type="IC", part_number=None,                      manufacturer=None,                 pins=["1"]),

            # ── Inductor (1) ──────────────────────────────────────────────────
            Component(ref="L1", type="Inductor", part_number="BLM21PG221SN1D", manufacturer="Murata Electronics North America", pins=["B1", "B2"]),

            # ── Oscillators (2) ───────────────────────────────────────────────
            Component(ref="Y1", type="Oscillator", value="15pF",   part_number="CSTCE16M0V53-R0",   manufacturer="Murata Electronics North America",  pins=["1","2","3"]),
            Component(ref="Y2", type="Oscillator", value="16 MHz", part_number="ABL-16_000MHZ-B2",  manufacturer="Abracon Corporation",               pins=["B1","B2"]),

            # ── Resistors (7) ─────────────────────────────────────────────────
            Component(ref="R1",  type="Resistor", value="1M",  part_number="RC0603FR-071ML",   manufacturer="Yageo",                        pins=["B1","B2"]),
            Component(ref="R2",  type="Resistor", value="1M",  part_number="ERJ-3GEYJ105V",    manufacturer="Panasonic Electronic Components",pins=["B1","B2"]),
            Component(ref="RN1", type="Resistor", value="1K",  part_number="CAY16-102J4LF",    manufacturer="Bourns Inc.",                  pins=["B1","B2","B3","B4","B5","B6","B7","B8"]),
            Component(ref="RN2", type="Resistor", value="22",  part_number="CAY16-220J4LF",    manufacturer="Bourns Inc.",                  pins=["B1","B2","B3","B4","B5","B6","B7","B8"]),
            Component(ref="RN3", type="Resistor", value="1K",  part_number="CAY16-102J4LF",    manufacturer="Bourns Inc.",                  pins=["B1","B2","B3","B4","B5","B6","B7","B8"]),
            Component(ref="RN4", type="Resistor", value="1K",  part_number="CAY16-102J4LF",    manufacturer="Bourns Inc.",                  pins=["B1","B2","B3","B4","B5","B6","B7","B8"]),
            Component(ref="RN5", type="Resistor", value="1K",  part_number="CAY16-102J4LF",    manufacturer="Bourns Inc.",                  pins=["B1","B2","B3","B4","B5","B6","B7","B8"]),

            # ── Switch (1) ────────────────────────────────────────────────────
            Component(ref="SW1", type="Switch", part_number="TS42031-160R-TR-7260", manufacturer="Omron", pins=["1","2","3","4"]),

            # ── Transistor (1) ────────────────────────────────────────────────
            Component(ref="T1", type="Transistor", part_number="FDN340P", manufacturer="Fairchild Semiconductor", pins=["B","C","E"]),

            # ── Voltage Regulators (2) ────────────────────────────────────────
            Component(ref="Z1", type="Voltage Regulator", part_number="CG0603MLC-05E", manufacturer="Bourns Inc.", pins=["B1","B2"]),
            Component(ref="Z2", type="Voltage Regulator", part_number="CG0603MLC-05E", manufacturer="Bourns Inc.", pins=["B1","B2"]),
        ],

        # ── 110 NETS ───────────────────────────────────────────────────────────
        nets=[

            # ── Power / Ground ─────────────────────────────────────────────────
            Net(name="GND", net_type="ground", connected_pins=[
                PinRef(component_ref="C1",   pin="B2"),
                PinRef(component_ref="C2",   pin="B2"),
                PinRef(component_ref="C4",   pin="B2"),
                PinRef(component_ref="C5",   pin="B2"),
                PinRef(component_ref="C6",   pin="B2"),
                PinRef(component_ref="C8",   pin="B1"),
                PinRef(component_ref="C9",   pin="B2"),
                PinRef(component_ref="C11",  pin="B2"),
                PinRef(component_ref="C12",  pin="B2"),
                PinRef(component_ref="C13",  pin="B2"),
                PinRef(component_ref="C14",  pin="B1"),
                PinRef(component_ref="C15",  pin="B1"),
                PinRef(component_ref="D4",   pin="C"),
                PinRef(component_ref="D5",   pin="C"),
                PinRef(component_ref="IC1",  pin="GND"),
                PinRef(component_ref="IC3",  pin="GND_11"),
                PinRef(component_ref="IC3",  pin="GND_32"),
                PinRef(component_ref="IC3",  pin="GND_62"),
                PinRef(component_ref="IC3",  pin="GND_81"),
                PinRef(component_ref="IC3",  pin="AGND"),
                PinRef(component_ref="IC4",  pin="GND"),
                PinRef(component_ref="IC6",  pin="GND"),
                PinRef(component_ref="IC7",  pin="4"),
                PinRef(component_ref="ICSP1",pin="P6"),
                PinRef(component_ref="J1",   pin="1"),
                PinRef(component_ref="J1",   pin="3"),
                PinRef(component_ref="JP1",  pin="PIN1"),
                PinRef(component_ref="JP6",  pin="P4"),
                PinRef(component_ref="PC1",  pin="B2"),
                PinRef(component_ref="PC2",  pin="B2"),
                PinRef(component_ref="RN3",  pin="B6"),
                PinRef(component_ref="RN5",  pin="B1"),
                PinRef(component_ref="SW1",  pin="1"),
                PinRef(component_ref="SW1",  pin="2"),
                PinRef(component_ref="U7",   pin="P6"),
                PinRef(component_ref="U7",   pin="P7"),
                PinRef(component_ref="U8",   pin="35"),
                PinRef(component_ref="U8",   pin="36"),
                PinRef(component_ref="U9",   pin="6"),
                PinRef(component_ref="Y1",   pin="2"),
            ]),

            Net(name="+5V", net_type="power", connected_pins=[
                PinRef(component_ref="C4",   pin="B1"),
                PinRef(component_ref="C5",   pin="B1"),
                PinRef(component_ref="C6",   pin="B1"),
                PinRef(component_ref="C9",   pin="B1"),
                PinRef(component_ref="C11",  pin="B1"),
                PinRef(component_ref="D2",   pin="K"),
                PinRef(component_ref="D3",   pin="K"),
                PinRef(component_ref="IC1",  pin="OUT"),
                PinRef(component_ref="IC1",  pin="OUT2"),
                PinRef(component_ref="IC3",  pin="VCC_10"),
                PinRef(component_ref="IC3",  pin="VCC_31"),
                PinRef(component_ref="IC3",  pin="VCC_61"),
                PinRef(component_ref="IC3",  pin="VCC_80"),
                PinRef(component_ref="IC3",  pin="AVCC"),
                PinRef(component_ref="IC4",  pin="VCC"),
                PinRef(component_ref="IC4",  pin="AVCC"),
                PinRef(component_ref="IC6",  pin="VIN"),
                PinRef(component_ref="IC6",  pin="ON_OFF"),
                PinRef(component_ref="IC7",  pin="8"),
                PinRef(component_ref="ICSP1",pin="P2"),
                PinRef(component_ref="PC2",  pin="B1"),
                PinRef(component_ref="RN1",  pin="B2"),
                PinRef(component_ref="RN3",  pin="B1"),
                PinRef(component_ref="RN4",  pin="B6"),
                PinRef(component_ref="RN5",  pin="B1"),
                PinRef(component_ref="RN5",  pin="B2"),
                PinRef(component_ref="T1",   pin="C"),
                PinRef(component_ref="U7",   pin="P2"),
                PinRef(component_ref="U7",   pin="P5"),
                PinRef(component_ref="U8",   pin="1"),
                PinRef(component_ref="U8",   pin="2"),
                PinRef(component_ref="U9",   pin="2"),
            ]),

            Net(name="USBVCC", net_type="power", connected_pins=[
                PinRef(component_ref="C8",  pin="B2"),
                PinRef(component_ref="F1",  pin="P2"),
                PinRef(component_ref="IC4", pin="UVCC"),
                PinRef(component_ref="T1",  pin="E"),
            ]),

            Net(name="XVCC", net_type="power", connected_pins=[
                PinRef(component_ref="F1",  pin="P1"),
                PinRef(component_ref="X2",  pin="1"),
            ]),

            Net(name="VIN", net_type="power", connected_pins=[
                PinRef(component_ref="C2",  pin="B1"),
                PinRef(component_ref="D1",  pin="K"),
                PinRef(component_ref="IC1", pin="IN"),
                PinRef(component_ref="PC1", pin="B1"),
                PinRef(component_ref="RN5", pin="B6"),
                PinRef(component_ref="U7",  pin="P8"),
            ]),

            Net(name="PWRIN", net_type="power", connected_pins=[
                PinRef(component_ref="D1",  pin="A"),
                PinRef(component_ref="J1",  pin="2"),
            ]),

            Net(name="UGND", net_type="ground", connected_pins=[
                PinRef(component_ref="C10",  pin="B2"),
                PinRef(component_ref="IC4",  pin="UGND"),
                PinRef(component_ref="JP1",  pin="PIN2"),
                PinRef(component_ref="L1",   pin="B1"),
                PinRef(component_ref="X2",   pin="4"),
            ]),

            # ── USB / Serial ───────────────────────────────────────────────────
            Net(name="D+", net_type="signal", connected_pins=[
                PinRef(component_ref="RN2", pin="B5"),
                PinRef(component_ref="X2",  pin="3"),
                PinRef(component_ref="Z2",  pin="B1"),
            ]),

            Net(name="D-", net_type="signal", connected_pins=[
                PinRef(component_ref="RN2", pin="B5"),
                PinRef(component_ref="X2",  pin="2"),
                PinRef(component_ref="Z1",  pin="B1"),
            ]),

            Net(name="RD+", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4", pin="D+"),
                PinRef(component_ref="RN2", pin="B1"),
            ]),

            Net(name="RD-", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4", pin="D-"),
                PinRef(component_ref="RN2", pin="B1"),
            ]),

            Net(name="USHIELD", net_type="signal", connected_pins=[
                PinRef(component_ref="L1",  pin="B2"),
                PinRef(component_ref="Z1",  pin="B2"),
                PinRef(component_ref="Z2",  pin="B2"),
            ]),

            Net(name="VUCAP", net_type="signal", connected_pins=[
                PinRef(component_ref="C10", pin="B1"),
                PinRef(component_ref="IC4", pin="UCAP"),
            ]),

            # ── Reset / DTR ────────────────────────────────────────────────────
            Net(name="RESET", net_type="signal", connected_pins=[
                PinRef(component_ref="C1",   pin="B1"),
                PinRef(component_ref="C7",   pin="B1"),
                PinRef(component_ref="D3",   pin="A"),
                PinRef(component_ref="IC3",  pin="176Reset"),
                PinRef(component_ref="JP2",  pin="PIN1"),
                PinRef(component_ref="JP2",  pin="PIN2"),
                PinRef(component_ref="RN5",  pin="B8"),
                PinRef(component_ref="SW1",  pin="3"),
                PinRef(component_ref="SW1",  pin="4"),
                PinRef(component_ref="U7",   pin="P3"),
                PinRef(component_ref="U9",   pin="5"),
            ]),

            Net(name="RESET2", net_type="signal", connected_pins=[
                PinRef(component_ref="D2",   pin="A"),
                PinRef(component_ref="IC4",  pin="RESET"),
                PinRef(component_ref="ICSP1",pin="P5"),
                PinRef(component_ref="RN5",  pin="B5"),
            ]),

            Net(name="DTR", net_type="signal", connected_pins=[
                PinRef(component_ref="C7",   pin="B2"),
                PinRef(component_ref="IC4",  pin="PD7"),
                PinRef(component_ref="RN3",  pin="B3"),
            ]),

            # ── SPI / ICSP ────────────────────────────────────────────────────
            Net(name="MOSI2", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4",  pin="MOSI"),
                PinRef(component_ref="ICSP1",pin="P4"),
            ]),

            Net(name="MISO2", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4",  pin="MISO"),
                PinRef(component_ref="ICSP1",pin="P1"),
            ]),

            Net(name="SCK2", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4",  pin="SCLK"),
                PinRef(component_ref="ICSP1",pin="P3"),
            ]),

            # ── Crystal oscillator (16 MHz, IC4) ──────────────────────────────
            Net(name="XT1", net_type="signal", connected_pins=[
                PinRef(component_ref="C14", pin="B2"),
                PinRef(component_ref="IC4", pin="XTAL1"),
                PinRef(component_ref="R2",  pin="B1"),
                PinRef(component_ref="Y2",  pin="B1"),
            ]),

            Net(name="XT2", net_type="signal", connected_pins=[
                PinRef(component_ref="C15", pin="B2"),
                PinRef(component_ref="IC4", pin="XTAL2"),
                PinRef(component_ref="R2",  pin="B2"),
                PinRef(component_ref="Y2",  pin="B2"),
            ]),

            # ── Crystal / resonator (IC3 / ATMEGA2560) ────────────────────────
            Net(name="$2N1267", net_type="signal", connected_pins=[
                PinRef(component_ref="IC3", pin="XTAL2"),
                PinRef(component_ref="R1",  pin="B1"),
                PinRef(component_ref="Y1",  pin="1"),
            ]),

            Net(name="$2N1266", net_type="signal", connected_pins=[
                PinRef(component_ref="IC3", pin="XTAL1"),
                PinRef(component_ref="R1",  pin="B2"),
                PinRef(component_ref="Y1",  pin="3"),
            ]),

            # ── 3.3 V rail ────────────────────────────────────────────────────
            Net(name="+3V3", net_type="signal", connected_pins=[
                PinRef(component_ref="C13", pin="B1"),
                PinRef(component_ref="IC6", pin="VOUT"),
                PinRef(component_ref="IC7", pin="6"),
                PinRef(component_ref="U7",  pin="P4"),
            ]),

            # ── AREF ──────────────────────────────────────────────────────────
            Net(name="AREF", net_type="signal", connected_pins=[
                PinRef(component_ref="C3",  pin="B1"),
                PinRef(component_ref="IC3", pin="AREF"),
                PinRef(component_ref="JP6", pin="P3"),
            ]),

            # ── CMP / power-select ────────────────────────────────────────────
            Net(name="CMP", net_type="signal", connected_pins=[
                PinRef(component_ref="C12", pin="B1"),
                PinRef(component_ref="IC7", pin="5"),
                PinRef(component_ref="RN5", pin="B6"),
                PinRef(component_ref="RN5", pin="B5"),
            ]),

            Net(name="$2N1033", net_type="signal", connected_pins=[
                PinRef(component_ref="IC7", pin="7"),
                PinRef(component_ref="T1",  pin="B"),
            ]),

            Net(name="$2N1032", net_type="signal", connected_pins=[
                PinRef(component_ref="IC7", pin="1"),
                PinRef(component_ref="IC7", pin="2"),
                PinRef(component_ref="RN3", pin="B7"),
            ]),

            Net(name="$2N1031", net_type="signal", connected_pins=[
                PinRef(component_ref="D4",  pin="A"),
                PinRef(component_ref="RN3", pin="B5"),
            ]),

            Net(name="$2N1030", net_type="signal", connected_pins=[
                PinRef(component_ref="D5",  pin="A"),
                PinRef(component_ref="RN3", pin="B2"),
            ]),

            # ── MEGA2560 UART ──────────────────────────────────────────────────
            Net(name="M8TXD", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4", pin="RXD"),
                PinRef(component_ref="RN4", pin="B5"),
            ]),

            Net(name="M8RXD", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4", pin="TXD"),
                PinRef(component_ref="RN4", pin="B5"),
            ]),

            Net(name="RXI", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4", pin="PD4"),
                PinRef(component_ref="U10", pin="K"),
            ]),

            Net(name="TXI", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4", pin="PD5"),
                PinRef(component_ref="U11", pin="K"),
            ]),

            Net(name="$1N357", net_type="signal", connected_pins=[
                PinRef(component_ref="RN4", pin="B1"),
                PinRef(component_ref="U11", pin="A"),
            ]),

            Net(name="$1N356", net_type="signal", connected_pins=[
                PinRef(component_ref="RN4", pin="B1"),
                PinRef(component_ref="U10", pin="A"),
            ]),

            # ── ATmega8U2 port B ──────────────────────────────────────────────
            Net(name="8PB4", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4", pin="PB4"),
                PinRef(component_ref="JP5", pin="P1"),
            ]),
            Net(name="8PB5", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4", pin="PB5"),
                PinRef(component_ref="JP5", pin="P3"),
            ]),
            Net(name="8PB6", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4", pin="PB6"),
                PinRef(component_ref="JP5", pin="P2"),
            ]),
            Net(name="8PB7", net_type="signal", connected_pins=[
                PinRef(component_ref="IC4", pin="PB7"),
                PinRef(component_ref="JP5", pin="P4"),
            ]),

            # ── MEGA2560 Port A (digital 22–29 via U8) ────────────────────────
            Net(name="PA0", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PA0"), PinRef(component_ref="U8", pin="3")]),
            Net(name="PA1", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PA1"), PinRef(component_ref="U8", pin="4")]),
            Net(name="PA2", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PA2"), PinRef(component_ref="U8", pin="5")]),
            Net(name="PA3", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PA3"), PinRef(component_ref="U8", pin="6")]),
            Net(name="PA4", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PA4"), PinRef(component_ref="U8", pin="7")]),
            Net(name="PA5", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PA5"), PinRef(component_ref="U8", pin="8")]),
            Net(name="PA6", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PA6"), PinRef(component_ref="U8", pin="9")]),
            Net(name="PA7", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PA7"), PinRef(component_ref="U8", pin="10")]),

            # ── MEGA2560 Port B (SPI / digital 50–53, via U8 / U9) ────────────
            Net(name="PB0", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PB0"), PinRef(component_ref="U8", pin="34")]),
            Net(name="PB1", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PB1"), PinRef(component_ref="U8", pin="33"), PinRef(component_ref="U9", pin="3")]),
            Net(name="PB2", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PB2"), PinRef(component_ref="U8", pin="32"), PinRef(component_ref="U9", pin="4")]),
            Net(name="PB3", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PB3"), PinRef(component_ref="U8", pin="31"), PinRef(component_ref="U9", pin="1")]),
            Net(name="PB4", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PB4"), PinRef(component_ref="JP6", pin="P8")]),
            Net(name="PB5", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PB5"), PinRef(component_ref="JP6", pin="P7")]),
            Net(name="PB6", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PB6"), PinRef(component_ref="JP6", pin="P6")]),
            Net(name="PB7", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PB7"), PinRef(component_ref="IC7", pin="3"),  PinRef(component_ref="JP6", pin="P5")]),

            # ── MEGA2560 Port C (digital 30–37 via U8) ────────────────────────
            Net(name="PC0", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PC0"), PinRef(component_ref="U8", pin="18")]),
            Net(name="PC1", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PC1"), PinRef(component_ref="U8", pin="17")]),
            Net(name="PC2", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PC2"), PinRef(component_ref="U8", pin="16")]),
            Net(name="PC3", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PC3"), PinRef(component_ref="U8", pin="15")]),
            Net(name="PC4", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PC4"), PinRef(component_ref="U8", pin="14")]),
            Net(name="PC5", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PC5"), PinRef(component_ref="U8", pin="13")]),
            Net(name="PC6", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PC6"), PinRef(component_ref="U8", pin="12")]),
            Net(name="PC7", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PC7"), PinRef(component_ref="U8", pin="11")]),

            # ── MEGA2560 Port D (I2C / UART1 / timer) ────────────────────────
            Net(name="SCL",  net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PD0"), PinRef(component_ref="JP6", pin="P1"), PinRef(component_ref="RN1", pin="B7"), PinRef(component_ref="U4", pin="P1")]),
            Net(name="SDA",  net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PD1"), PinRef(component_ref="JP6", pin="P2"), PinRef(component_ref="RN1", pin="B3"), PinRef(component_ref="U4", pin="P2")]),
            Net(name="RXD1", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PD2"), PinRef(component_ref="U4",  pin="P3")]),
            Net(name="TXD1", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PD3"), PinRef(component_ref="U4",  pin="P4")]),
            Net(name="PD7",  net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PD7"), PinRef(component_ref="U8",  pin="19")]),

            # ── MEGA2560 Port E ────────────────────────────────────────────────
            Net(name="PE0", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PE0"), PinRef(component_ref="RN4", pin="B1"), PinRef(component_ref="U5", pin="P1")]),
            Net(name="PE1", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PE1"), PinRef(component_ref="RN4", pin="B1"), PinRef(component_ref="U5", pin="P2")]),
            Net(name="PE3", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PE3"), PinRef(component_ref="U5",  pin="P6")]),
            Net(name="PE4", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PE4"), PinRef(component_ref="U5",  pin="P3")]),
            Net(name="PE5", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PE5"), PinRef(component_ref="U5",  pin="P4")]),

            # ── MEGA2560 Port F (analog inputs A0–A7) ─────────────────────────
            Net(name="ADC0", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PF0"), PinRef(component_ref="U6", pin="P1")]),
            Net(name="ADC1", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PF1"), PinRef(component_ref="U6", pin="P2")]),
            Net(name="ADC2", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PF2"), PinRef(component_ref="U6", pin="P3")]),
            Net(name="ADC3", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PF3"), PinRef(component_ref="U6", pin="P4")]),
            Net(name="ADC4", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PF4"), PinRef(component_ref="U6", pin="P5")]),
            Net(name="ADC5", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PF5"), PinRef(component_ref="U6", pin="P6")]),
            Net(name="ADC6", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PF6"), PinRef(component_ref="U6", pin="P7")]),
            Net(name="ADC7", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PF7"), PinRef(component_ref="U6", pin="P8")]),

            # ── MEGA2560 Port G ────────────────────────────────────────────────
            Net(name="PG0", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PG0"), PinRef(component_ref="U8", pin="22")]),
            Net(name="PG1", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PG1"), PinRef(component_ref="U8", pin="21")]),
            Net(name="PG2", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PG2"), PinRef(component_ref="U8", pin="20")]),
            Net(name="PG5", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PG5"), PinRef(component_ref="U5", pin="P5")]),

            # ── MEGA2560 Port H (UART2 / PWM) ─────────────────────────────────
            Net(name="RXD2", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PH0"), PinRef(component_ref="U4", pin="P5")]),
            Net(name="TXD2", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PH1"), PinRef(component_ref="U4", pin="P6")]),
            Net(name="PH3",  net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PH3"), PinRef(component_ref="U5", pin="P7")]),
            Net(name="PH4",  net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PH4"), PinRef(component_ref="U5", pin="P8")]),
            Net(name="PH5",  net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PH5"), PinRef(component_ref="JP6", pin="P10")]),
            Net(name="PH6",  net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PH6"), PinRef(component_ref="JP6", pin="P9")]),

            # ── MEGA2560 Port J (UART3) ────────────────────────────────────────
            Net(name="RXD3", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PJ0"), PinRef(component_ref="U4", pin="P7")]),
            Net(name="TXD3", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PJ1"), PinRef(component_ref="U4", pin="P8")]),

            # ── MEGA2560 Port K (analog inputs A8–A15) ────────────────────────
            Net(name="ADC8",  net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PK0"), PinRef(component_ref="U3", pin="P1")]),
            Net(name="ADC9",  net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PK1"), PinRef(component_ref="U3", pin="P2")]),
            Net(name="ADC10", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PK2"), PinRef(component_ref="U3", pin="P3")]),
            Net(name="ADC11", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PK3"), PinRef(component_ref="U3", pin="P4")]),
            Net(name="ADC12", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PK4"), PinRef(component_ref="U3", pin="P5")]),
            Net(name="ADC13", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PK5"), PinRef(component_ref="U3", pin="P6")]),
            Net(name="ADC14", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PK6"), PinRef(component_ref="U3", pin="P7")]),
            Net(name="ADC15", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PK7"), PinRef(component_ref="U3", pin="P8")]),

            # ── MEGA2560 Port L (digital 42–49 via U8) ────────────────────────
            Net(name="PL0", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PL0"), PinRef(component_ref="U8", pin="30")]),
            Net(name="PL1", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PL1"), PinRef(component_ref="U8", pin="29")]),
            Net(name="PL2", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PL2"), PinRef(component_ref="U8", pin="28")]),
            Net(name="PL3", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PL3"), PinRef(component_ref="U8", pin="27")]),
            Net(name="PL4", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PL4"), PinRef(component_ref="U8", pin="26")]),
            Net(name="PL5", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PL5"), PinRef(component_ref="U8", pin="25")]),
            Net(name="PL6", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PL6"), PinRef(component_ref="U8", pin="24")]),
            Net(name="PL7", net_type="signal", connected_pins=[PinRef(component_ref="IC3", pin="PL7"), PinRef(component_ref="U8", pin="23")]),
        ]
    )

    mg.store_circuit_spec(spec)

    print("✅ Arduino Mega 2560 Rev3 loaded successfully!")
    print()
    print("Circuit Summary:")
    print("  Main MCU  : ATmega2560-16AU  (IC3) — 100-pin TQFP, 256KB flash")
    print("  USB bridge: ATmega8U2-MUR    (IC4) — USB ↔ UART converter")
    print("  LDO 5V    : NCP1117ST50T3G   (IC1) — 1 A, SOT-223")
    print("  LDO 3.3V  : DIGIKEY-296-18476-1-ND (IC6) — 0.15 A, SOT-23-5")
    print("  Op-amp    : LMV358IDGKR_2    (IC7) — power-select comparator")
    print()
    print("  Power rails : +5V, USBVCC, XVCC, VIN, PWRIN")
    print("  Ground nets : GND, UGND")
    print()
    print(f"  Components  : 62 total")
    print(f"    Capacitors       : 17  (C1–C15, PC1, PC2)")
    print(f"    Connectors       : 14  (ICSP1, J1, JP1, JP2, JP5, JP6, U3–U9, X2)")
    print(f"    Diodes/LEDs      :  7  (D1–D5, U10, U11)")
    print(f"    Fuse             :  1  (F1 — resettable PTC)")
    print(f"    ICs              :  9  (IC1, IC3, IC4, IC6, IC7, MTG1–MTG4)")
    print(f"    Inductor         :  1  (L1 — ferrite bead, USB shield)")
    print(f"    Oscillators      :  2  (Y1 ceramic resonator, Y2 16 MHz crystal)")
    print(f"    Resistors/Arrays :  7  (R1, R2, RN1–RN5)")
    print(f"    Switch           :  1  (SW1 — reset)")
    print(f"    Transistor       :  1  (T1 — PMOS power-path)")
    print(f"    Voltage regs     :  2  (Z1, Z2 — varistors/TVS)")
    print()
    print(f"  Nets        : 110")
    print(f"    Power     :  6  (GND, +5V, USBVCC, XVCC, VIN, PWRIN)")
    print(f"    Ground    :  2  (GND, UGND)")
    print(f"    Signal    : 102")


if __name__ == "__main__":
    # delete_circuit_by_title("USB-Powered Indicator Circuit with FT232RL")

    load_arduino_mega_2560()