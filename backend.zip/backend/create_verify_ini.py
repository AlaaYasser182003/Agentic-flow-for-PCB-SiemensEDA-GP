"""
create_verify_ini.py
Sets up Verify.ini for PADS Professional schematic DRC.

Creation priority:
  1. Project directory     — use existing Verify.ini if already there
  2. Static fallback path  — known good Verify.ini from a verified project
  3. verificationUI.exe    — launch PADS GUI to auto-create
  4. Manual                — instruct user to run GUI once

Usage:
    python create_verify_ini.py                          # use defaults
    python create_verify_ini.py --prj path/project.prj  # specific project
    python create_verify_ini.py --force                  # re-patch even if exists
    python create_verify_ini.py --check                  # inspect current state
"""

import argparse
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from config import SDD_HOME , MGLAUNCH , VERIFY_UI, DEFAULT_PRJ_FILE, DEFAULT_VERIFY_INI, FALLBACK_VERIFY_INI

# ─────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────


# ── Only these checks are enabled — everything else is disabled ───────────────
ENABLE_CHECKS = {
    "drc-105",   # Un-driven net
    "drc-107",   # Unconnected pin
    "drc-108",   # Hanging/dangling net
    "drc-113",   # Inputs only connected to connectors/inputs
    "drc-114",   # Dipole only connected to input pins
    "drc-123",   # Single pin nets
    "drc-511",   # Invalid POWER/GROUND pin connection
}


# ─────────────────────────────────────────────────────────────
# Environment helper
# ─────────────────────────────────────────────────────────────

def _make_env(prj_file: str) -> dict:
    dll_paths = [
        os.path.join(SDD_HOME, "wv",     "win64", "bin"),
        os.path.join(SDD_HOME, "common", "win64", "bin"),
        os.path.join(SDD_HOME, "common", "win32", "bin"),
        os.path.join(SDD_HOME, "wg",     "win64", "bin"),
        os.path.join(SDD_HOME, "lm",     "win64", "bin"),
        os.path.join(SDD_HOME, "dx",     "win64", "bin"),
    ]
    dll_str = ";".join(p for p in dll_paths if os.path.exists(p))
    env = os.environ.copy()
    env["PATH"]     = dll_str + ";" + env.get("PATH", "")
    env["SDD_HOME"] = SDD_HOME
    env["MGC_WD"]   = str(Path(prj_file).parent)
    return env


# ─────────────────────────────────────────────────────────────
# Verify.ini validation
# ─────────────────────────────────────────────────────────────

def _is_valid_verify_ini(path: str) -> bool:
    """Check if a Verify.ini file has the correct PADS format."""
    if not os.path.exists(path):
        return False
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            text = f.read(1000)
        return 'version="1.0"' in text and '<GUI Name=' in text
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────
# Verify.ini patching
# ─────────────────────────────────────────────────────────────

def _set_state(text: str, drc_id: str, state: str) -> str:
    """
    Set State attribute for a specific drc-ID check tag.
    Handles both attribute orderings within the <Check ...> tag.
    """
    # ID before State
    pattern = rf'(<Check\b[^>]*\bID="{re.escape(drc_id)}"[^>]*\bState=)"[^"]*"'
    new_text = re.sub(pattern, rf'\g<1>"{state}"', text)

    # State before ID
    if new_text == text:
        pattern2 = rf'(<Check\b[^>]*\bState=)"[^"]*"([^>]*\bID="{re.escape(drc_id)}")'
        new_text = re.sub(pattern2, rf'\g<1>"{state}"\g<2>', text)

    return new_text


def patch_verify_ini(verify_ini_path: str) -> bool:
    """
    Enable only ENABLE_CHECKS — disable everything else.
    Two-pass:
      Pass 1: disable ALL checks in the file
      Pass 2: enable only ENABLE_CHECKS
    """
    if not os.path.exists(verify_ini_path):
        print(f"  ❌ Verify.ini not found: {verify_ini_path}")
        return False

    with open(verify_ini_path, encoding="utf-8", errors="ignore") as f:
        content = f.read()

    original = content
    all_ids  = set(re.findall(r'ID="(drc-[\w-]+)"', content))
    print(f"  Found {len(all_ids)} check IDs in Verify.ini")

    # Pass 1: disable ALL
    for drc_id in all_ids:
        content = _set_state(content, drc_id, "Disabled")

    # Pass 2: enable selected
    enabled_count = 0
    for drc_id in ENABLE_CHECKS:
        if drc_id in all_ids:
            content = _set_state(content, drc_id, "Enabled")
            enabled_count += 1
        else:
            print(f"  ⚠️  {drc_id} not found in Verify.ini — skipping")

    if content != original:
        with open(verify_ini_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"  ✅ Patched — {enabled_count}/{len(ENABLE_CHECKS)} checks enabled")
    else:
        print(f"  ℹ️  Already correct — no changes needed")

    enabled  = sorted(re.findall(r'ID="(drc-[\w-]+)"[^>]*State="Enabled"', content))
    disabled = sorted(re.findall(r'ID="(drc-[\w-]+)"[^>]*State="Disabled"', content))
    print(f"  Enabled  ({len(enabled)}): {enabled}")
    print(f"  Disabled ({len(disabled)}): {len(disabled)} checks")

    unexpected = set(enabled) - ENABLE_CHECKS
    if unexpected:
        print(f"  ⚠️  Unexpected enabled: {unexpected}")

    return True


def verify_patch_result(verify_ini_path: str) -> dict:
    """Read Verify.ini and return summary of what's enabled/disabled."""
    if not os.path.exists(verify_ini_path):
        return {"error": "Verify.ini not found"}

    with open(verify_ini_path, encoding="utf-8", errors="ignore") as f:
        content = f.read()

    enabled  = sorted(re.findall(r'ID="(drc-[\w-]+)"[^>]*State="Enabled"', content))
    disabled = sorted(re.findall(r'ID="(drc-[\w-]+)"[^>]*State="Disabled"', content))

    unexpected_on    = set(enabled) - ENABLE_CHECKS
    missing_from_ini = ENABLE_CHECKS - set(enabled) - set(disabled)

    return {
        "enabled":          enabled,
        "disabled_count":   len(disabled),
        "total":            len(enabled) + len(disabled),
        "missing_from_ini": list(missing_from_ini),
        "unexpected_on":    list(unexpected_on),
        "ok":               len(unexpected_on) == 0 and len(missing_from_ini) == 0,
    }


# ─────────────────────────────────────────────────────────────
# Creation strategies
# ─────────────────────────────────────────────────────────────

def _try_static_fallback(target: str) -> bool:
    """
    Copy from the static fallback path — a known-good Verify.ini
    that has already been validated with PADS for this installation.
    Update FALLBACK_VERIFY_INI at the top of this file to point
    to your working reference file.
    """
    if FALLBACK_VERIFY_INI == target:
        return False

    if not _is_valid_verify_ini(FALLBACK_VERIFY_INI):
        print(f"  ⚠️  Static fallback not valid or not found: {FALLBACK_VERIFY_INI}")
        return False

    shutil.copy2(FALLBACK_VERIFY_INI, target)
    print(f"  ✅ Copied from static fallback: {FALLBACK_VERIFY_INI}")
    return True


def _try_verificationUI(prj_file: str, verify_ini: str) -> bool:
    """
    Launch verificationUI.exe to create Verify.ini for this project.
    Opens a brief GUI window — closes automatically after initialization.
    """
    print(f"  🚀 Launching verificationUI.exe...")

    if not os.path.exists(VERIFY_UI):
        print(f"  ⚠️  verificationUI.exe not found: {VERIFY_UI}")
        return False

    cmd = [MGLAUNCH, VERIFY_UI, "-proj", prj_file]
    print(f"     CMD: {' '.join(cmd)}")

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=_make_env(prj_file),
            cwd=os.path.join(SDD_HOME, "standard"),
        )
        for i in range(6):
            time.sleep(5)
            if Path(verify_ini).exists():
                proc.terminate()
                print(f"  ✅ Verify.ini created by verificationUI.exe")
                return True
            print(f"     Waiting... ({(i+1)*5}s)")

        proc.terminate()
        print(f"  ⚠️  Verify.ini not created after 30s")
        return False

    except Exception as e:
        print(f"  ❌ verificationUI.exe error: {e}")
        return False


# ─────────────────────────────────────────────────────────────
# Main setup function
# ─────────────────────────────────────────────────────────────

def setup_verify_ini(
    prj_file:   str  = DEFAULT_PRJ_FILE,
    verify_ini: str  = None,
    force:      bool = False,
) -> bool:
    """
    Full setup: locate or create Verify.ini, then patch checks.

    Creation priority:
      1. Project directory     — existing Verify.ini in same folder as .prj
      2. Static fallback path  — FALLBACK_VERIFY_INI (update at top of file)
      3. verificationUI.exe    — launch PADS to auto-create
      4. Manual instructions   — tell user what to do

    Patch logic:
      - If Verify.ini came from static fallback: skip patching
        (fallback is already correct)
      - Otherwise: always patch to ensure correct checks

    Args:
        prj_file:   Path to .prj file
        verify_ini: Override Verify.ini path (default: same dir as prj_file)
        force:      Re-patch even if Verify.ini already exists and is correct

    Returns True if Verify.ini is ready for vdrc.exe.
    """
    if verify_ini is None:
        verify_ini = os.path.join(os.path.dirname(prj_file), "Verify.ini")

    print(f"\n{'─'*55}")
    print(f"  Verify.ini Setup")
    print(f"  Project    : {prj_file}")
    print(f"  Verify.ini : {verify_ini}")
    print(f"{'─'*55}")

    # ── Step 1: Check project directory ───────────────────────────────────────
    if os.path.exists(verify_ini) and not force:
        if _is_valid_verify_ini(verify_ini):
            print(f"\n  ✅ Found valid Verify.ini in project directory")
        else:
            print(f"\n  ⚠️  Verify.ini exists but format invalid — re-creating")
            os.remove(verify_ini)

    # ── Step 2: Create if still missing ───────────────────────────────────────
    used_fallback = False

    if not os.path.exists(verify_ini):
        print(f"\n  Verify.ini not found — trying creation strategies...")

        # Strategy A: static fallback
        print(f"\n  Strategy 1: Static fallback ({FALLBACK_VERIFY_INI})")
        if _try_static_fallback(verify_ini):
            used_fallback = True

        # Strategy B: verificationUI.exe
        elif _try_verificationUI(prj_file, verify_ini):
            pass

        # Strategy C: manual
        else:
            print("\n  ❌ Could not create Verify.ini automatically.")
            print("     Manual steps:")
            print(f"       1. Open PADS: {prj_file}")
            print("       2. Open any block → Analysis → Verify → OK")
            print(f"       3. Verify.ini will appear at: {verify_ini}")
            print(f"       4. Copy it to FALLBACK_VERIFY_INI in create_verify_ini.py")
            print(f"          so future projects reuse it automatically.")
            return False

    elif force:
        print(f"\n  Force mode — re-patching existing Verify.ini")

    # ── Step 3: Patch checks (skip if came from static fallback) ──────────────
    if used_fallback:
        print("\n  Skipping patch — static fallback already has correct checks")
    else:
        print("\n  Patching checks...")
        patch_verify_ini(verify_ini)

    # ── Step 4: Verify result ──────────────────────────────────────────────────
    print("\n  Verifying patch...")
    result = verify_patch_result(verify_ini)

    if result.get("ok"):
        print(f"  ✅ Verified — enabled: {result['enabled']}")
    else:
        if result.get("unexpected_on"):
            print(f"  ⚠️  Unexpected checks enabled: {result['unexpected_on']}")
            if used_fallback:
                print(f"      Fallback file may have wrong checks — run --force to patch")
            else:
                print(f"      Run --force to re-patch")
        if result.get("missing_from_ini"):
            print(f"  ⚠️  Checks not found in file: {result['missing_from_ini']}")

    print(f"\n  ✅ Ready: {verify_ini}")
    return True


# ─────────────────────────────────────────────────────────────
# Called by stage0_pads_drc.py — ensure Verify.ini is ready
# ─────────────────────────────────────────────────────────────

def ensure_verify_ini(verify_path: str, prj_file: str) -> bool:
    """
    Called by stage0_pads_drc.py before running vdrc.exe.
    If Verify.ini is missing or invalid, runs full setup automatically.
    Never raises — returns True if ready, False if setup failed.

    Args:
        verify_path: Expected path to Verify.ini
        prj_file:    Path to .prj file (needed for creation strategies)

    Returns True if Verify.ini is valid and ready for vdrc.exe.
    """
    # Already valid — nothing to do
    if _is_valid_verify_ini(verify_path):
        print(f"  Verify.ini OK: {verify_path}")
        return True

    # Missing or invalid — run full setup
    if not os.path.exists(verify_path):
        print(f"  Verify.ini not found — running setup...")
    else:
        print(f"  Verify.ini invalid format — re-creating...")

    try:
        return setup_verify_ini(
            prj_file   = prj_file,
            verify_ini = verify_path,
            force      = False,
        )
    except Exception as e:
        print(f"  ❌ setup_verify_ini failed: {e}")
        return False


# ─────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Setup Verify.ini for PADS schematic DRC"
    )
    parser.add_argument("--prj",    default=DEFAULT_PRJ_FILE,
                        help="Path to .prj file")
    parser.add_argument("--verify", default=None,
                        help="Override Verify.ini path")
    parser.add_argument("--force",  action="store_true",
                        help="Re-patch even if Verify.ini already correct")
    parser.add_argument("--check",  action="store_true",
                        help="Inspect current state without making changes")
    args = parser.parse_args()

    verify_path = args.verify or os.path.join(
        os.path.dirname(args.prj), "Verify.ini"
    )

    if args.check:
        result = verify_patch_result(verify_path)
        print(f"\nVerify.ini: {verify_path}")
        print(f"  Valid format : {_is_valid_verify_ini(verify_path)}")
        print(f"  Enabled      : {result.get('enabled', [])}")
        print(f"  Total checks : {result.get('total', 0)}")
        print(f"  OK           : {result.get('ok', False)}")
        if result.get("unexpected_on"):
            print(f"  ⚠️  Unexpected ON : {result['unexpected_on']}")
        if result.get("missing_from_ini"):
            print(f"  ⚠️  Not in file   : {result['missing_from_ini']}")
        exit(0 if result.get("ok") else 1)

    success = setup_verify_ini(
        prj_file   = args.prj,
        verify_ini = args.verify,
        force      = args.force,
    )

    if success:
        print(f"\n  Run DRC:")
        print(f'  python stage0_pads_drc.py "{args.prj}" "BLOCK_NAME" "{verify_path}"')

    exit(0 if success else 1)