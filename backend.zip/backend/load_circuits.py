"""
Run once to load all JSON files from the circuits/ folder into Memgraph.
Usage:
    python load_circuits.py
"""
import os
import glob

# Import back.py — this initialises Memgraph, OpenAI, the full pipeline
from agent import memgraph

CIRCUITS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "circuits\\final_circuits")

json_files = sorted(glob.glob(os.path.join(CIRCUITS_DIR, "*.json")))
print(CIRCUITS_DIR)
if not json_files:
    print("No JSON files found in circuits/")
else:
    for path in json_files:
        print(f"\n{'='*60}")
        print(f"Loading: {os.path.basename(path)}")
        print(f"{'='*60}")
        result = memgraph.bulk_load_circuits_to_memgraph(path)
        print(f"  stored={result['successfully_stored']}  failed={result['failed']}")

    print("\n✅ All done.")
