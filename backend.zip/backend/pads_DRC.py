"""
stage0_pads_drc.py
PADS Professional Schematic DRC using vdrc.exe

Key requirements (confirmed working):
  - CWD must be SDD_HOME/standard  (vllib.vmb lookup)
  - Use wv/win64/bin/vdrc.exe      (common/bin version is 16-bit stub)
  - PATH must include all PADS DLL folders before launching
  - Verify.ini must be created by PADS GUI (version="1.0" format)
  - Args: -proj -block -set -def -dxd_std -hier  (no -board)
  - Output is HTML — parse with regex

Verify.ini:
  - If missing or invalid, automatically calls create_verify_ini.ensure_verify_ini
  - All Verify.ini logic lives in create_verify_ini.py
  - Never raises on missing Verify.ini — returns SKIP result instead

Block name:
  - Pass base name from state["block_name"]
  - auto_find_block=True resolves versioned name (_2, _3...) automatically

Usage:
    python stage0_pads_drc.py
    python stage0_pads_drc.py "project.prj" "BlockName"
    python stage0_pads_drc.py "project.prj" "BlockName" "Verify.ini" "output_dir"
"""

import glob
import json
import os
import re
import sqlite3
import subprocess
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from config import SDD_HOME , VDRC_EXE, VERIFY_DEFAULTS ,  DEFAULT_PRJ_FILE as DEFAULT_PRJ , DEFAULT_VERIFY_INI as DEFAULT_VERIFY , STANDARD_DIR, STANDARD_DIR, OUTPUT_DIR
# ─────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────

DEFAULT_BLOCK  = "Schematic_1"

MAX_BLOCK_NAME_LEN = 64


# ─────────────────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────────────────

def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


# ─────────────────────────────────────────────────────────────
# Verify.ini — delegated entirely to create_verify_ini.py
# ─────────────────────────────────────────────────────────────

def ensure_verify_ini(verify_path: str, prj_file: str) -> bool:
    """
    Ensure Verify.ini exists and is valid before running DRC.
    All logic delegated to create_verify_ini.ensure_verify_ini.
    Never raises — returns False if setup failed so DRC returns SKIP.
    """
    try:
        from create_verify_ini import ensure_verify_ini as _ensure
        return _ensure(verify_path, prj_file)
    except ImportError:
        log("  ❌ create_verify_ini.py not found")
        log("     Place it in the same directory as pads_DRC.py")
        return False
    except Exception as e:
        log(f"  ❌ ensure_verify_ini error: {e}")
        return False


# ─────────────────────────────────────────────────────────────
# Block name auto-detection
# ─────────────────────────────────────────────────────────────

def _pick_latest(names: list[str], base_name: str) -> str:
    """Return the name with the highest _N suffix."""
    def _suffix(name: str) -> int:
        if name == base_name:
            return 1
        m = re.match(rf'^{re.escape(base_name)}_(\d+)$', name)
        return int(m.group(1)) if m else 0
    return max(names, key=_suffix) if names else base_name


def get_latest_block_name(design_name: str, prj_file: str) -> str:
    """
    Find the most recently imported version of design_name in the project.

    PADS increments block names on each import:
      MyCircuit       (first import)
      MyCircuit_2     (second import)
      MyCircuit_3     (third import)  ← returned

    Strategy 1: exact name or exact_N match in project subfolders
    Strategy 2: progressively shorter prefix match (handles PADS truncation)

    Args:
        design_name: Base block name (from state["block_name"])
        prj_file:    Path to .prj file

    Returns: Actual block name to pass to vdrc.exe
    """
    prj_dir      = str(Path(prj_file).parent)
    database_dir = os.path.join(prj_dir, "database")
    search_name  = design_name[:MAX_BLOCK_NAME_LEN]

    log(f"  🔍 Searching for block '{search_name}'")

    # Collect subdirs from both project root and database folder
    search_dirs = []
    for search_root in [database_dir, prj_dir]:
        if not os.path.isdir(search_root):
            continue
        try:
            for item in os.listdir(search_root):
                full = os.path.join(search_root, item)
                if os.path.isdir(full):
                    search_dirs.append((item, os.path.getmtime(full)))
        except Exception:
            continue

    if not search_dirs:
        log(f"  ⚠️  No subdirectories found — using base name")
        return search_name

    log(f"     Dirs: {sorted([d[0] for d in search_dirs])}")

    def _best(candidates):
        candidates.sort(key=lambda x: x[1], reverse=True)
        latest = candidates[0][0]
        if len(candidates) > 1:
            log(f"     All matches: {[c[0] for c in candidates]}")
        return latest

    # ── Strategy 1: Exact name or exact_N ─────────────────────────────────────
    s1 = [
        (name, mtime) for name, mtime in search_dirs
        if name == search_name or
           re.match(rf'^{re.escape(search_name)}_\d+$', name)
    ]
    if s1:
        latest = _best(s1)
        log(f"  📦 Strategy 1 (exact) — using: '{latest}'")
        return latest

    # ── Strategy 2: Progressively shorter prefix ───────────────────────────────
    MIN_PREFIX = 10
    for prefix_len in range(len(search_name) - 1, MIN_PREFIX - 1, -1):
        prefix = search_name[:prefix_len]
        s2 = [
            (name, mtime) for name, mtime in search_dirs
            if name == prefix or
               re.match(rf'^{re.escape(prefix)}_\d+$', name)
        ]
        if s2:
            latest = _best(s2)
            log(f"  📦 Strategy 2 (prefix len={prefix_len}) — using: '{latest}'")
            return latest

    log(f"  ⚠️  No match found — using base name: '{search_name}'")
    return search_name


# ─────────────────────────────────────────────────────────────
# Environment
# ─────────────────────────────────────────────────────────────

def make_env(prj_file: str) -> dict:
    dll_paths = [
        os.path.join(SDD_HOME, "wv",       "win64", "bin"),
        os.path.join(SDD_HOME, "wv",       "win64", "lib"),
        os.path.join(SDD_HOME, "common",   "win64", "bin"),
        os.path.join(SDD_HOME, "common",   "win64", "lib"),
        os.path.join(SDD_HOME, "wg",       "win64", "bin"),
        os.path.join(SDD_HOME, "common3D", "win64", "bin"),
        os.path.join(SDD_HOME, "lm",       "win64", "bin"),
        os.path.join(SDD_HOME, "dx",       "win64", "bin"),
    ]
    dll_str = ";".join(p for p in dll_paths if os.path.exists(p))
    os.environ["PATH"]     = dll_str + ";" + os.environ.get("PATH", "")
    os.environ["SDD_HOME"] = SDD_HOME
    env = os.environ.copy()
    env["MGC_WD"] = str(Path(prj_file).parent)
    return env


# ─────────────────────────────────────────────────────────────
# HTML output parser
# ─────────────────────────────────────────────────────────────

def parse_html_output(text: str):
    """Parse vdrc.exe -dxd_std HTML output into structured errors/warnings."""
    errors, warnings, notes = [], [], []

    link_pat = re.compile(
        r'style="color:(red|blue)[^"]*"[^>]*>'
        r'(drc-[\w-]+)\s*-\s*<b>\[([^\]]+)\]</b>\s*([^<]+)</a>',
        re.S
    )

    seen = set()
    for m in link_pat.finditer(text):
        color    = m.group(1)
        drc_id   = m.group(2).strip()
        location = m.group(3).strip()
        message  = m.group(4).strip()

        key = (drc_id, location)
        if key in seen:
            continue
        seen.add(key)

        item = {
            "severity": "ERROR" if color == "red" else "WARNING",
            "id":       drc_id,
            "location": location,
            "message":  message,
            "full":     f"{drc_id} [{location}] {message}",
        }
        if color == "red":
            errors.append(item)
        else:
            warnings.append(item)

    sm = re.search(
        r"(\d+)\s+Error\(s\),\s*(\d+)\s+Warning\(s\),\s*(\d+)\s+Note\(s\)",
        text
    )
    official = (int(sm.group(1)), int(sm.group(2)), int(sm.group(3))) if sm else (None, None, None)

    return errors, warnings, notes, official


# ─────────────────────────────────────────────────────────────
# Main DRC runner
# ─────────────────────────────────────────────────────────────

def run_pads_drc(
    prj_file:        str  = DEFAULT_PRJ,
    block_name:      str  = DEFAULT_BLOCK,
    verify_ini:      str  = DEFAULT_VERIFY,
    output_dir:      str  = OUTPUT_DIR,
    auto_find_block: bool = True,
) -> dict:
    """
    Run vdrc.exe schematic DRC on a PADS project block.

    Args:
        prj_file:        Path to .prj file
        block_name:      Base block name from state["block_name"]
        verify_ini:      Path to Verify.ini (auto-created if missing)
        output_dir:      Directory for result files
        auto_find_block: Find latest _N version of block_name automatically

    Returns: dict with pass_fail, error_count, errors, warnings, etc.
             Returns SKIP result if Verify.ini could not be created.
    """
    prj_file = str(Path(prj_file).resolve())
    if not os.path.exists(prj_file):
        raise FileNotFoundError(f"Project not found: {prj_file}")

    os.makedirs(output_dir, exist_ok=True)

    # ── Resolve actual block name ──────────────────────────────────────────────
    actual_block = block_name
    if auto_find_block:
        actual_block = get_latest_block_name(block_name, prj_file)
        if actual_block != block_name:
            log(f"  Block resolved: {block_name} → {actual_block}")

    log("═" * 60)
    log("  PADS SCHEMATIC DRC")
    log("═" * 60)
    log(f"  Project    : {prj_file}")
    log(f"  Block      : {actual_block}")
    log(f"  Verify.ini : {verify_ini}")
    log(f"  Output     : {output_dir}")
    log("─" * 60)

    # ── Ensure Verify.ini — delegated to create_verify_ini.py ─────────────────
    if not ensure_verify_ini(verify_ini, prj_file):
        log("  ❌ Verify.ini not available — skipping DRC")
        result = {
            "mode":        "vdrc.exe",
            "prj_file":    prj_file,
            "block_name":  actual_block,
            "block_name_base": block_name,
            "verify_ini":  verify_ini,
            "timestamp":   datetime.now().isoformat(),
            "status":      "skipped",
            "pass_fail":   "SKIP",
            "skip_reason": "Verify.ini could not be created",
            "error_count": 0, "warning_count": 0, "note_count": 0,
            "errors": [], "warnings": [], "notes": [],
            "library_errors": [], "design_errors": [], "expected_warnings": [],
            "exit_code":   -1,
        }
        json_path = os.path.join(output_dir, "drc_results.json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, default=str)
        return result

    # ── Run vdrc.exe ───────────────────────────────────────────────────────────
    cmd = [
        VDRC_EXE,
        "-proj",  prj_file,
        "-block", actual_block,
        "-set",   verify_ini,
        "-def",   VERIFY_DEFAULTS,
        "-dxd_std",
        "-hier",
    ]

    log(f"  Running vdrc.exe...")

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300,
            env=make_env(prj_file),
            cwd=STANDARD_DIR,
            encoding="utf-8",
            errors="ignore",
        )
        raw = (proc.stdout or "") + "\n" + (proc.stderr or "")
        log(f"  Exit code  : {proc.returncode}")
    except subprocess.TimeoutExpired:
        raw  = "TIMEOUT"
        proc = type("P", (), {"returncode": -1})()
        log("  ❌ TIMEOUT after 300s")
    except Exception as e:
        raw  = str(e)
        proc = type("P", (), {"returncode": -1})()
        log(f"  ❌ Error: {e}")

    # Save raw output
    out_txt = os.path.join(output_dir, "drc_results.txt")
    with open(out_txt, "w", encoding="utf-8") as f:
        f.write(f"Project    : {prj_file}\n")
        f.write(f"Block      : {actual_block}\n")
        f.write(f"Verify.ini : {verify_ini}\n")
        f.write(f"Time       : {datetime.now().isoformat()}\n\n")
        f.write(raw)

    # ── Detect false PASS ──────────────────────────────────────────────────────
    config_failed = (
        "Error : Cannot load configuration" in raw or
        ("Error: while reading file" in raw and "Verify.ini" in raw)
    )

    if config_failed:
        log("─" * 60)
        log("  ❌ CONFIG ERROR — Verify.ini rejected by vdrc.exe")
        log("     DRC checks were SKIPPED — this is a FALSE PASS")
        log("     Fix: python create_verify_ini.py --prj <project.prj> --force")
        log("─" * 60)
        result = {
            "mode":            "vdrc.exe",
            "prj_file":        prj_file,
            "block_name":      actual_block,
            "block_name_base": block_name,
            "verify_ini":      verify_ini,
            "timestamp":       datetime.now().isoformat(),
            "status":          "config_error",
            "pass_fail":       "SKIP",
            "skip_reason":     "Verify.ini rejected by vdrc.exe — no checks ran",
            "error_count":     0, "warning_count": 0, "note_count": 0,
            "errors": [], "warnings": [], "notes": [],
            "library_errors": [], "design_errors": [], "expected_warnings": [],
            "output_file":     out_txt,
            "exit_code":       proc.returncode,
        }
        json_path = os.path.join(output_dir, "drc_results.json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, default=str)
        return result

    # ── Parse results ──────────────────────────────────────────────────────────
    errors, warnings, notes, official = parse_html_output(raw)
    err_c  = official[0] if official[0] is not None else len(errors)
    warn_c = official[1] if official[1] is not None else len(warnings)
    note_c = official[2] if official[2] is not None else len(notes)

    pass_fail = "PASS" if err_c == 0 else "FAIL"

    # ── Print structured summary ───────────────────────────────────────────────
    log("─" * 60)
    log(f"  {'✅' if pass_fail == 'PASS' else '❌'} DRC RESULT : {pass_fail}")
    log(f"  Errors       : {err_c}")
    log(f"  Warnings     : {warn_c}")
    log(f"  Notes        : {note_c}")
    log("─" * 60)

    if errors:
        log(f"\n  ERRORS ({err_c})")
        log("  " + "─" * 50)
        error_groups = defaultdict(list)
        for e in errors:
            error_groups[e["id"]].append(e)
        for rule_id, items in error_groups.items():
            log(f"\n  ● {rule_id}  [{len(items)} occurrence(s)]")
            log(f"    Rule: {items[0]['message']}")
            log(f"    Affected:")
            for item in items:
                log(f"      • {item['location']}")

    if warnings:
        log(f"\n  WARNINGS ({warn_c})")
        log("  " + "─" * 50)
        warn_groups = defaultdict(list)
        for w in warnings:
            warn_groups[w["id"]].append(w)
        for rule_id, items in warn_groups.items():
            log(f"\n  ○ {rule_id}  [{len(items)} occurrence(s)]")
            log(f"    Rule: {items[0]['message']}")
            for item in items[:5]:
                log(f"      • {item['location']}")
            if len(items) > 5:
                log(f"      ... and {len(items) - 5} more")

    # ── Actionable summary ─────────────────────────────────────────────────────
    log("\n" + "─" * 60)
    log("  ACTIONABLE SUMMARY")
    log("─" * 60)

    if err_c == 0 and warn_c == 0:
        log("  ✅ Clean — no issues found")
    else:
        if errors:
            lib_errors    = [e for e in errors
                             if "POWER-GROUND" in e["id"] or "POWER-POWER" in e["id"]]
            design_errors = [e for e in errors if e not in lib_errors]
            if lib_errors:
                log(f"  ⚠️  {len(lib_errors)} error(s) — LIBRARY SYMBOL issues (not LLM-fixable)")
            if design_errors:
                log(f"  🔧 {len(design_errors)} error(s) — DESIGN issues (LLM can fix)")
        if warnings:
            bi_warns    = [w for w in warnings
                           if "BI-GROUND" in w["id"] or "BI-POWER" in w["id"]]
            other_warns = [w for w in warnings if w not in bi_warns]
            if bi_warns:
                log(f"  ℹ️  {len(bi_warns)} BI-pin warning(s) — expected for passives on power nets")
            if other_warns:
                log(f"  ⚠️  {len(other_warns)} other warning(s) need review")

    log("─" * 60)
    log(f"  Results : {out_txt}")

    # ── Build result dict ──────────────────────────────────────────────────────
    result = {
        "mode":             "vdrc.exe",
        "prj_file":         prj_file,
        "block_name":       actual_block,
        "block_name_base":  block_name,
        "verify_ini":       verify_ini,
        "timestamp":        datetime.now().isoformat(),
        "status":           "success",
        "pass_fail":        pass_fail,
        "error_count":      err_c,
        "warning_count":    warn_c,
        "note_count":       note_c,
        "errors":           errors,
        "warnings":         warnings,
        "notes":            notes,
        "output_file":      out_txt,
        "exit_code":        proc.returncode,
        "library_errors":   [e for e in errors
                             if "POWER-GROUND" in e["id"] or "POWER-POWER" in e["id"]],
        "design_errors":    [e for e in errors
                             if "POWER-GROUND" not in e["id"] and "POWER-POWER" not in e["id"]],
        "expected_warnings":[w for w in warnings
                             if "BI-GROUND" in w["id"] or "BI-POWER" in w["id"]],
    }

    json_path = os.path.join(output_dir, "drc_results.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, default=str)

    log(f"  JSON    : {json_path}")
    log("═" * 60)

    return result


def should_block_pipeline(result: dict, block_on_errors: bool = True) -> bool:
    return block_on_errors and result.get("error_count", 0) > 0


# ─────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    PRJ    = sys.argv[1] if len(sys.argv) >= 2 else DEFAULT_PRJ
    BLOCK  = sys.argv[2] if len(sys.argv) >= 3 else DEFAULT_BLOCK
    VERIFY = sys.argv[3] if len(sys.argv) >= 4 else DEFAULT_VERIFY
    OUT    = sys.argv[4] if len(sys.argv) >= 5 else OUTPUT_DIR

    result = run_pads_drc(
        prj_file        = PRJ,
        block_name      = BLOCK,
        verify_ini      = VERIFY,
        output_dir      = OUT,
        auto_find_block = True,
    )

    print()
    print("═" * 60)
    print(f"  DRC RESULT      : {result['pass_fail']}")
    print(f"  Errors          : {result['error_count']}")
    print(f"  Warnings        : {result['warning_count']}")
    print(f"  Block (base)    : {result['block_name_base']}")
    print(f"  Block (actual)  : {result['block_name']}")
    print(f"  Output          : {OUT}")
    print("═" * 60)

    if result["errors"]:
        print("\nErrors:")
        for e in result["errors"]:
            print(f"  {e['id']} [{e['location']}]: {e['message']}")

    sys.exit(1 if result["pass_fail"] == "FAIL" else 0)